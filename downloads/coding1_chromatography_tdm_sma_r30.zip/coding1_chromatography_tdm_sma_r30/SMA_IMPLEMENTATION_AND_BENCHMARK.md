# TDM + Steric Mass Action (R30)

## Sources and model choice

The binding law follows the [CADET-Core SMA modelling guide](https://cadet.github.io/v5.1.X/modelling/binding/steric_mass_action.html) and [parameter interface](https://cadet.github.io/v5.1.X/interface/binding/steric_mass_action.html). The transport balances follow CADET-Core's [lumped-rate model with pores](https://cadet.github.io/master/modelling/unit_operations/lumped_rate_model_with_pores.html) (LRMP): axial convection and dispersion in the column liquid, film transfer, a mixed pore liquid, and a solid adsorbed phase. This is the transport dispersive structure of this software. Radial pore diffusion is not included.

The literature cross-checks were Brooks and Cramer, *AIChE Journal* **38** (1992), 1969–1978, DOI 10.1002/aic.690381212 (original SMA displacement model); Briskot et al., *Journal of Chromatography A* **1653** (2021), 462397, DOI 10.1016/j.chroma.2021.462397 (SMA versus CPA in IEX, including its equilibrium SMA equation); and Kumar et al., *Journal of Chromatography A* **1426** (2015), 140–153, DOI 10.1016/j.chroma.2015.11.062 (mechanistic IEX modelling of mAb charge variants). CADET's equations and units govern this implementation where conventions differ.

The supplied Shekhawat et al., *Journal of Chromatography A* **1680** (2022), 463423, DOI 10.1016/j.chroma.2022.463423, uses a **general rate model plus extended Langmuir binding**, although it discusses SMA in the introduction. Its results therefore are not an SMA numerical benchmark and its binding parameters were not substituted for SMA parameters.

## Equations and units

Salt is component 0 and is treated as a monovalent counterion. For protein species `i`, with pore concentration `c_p,i` in mol/m³ liquid and stationary concentration `q_i` in mol/m³ solid:

```text
q_0    = Λ − Σ_i ν_i q_i
q_free = Λ − Σ_i (ν_i + σ_i) q_i
dq_i/dt = k_a,i c_p,i (q_free/q_ref)^ν_i
          − k_d,i q_i (c_p,0/c_ref)^ν_i
```

`Λ` is mol/m³ stationary phase, `ν_i` is characteristic charge, and `σ_i` is steric shielding. `k_a,i` is m³ liquid/(m³ solid·s), `k_d,i` is s⁻¹, and the reference concentrations `c_ref` and `q_ref` are mol/m³ in their respective phases. They default to 1 mol/m³, as in CADET. They define a parameter convention, so changing them without refitting the rate constants changes the predictions. The salt site balance is algebraic and coupled to the pore and interstitial salt transport; the program does not impose the gradient at the column outlet.

The kinetic option integrates the rate equation. The quasi-stationary option solves its zero-rate equilibrium at each axial cell while conserving pore protein and salt totals. In quasi-stationary mode, only `k_a/k_d` is identifiable; fitting holds `k_d` fixed. Molecular weight is required to convert feed mg/mL and UV mass responses to the molar binding basis; it is not an SMA binding parameter. The values of `ν`, `σ`, `k_a/k_d`, and `Λ` must be fitted or measured for the selected resin, protein, salt and pH.

## Numerical benchmark

The independent reference is CADET-Core's four-component `ref_LRMP_reqSMA_4comp_sensbenchmark1_DG_P3Z8.h5` (CADET 4.4.0, source commit `33d8e85f44e66310e994b97110169e9c47c6d358`). Its salt plus three protein outlet curves were mapped into this TDM setup. The reference is a quasi-stationary LRMP + SMA simulation with a 14 mm bed, 45 µm bead radius, `Λ=1200 mol/m³`, charges `[4.7, 5.29, 3.7]`, shielding `[11.83, 10.6, 10.0]`, and a salt gradient. The mapped configuration and 68 sampled reference points are packaged under `benchmark_scenarios/`. The artificial protein mass of **1 kDa** is only a unit-conversion device: 1 mol/m³ equals 1 g/L numerically. It is not a physical claim about those proteins.

At 32 axial cells, `python benchmark_scenarios/run_cadet_sma_benchmark.py` gives peak-normalized outlet RMSE of **0.00346% for salt** and **0.236%, 0.164%, 0.130%** for the three proteins against the 68 CADET reference points. Maximum protein mass closure error is **0.000213%**, salt closure error **0.00725%**, and the free-site and bound-counterion concentrations remain nonnegative. A separate full 1501-point reference comparison at 64 cells gave peak-normalized RMSE of **0.00195% salt** and **0.0472%, 0.0314%, 0.0222%** for proteins 1–3. These are numerical cross-checks, not experimental validation or a claim of exact identity to CADET's discretization.

The packaged tests also check the CADET rate formula and balances, kinetic and quasi-stationary solutions, JMP-to-Python handoff, SMA fitting parameter selection, method recipe retention, and existing Wang/Langmuir simulations. Run `python -m unittest tests.test_sma_r30` in the extracted folder.

## Limits

This SMA implementation uses one effective monovalent salt species. Buffer pH is retained in the process setup, but SMA charge and rate constants do **not** change with pH in this plain CADET SMA formulation. Use a fitted parameter set for the applicable pH range. Conductivity is converted to salt using the specified calibration when salt molarity is not entered. The illustrative SMA example and CADET mathematical benchmark are not calibrated predictions for a particular experimental CEX run.
