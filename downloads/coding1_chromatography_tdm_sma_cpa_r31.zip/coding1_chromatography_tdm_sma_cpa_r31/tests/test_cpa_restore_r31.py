"""R28 Poros 50 HS CPA reference survives the SMA/CPA integration."""
import copy
import json
from pathlib import Path
import unittest

import numpy as np

from tdm_jmp import _validate_jsl, build_jsl
from tdm_least_squares import _trial_deadline, fit_parameter_specs
from tdm_minimal_io import (apply_batch_shared_parameters, batch_row_to_run_config,
                            load_batch_rows, validate_config)
from tdm_minimal_model import simulate


ROOT = Path(__file__).resolve().parents[1]
PRESET = ROOT / "archived_inputs" / "tdm_cpa_inputs_r28.json"
RUNS = ROOT / "archived_inputs" / "tdm_cpa_batch_runs_r28.csv"


class CPARestorationTests(unittest.TestCase):
    def test_preset_ui_and_fitting(self):
        shared = json.loads(PRESET.read_text())
        run = load_batch_rows(RUNS)[0]
        config, _ = apply_batch_shared_parameters(shared, batch_row_to_run_config(run))
        self.assertEqual(validate_config(config, strict=True), [])
        self.assertEqual(config["model"], "TDM_CPA")
        self.assertAlmostEqual(config["feed"]["load_density_mg_mL_resin"], 90.0)
        self.assertAlmostEqual(config["components"][0]["Z_ref"], 80.45)
        self.assertAlmostEqual(config["components"][0]["delta_ref"], 10**-1.90)
        self.assertEqual({s.path for s in fit_parameter_specs(config)},
                         {"components[0].Z_ref", "components[0].delta_ref"})
        config["least_squares"]["max_trial_minutes"] = 1.0
        self.assertIsNone(_trial_deadline(config))
        jsl = build_jsl(shared)
        _validate_jsl(jsl)
        self.assertIn("TDM – CPA", jsl)
        self.assertIn("TDM – Steric Mass Action", jsl)
        self.assertIn("legacyRequiresReview = 0;", jsl)

    def test_r28_predicted_chromatogram_is_retained(self):
        shared = json.loads(PRESET.read_text())
        run = load_batch_rows(RUNS)[0]
        config, _ = apply_batch_shared_parameters(shared, batch_row_to_run_config(run))
        config = copy.deepcopy(config)
        config["numerics"].update(axial_positions=8, time_steps=175)
        result = simulate(config)
        trace = result["trace"]
        idx = int(np.argmax(trace["uv_mAU"]))
        # Independently recorded R28 output for this same reduced-grid run.
        self.assertAlmostEqual(float(trace["volume_mL"][idx]), 23.0037706934, places=3)
        self.assertAlmostEqual(float(trace["uv_mAU"][idx]), 478.6553815874, places=1)
        self.assertLess(abs(result["mass_balance"]["mAb1"]["closure_error_percent_of_input"]), 1.0)


if __name__ == "__main__":
    unittest.main()
