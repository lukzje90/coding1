TDM CHROMATOGRAPHY MODEL — R31 (26 November 2026)

SUPPORTED MODELS
• TDM – Competitive Langmuir (HIC)
• TDM – CPA (ion exchange, CEX setup)
• TDM – Modified Wang (HIC)
• TDM – Steric Mass Action (ion exchange, CEX setup)

The SMA option follows CADET-Core's steric mass action binding equation,
coupled to the existing transport dispersive column with interstitial and pore
liquid balances. It supports kinetic and quasi-stationary binding, protein
competition, monovalent salt displacement and steric shielding. It does not
reuse CPA fitted parameters.

The CPA option restores the CADET-style TDM + CPA solver from R28, including
its charge regulation, surface crowding, lateral charge, kinetic binding,
prescribed pore ionic strength, and CPA-specific LSQ controls. R28's Poros 50
HS mAb starting values and matching normal-batch Run 1 are in
archived_inputs/tdm_cpa_inputs_r28.json and
archived_inputs/tdm_cpa_batch_runs_r28.csv. To try them, extract the
ZIP, make a copy of its folder, and in that copy replace tdm_inputs.json and
tdm_batch_runs.csv with the two starter files, using those destination names.
Then open the JMP launcher and simulate Run 1. These values are specific to
the Poros 50 HS example and are not defaults for other resins or proteins.
The saved CPA starting values include: resin ligand density 2.89 µmol/m²,
ligand pK 2.3, protein radius 5.5 nm, accessible area 0.22 nm⁻¹,
Z_ref 80.45 at pH 5.0, Z_lat 19.07, Δ_ref 10⁻¹·⁹, and k*kin 4.61×10⁷ s⁻¹.
Run 1 uses 12.7 mg/mL feed, 90 g/L column load, 5 CV wash and an increasing
0–0.45 M NaCl gradient. The saved molecular weight is 150 kDa for mass/molar
conversion; it does not set the CPA adsorption radius.
This restores R28's CPA prediction; its published experimental wash-transition
spike remains underpredicted, so the starter is not a full experimental fit.

START
1. Extract the complete ZIP into one folder.
2. Open 00_RUN_CHROMATOGRAPHY_MODEL_IN_JMP.jsl in JMP and press Ctrl+R.
3. Choose TDM – Steric Mass Action under Model Parameters for CEX. Enter
   measured molecular weights, the SMA and transport parameters, buffers and
   stages; then review the selected run before simulating.

The active tdm_inputs.json and Run 1 in tdm_batch_runs.csv are a Poros XS
SMA benchmark at pH 6.0, using the system and binding parameters published
by Briskot et al. (2021). Run 1 in tdm_lsq_process_runs.csv points to this
same normal-batch method; its experimental chromatogram field is intentionally
empty. Select Run 1 and simulate to see the predicted chromatogram. The
benchmark_scenarios/ folder also contains a CADET-Core four-component
numerical reference. These are examples, not calibrated values for your resin
or protein.

The previous CPA/CEX setup and run tables remain in archived_inputs/ for
reference. CPA and SMA have different parameter meanings. A saved TDM + CPA
project now opens with CPA selected; review its resin and run values before
using results. Saved EDM and Xu–Lenhoff projects still need migration.

To transfer an existing HIC project, copy tdm_inputs.json,
tdm_batch_runs.csv, tdm_lsq_process_runs.csv and tdm_lsq_fraction_mass.csv
into this extracted folder. For an existing CEX/CPA project, copy its saved
input JSON and run tables into a separate extracted R31 folder. Use the CPA
option for its CPA parameters; enter and fit new SMA parameters if switching
that project to SMA.

The model writes simulation, least-squares and method-optimisation results
beside these files. Previous results are marked stale by the R31 build ID.
See SMA_IMPLEMENTATION_AND_BENCHMARK.md for the benchmark result, source,
and which transport and run settings had to be assumed.
