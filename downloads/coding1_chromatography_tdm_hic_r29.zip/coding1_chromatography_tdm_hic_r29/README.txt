TDM CHROMATOGRAPHY MODEL — R29 (26 November 2026)

SUPPORTED MODELS
• TDM – Competitive Langmuir (HIC)
• TDM – Modified Wang (HIC)

TDM – CPA has been removed from selection, simulation and fitting. A saved
TDM_CPA model is rejected with a migration message. Its fitted CEX parameters
cannot be transferred to the remaining HIC binding models.

START
1. Extract the complete ZIP into one folder.
2. Open 00_RUN_CHROMATOGRAPHY_MODEL_IN_JMP.jsl in JMP and press Ctrl+R.
3. Select a model under Model Parameters, enter or import its calibrated
   parameters, and review the process and run table before simulating.

The active tdm_inputs.json and run table contain an illustrative Modified Wang
HIC method. These values are demonstration inputs, not fitted parameters.
The previous CPA/CEX model setup, normal run table, LSQ run table and fraction
table are preserved unchanged under archived_inputs/ for reference.

To transfer your own HIC setup from an older release, copy tdm_inputs.json,
tdm_batch_runs.csv, tdm_lsq_process_runs.csv and tdm_lsq_fraction_mass.csv into
this extracted folder. Do not copy a CPA/CEX project as an active setup.

The model writes simulation, least-squares and method-optimisation results
beside these files. Previous results are marked stale by the R29 build ID.
See WANG_IMPLEMENTATION_AND_USAGE.md and UPDATE_EXISTING_PROJECT_R29.txt.
