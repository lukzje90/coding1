"""Release checks for the two supported HIC binding models."""
import copy
import math
import unittest

from tdm_jmp import _validate_jsl, build_jsl
from tdm_least_squares import fit_parameter_specs
from tdm_minimal_io import (
    MODEL_TDM_CPA, MODEL_TDM_LANGMUIR, MODEL_TDM_WANG,
    MODELS, SELECTABLE_MODELS, apply_batch_shared_parameters,
    batch_row_to_run_config, load_batch_rows, load_config, validate_config,
)
from tdm_minimal_model import simulate


class SupportedModelsR29Tests(unittest.TestCase):
    def test_selector_and_legacy_project_guard(self):
        self.assertEqual(MODELS, {MODEL_TDM_LANGMUIR, MODEL_TDM_WANG})
        self.assertEqual(set(SELECTABLE_MODELS), MODELS)
        current = load_config()
        current_jsl = build_jsl(current)
        _validate_jsl(current_jsl)
        selector = current_jsl.split('modelBox = Combo Box(', 1)[1].split('}', 1)[0]
        self.assertNotIn('CPA', selector)

        legacy = copy.deepcopy(current)
        legacy['model'] = MODEL_TDM_CPA
        legacy['chromatography_mode'] = 'ION_EXCHANGE'
        self.assertIn('has been removed', ' '.join(validate_config(legacy, strict=True)))
        with self.assertRaisesRegex(ValueError, 'has been removed'):
            simulate(legacy)
        with self.assertRaisesRegex(ValueError, 'has been removed'):
            fit_parameter_specs(legacy)
        old_jsl = build_jsl(legacy)
        _validate_jsl(old_jsl)
        self.assertIn('legacyRequiresReview = 1;', old_jsl)

    def test_supplied_hic_run_simulates_with_both_remaining_models(self):
        shared = load_config()
        run = batch_row_to_run_config(load_batch_rows()[0])
        self.assertEqual(shared['chromatography_mode'], 'HIC')
        for binding in SELECTABLE_MODELS:
            selected = copy.deepcopy(shared)
            selected['model'] = binding
            candidate, _ = apply_batch_shared_parameters(selected, run)
            with self.subTest(binding=binding):
                self.assertEqual(validate_config(candidate, strict=True), [])
                result = simulate(candidate)
                uv = result['trace']['uv_mAU']
                self.assertGreater(max(uv), 0)
                self.assertTrue(all(math.isfinite(value) for value in uv))
