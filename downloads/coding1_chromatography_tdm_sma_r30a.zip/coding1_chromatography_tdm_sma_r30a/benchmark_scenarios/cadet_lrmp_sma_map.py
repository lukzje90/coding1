"""Map CADET-Core's four-component LRMP/SMA reference into this TDM recipe.

Reference: CADET-Core test/data/ref_LRMP_reqSMA_4comp_sensbenchmark1_DG_P3Z8.h5,
CADET 4.4.0 commit 33d8e85f44e66310e994b97110169e9c47c6d358.
Use 1 kDa as a mathematical mass conversion: 1 mol/m3 is then 1 g/L.
This is a numerical benchmark, not a protein molecular-weight claim.
"""
import json
import math
from pathlib import Path

base=Path(__file__).with_name('tdm_sma_illustrative.json')
x=json.loads(base.read_text())
area=math.pi*0.01**2
length=0.014
volume_mL=area*length*1e6
epsv=0.37
velocity=0.000575
flow_mL_min=velocity*area*epsv*60*1e6
cv_per_second=flow_mL_min/60/volume_mL
x['model']='TDM_SMA';x['chromatography_mode']='ION_EXCHANGE'
x['impurity_count']=2
x['column'].update(volume_mL=volume_mL,length_mm=length*1000,flow_mL_min=flow_mL_min)
x['tdm'].update(bead_radius_um=45.0,void_fraction=epsv,particle_porosity=0.75)
x['feed'].update(total_concentration_mg_mL=3.0,load_density_mg_mL_resin=3.0*10*cv_per_second)
x['numerics'].update(time_steps=1500,axial_positions=32)
x['system'].update(buffer_dispersion_mL=0.0,salt_dispersion_mm2_s=0.0575,
                   uv_dead_volume_mL=0.0,conductivity_dead_volume_mL=0.0)
x['conversion'].update(conductivity_to_salt_M_per_mS_cm=0.01,uv_to_protein_mAU_L_g=200.0)
x['sma'].update(lambda_mol_m3=1200.0,salt_k_eff_um_s=6.9,
                c_ref_mol_m3=1.0,q_ref_mol_m3=1.0,is_kinetic=False)
for i,(ka,kd,nu,sigma) in enumerate(zip([35.5,1.59,7.7],[1000.0]*3,[4.7,5.29,3.7],[11.83,10.6,10.0])):
 row=x['components'][i]
 row.update(name=['Protein 1','Protein 2','Protein 3'][i],mass_percent=(100/3 if i<2 else 100-200/3),
            uv_response_factor_mAU_L_g=(200.0 if i else None),D_ax_mm2_s=0.0575,
            k_eff_um_s=6.9,accessible_particle_porosity=0.75,molecular_weight_kDa=1.0,
            sma_ka_s=ka,sma_kd_s=kd,sma_nu=nu,sma_sigma=sigma)
p=x['process']
p.update(load_amount_basis='LOAD_VOLUME',load_CV=10*cv_per_second,
         load_volume_mL=flow_mL_min*10/60,load_start_percent_B=0.0,
         load_end_percent_B=0.0,load_source='BUFFER_A',
         equilibration_source='BUFFER_A',plw_count=1,elution_count=1)
p['buffer_A'].update(pH=6.0,salt_input_mode='SALT_M',salt_concentration_M=0.05,
                     conductivity_mS_cm=5.0,ionic_strength_source='SALT_PROXY')
p['buffer_B'].update(pH=6.0,salt_input_mode='SALT_M',salt_concentration_M=0.382,
                     conductivity_mS_cm=38.2,ionic_strength_source='SALT_PROXY')
p['plw_steps'][0].update(mode='SET_POINT',CV=80*cv_per_second,flow_mL_min=flow_mL_min,
                         chemistry_control='BUFFER_B_PERCENT',start_percent_B=0.0,end_percent_B=0.0)
p['elution_steps'][0].update(mode='LINEAR',CV=1410*cv_per_second,flow_mL_min=flow_mL_min,
                             chemistry_control='ENDPOINT_CHEMISTRY',start_source='DIRECT',
                             start_pH=6.0,start_salt_input_mode='SALT_M',
                             start_salt_concentration_M=0.1,start_conductivity_mS_cm=10.0,
                             end_source='DIRECT',end_pH=6.0,end_salt_input_mode='SALT_M',
                             end_salt_concentration_M=0.382,end_conductivity_mS_cm=38.2)
Path(__file__).with_name('cadet_lrmp_sma_mapped.json').write_text(json.dumps(x,indent=2))
print('CV_mL',volume_mL,'flow_mL_min',flow_mL_min,'CV/s',cv_per_second)
