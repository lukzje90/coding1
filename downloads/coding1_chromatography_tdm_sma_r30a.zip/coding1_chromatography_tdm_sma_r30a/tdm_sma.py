"""CADET-Core steric mass action binding in the existing TDM column balance.

Salt is component zero. Concentrations are mol/m3 in their respective mobile
or stationary phase volumes. Bound salt is eliminated by electroneutrality;
its time derivative is included in the pore-salt balance.
"""
from __future__ import annotations

import math
import numpy as np
from scipy.integrate import solve_ivp
from scipy.sparse import lil_matrix

from tdm_minimal_io import active_components
from tdm_mobile_phase import MobilePhaseTransport


def sma_rate(cp: np.ndarray, q: np.ndarray, salt_cp: np.ndarray, *,
             ka: np.ndarray, kd: np.ndarray, nu: np.ndarray, sigma: np.ndarray,
             capacity: float, c_ref: float, q_ref: float) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """CADET SMA rate and algebraic salt/available-site concentrations.

    CADET's monovalent salt convention sets nu_0 = 1. The output is
    dq_i/dt, q_0 = Lambda - sum(nu_i q_i), qbar_0 = q_0 - sum(sigma_i q_i).
    """
    cp = np.asarray(cp, dtype=float)
    q = np.asarray(q, dtype=float)
    salt_cp = np.asarray(salt_cp, dtype=float)
    q0 = capacity - np.sum(nu * q, axis=-1)
    free = capacity - np.sum((nu + sigma) * q, axis=-1)
    if np.min(free) < -max(1e-7, capacity * 1e-3):
        raise ValueError("SMA bound protein exceeds available ionic/steric sites.")
    if np.min(q0) < -max(1e-7, capacity * 1e-3):
        raise ValueError("SMA bound counterion concentration is negative.")
    free_ratio = np.maximum(free, 0.0)[..., None] / q_ref
    salt_ratio = np.maximum(salt_cp, 0.0)[..., None] / c_ref
    try:
        with np.errstate(over="raise", invalid="raise"):
            rate = ka * np.maximum(cp, 0.0) * free_ratio ** nu - kd * q * salt_ratio ** nu
    except FloatingPointError as exc:
        raise ValueError("SMA rate overflow: check rate constants, characteristic charges and reference concentrations.") from exc
    return rate, q0, free


def sma_equilibrium_from_totals(total_protein: np.ndarray, total_salt: np.ndarray, *,
                                ka: np.ndarray, kd: np.ndarray, nu: np.ndarray,
                                sigma: np.ndarray, beta: np.ndarray, beta_salt: float,
                                capacity: float, c_ref: float, q_ref: float
                                ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Solve CADET's quasi-stationary SMA equations using one monotone local root.

    Total_i = c_p,i + beta_i q_i and Total_0 = c_p,0 + beta_0 q_0.
    The root is the ratio (qbar/q_ref)/(c_p,0/c_ref); competition and salt
    displacement remain coupled rather than prescribing a salt profile.
    """
    total_protein = np.maximum(np.asarray(total_protein, dtype=float), 0.0)
    total_salt = np.asarray(total_salt, dtype=float)
    k = np.asarray(ka, dtype=float) / np.asarray(kd, dtype=float)
    log_k = np.where(k > 0, np.log(np.maximum(k, 1e-300)), -np.inf)

    def values(log_ratio: np.ndarray):
        log_a = log_k[None, :] + np.asarray(log_ratio)[:, None] * nu[None, :]
        inv_a = np.exp(np.clip(-log_a, -700.0, 700.0))
        denominator = beta[None, :] + inv_a
        q = total_protein / denominator
        # Recover the free pore concentration from its positive equilibrium
        # fraction. Subtracting beta*q from total_protein loses all significant
        # digits when almost all protein is bound (the case behind a flat UV
        # trace), even though a small positive free concentration remains.
        cp = total_protein * (inv_a / denominator)
        q0 = capacity - np.sum(nu[None, :] * q, axis=1)
        free = capacity - np.sum((nu + sigma)[None, :] * q, axis=1)
        cp_salt = total_salt - beta_salt * q0
        residual = free / q_ref - np.exp(np.clip(log_ratio, -700.0, 700.0)) * cp_salt / c_ref
        return residual, cp, q, q0, free, cp_salt

    cells = len(total_salt)
    lower = np.full(cells, -60.0)
    upper = np.full(cells, 60.0)
    # The upper limit corresponds to complete uptake when salt is zero.
    upper_residual = values(upper)[0]
    no_finite_root = upper_residual > 0.0
    for _ in range(55):
        middle = 0.5 * (lower + upper)
        positive = values(middle)[0] > 0.0
        lower = np.where(positive, middle, lower)
        upper = np.where(positive, upper, middle)
    _, cp, q, q0, free, cp_salt = values(0.5 * (lower + upper))
    if np.any(no_finite_root):
        q_limit = total_protein / beta[None, :]
        cp[no_finite_root] = 0.0
        q[no_finite_root] = q_limit[no_finite_root]
        q0[no_finite_root] = capacity - np.sum(nu * q[no_finite_root], axis=1)
        free[no_finite_root] = capacity - np.sum((nu + sigma) * q[no_finite_root], axis=1)
        cp_salt[no_finite_root] = total_salt[no_finite_root] - beta_salt * q0[no_finite_root]
    if np.min(cp_salt) < -max(1e-6, capacity * 1e-4) or np.min(free) < -max(1e-6, capacity * 1e-4):
        raise ValueError("SMA quasi-stationary state is outside the salt/site balance domain.")
    return np.maximum(cp, 0.0), np.maximum(q, 0.0), np.maximum(cp_salt, 0.0), q0, free


def simulate_tdm_sma(config: dict) -> dict:
    # Imported here to keep the common TDM model independent of SMA internals.
    from tdm_minimal_model import (_build_program, _column_geometry,
                                   _numerical_resolution, _scalar_transport)

    rows = active_components(config)
    n = len(rows)
    names = [str(row['name']) for row in rows]
    mw = np.array([float(row['molecular_weight_kDa']) for row in rows])
    fractions = np.array([float(row['mass_percent']) / 100.0 for row in rows])
    feed_mol_m3 = float(config['feed']['total_concentration_mg_mL']) * fractions / mw
    program = _build_program(config, feed_mol_m3)
    mobile_phase = MobilePhaseTransport(config, program, _scalar_transport)
    L, _, area = _column_geometry(config)
    epsv = float(config['tdm']['void_fraction'])
    epsp = float(config['tdm']['particle_porosity'])
    radius = float(config['tdm']['bead_radius_um']) * 1e-6
    sma = config['sma']
    kinetic = bool(sma['is_kinetic'])
    capacity = float(sma['lambda_mol_m3'])
    cref = float(sma['c_ref_mol_m3'])
    qref = float(sma['q_ref_mol_m3'])
    ka = np.array([float(row['sma_ka_s']) for row in rows])
    kd = np.array([float(row['sma_kd_s']) for row in rows])
    nu = np.array([float(row['sma_nu']) for row in rows])
    sigma = np.array([float(row['sma_sigma']) for row in rows])
    dax = np.array([float(row['D_ax_mm2_s']) * 1e-6 for row in rows])
    transfer_coeff = 3.0 / radius * np.array([float(row['k_eff_um_s']) * 1e-6 for row in rows])
    epspi = np.array([float(row['accessible_particle_porosity']) for row in rows])
    beta = (1.0 - epsp) / epspi
    beta_salt = (1.0 - epsp) / epsp
    salt_transfer_coeff = 3.0 / radius * float(sma['salt_k_eff_um_s']) * 1e-6
    salt_dax = float(config['system']['salt_dispersion_mm2_s']) * 1e-6 if config['system']['salt_dispersion_enabled'] else 0.0
    time_steps, nx = _numerical_resolution(config)
    dx = L / nx
    size = nx * n
    init_salt = float(mobile_phase.initial_chemistry_state[1]) * 1000.0

    if kinetic:
        # Bulk proteins, pore proteins, bound proteins, bulk salt, pore salt.
        y0 = np.concatenate((np.zeros(3 * size), np.full(nx, init_salt), np.full(nx, init_salt)))
        def unpack(y):
            return (y[:size].reshape(nx, n), y[size:2*size].reshape(nx, n),
                    y[2*size:3*size].reshape(nx, n), y[3*size:3*size+nx],
                    y[3*size+nx:3*size+2*nx])
    else:
        # Protein and salt particle totals include the algebraically bound phase.
        y0 = np.concatenate((np.zeros(size), np.zeros(size), np.full(nx, init_salt),
                             np.full(nx, init_salt + beta_salt * capacity)))
        def unpack(y):
            cb = y[:size].reshape(nx, n)
            total_protein = y[size:2*size].reshape(nx, n)
            cb_salt = y[2*size:2*size+nx]
            total_salt = y[2*size+nx:2*size+2*nx]
            cp, q, cp_salt, q0, free = sma_equilibrium_from_totals(
                total_protein, total_salt, ka=ka, kd=kd, nu=nu, sigma=sigma,
                beta=beta, beta_salt=beta_salt, capacity=capacity,
                c_ref=cref, q_ref=qref)
            return cb, cp, q, cb_salt, cp_salt

    state_count = len(y0)
    sparsity = lil_matrix((state_count, state_count), dtype=int)
    # Include all local variables in every local row. This is conservative for
    # finite-difference Jacobians and avoids a dense column-wide factorization.
    for cell in range(nx):
        local = [cell*n+i for i in range(n)]
        local += [size+cell*n+i for i in range(n)]
        if kinetic:
            local += [2*size+cell*n+i for i in range(n)]
            local += [3*size+cell, 3*size+nx+cell]
        else:
            local += [2*size+cell, 2*size+nx+cell]
        for row in local:
            sparsity[row, local] = 1
        for species in range(n):
            row = cell*n+species
            for neighbor in range(max(0,cell-2),min(nx,cell+3)):
                sparsity[row, neighbor*n+species] = 1
        salt_row = (3*size if kinetic else 2*size)+cell
        for neighbor in range(max(0,cell-2),min(nx,cell+3)):
            sparsity[salt_row, (3*size if kinetic else 2*size)+neighbor] = 1

    def inlet_salt_M(t):
        if config['system']['buffer_dispersion_enabled'] and float(config['system']['buffer_dispersion_mL']) > 0.0:
            return float(mobile_phase._state(t)[1])
        return float(program.chemistry_at_cv(program.time_to_cv(t))[1])

    def rhs(t, y):
        cb, cp, q, cb_salt, cp_salt = unpack(y)
        inlet, _, _, _ = program.at_time(t)
        flow_m3_s = program.flow_at_time(t) * 1e-6 / 60.0
        velocity = flow_m3_s / (area * epsv)
        protein_transfer = transfer_coeff[None, :] * (cb - cp)
        salt_transfer = salt_transfer_coeff * (cb_salt - cp_salt)
        dcb = np.empty_like(cb)
        for i in range(n):
            dcb[:, i] = (_scalar_transport(cb[:, i], inlet[i], velocity, dax[i], dx)
                         - (1.0-epsv)/epsv * protein_transfer[:, i])
        dcb_salt = (_scalar_transport(cb_salt, inlet_salt_M(t)*1000.0,
                                      velocity, salt_dax, dx)
                    - (1.0-epsv)/epsv * salt_transfer)
        if kinetic:
            dq, _, _ = sma_rate(cp, q, cp_salt, ka=ka, kd=kd, nu=nu,
                               sigma=sigma, capacity=capacity, c_ref=cref, q_ref=qref)
            dcp = (protein_transfer - (1.0-epsp)*dq)/epspi[None, :]
            dcp_salt = (salt_transfer + (1.0-epsp)*np.sum(nu*dq, axis=1))/epsp
            return np.concatenate((dcb.ravel(),dcp.ravel(),dq.ravel(),dcb_salt,dcp_salt))
        dtotal_protein = protein_transfer/epspi[None, :]
        dtotal_salt = salt_transfer/epsp
        return np.concatenate((dcb.ravel(),dtotal_protein.ravel(),dcb_salt,dtotal_salt))

    solution = solve_ivp(rhs,(0.0,program.total_time_s),y0,method='BDF',
                         rtol=1e-6,atol=1e-8,dense_output=True,
                         max_step=max(program.total_time_s/max(time_steps,1),1e-6),
                         jac_sparsity=sparsity.tocsr())
    if not solution.success:
        raise RuntimeError('TDM–SMA integration failed: '+solution.message)
    times = np.linspace(0.0,program.total_time_s,time_steps+1)
    sampled = solution.sol(times)
    outlet = np.empty((len(times),n))
    salt_out = np.empty(len(times))
    salt_pore_out = np.empty(len(times))
    q0_out = np.empty(len(times))
    free_out = np.empty(len(times))
    for k in range(len(times)):
        cb,cp,q,cb_salt,cp_salt = unpack(sampled[:,k])
        outlet[k] = cb[-1]
        salt_out[k] = cb_salt[-1]/1000.0
        salt_pore_out[k] = cp_salt[-1]/1000.0
        q0_out[k] = capacity-np.sum(nu*q[-1])
        free_out[k] = capacity-np.sum((nu+sigma)*q[-1])
    cb,cp,q,cb_salt,cp_salt = unpack(solution.y[:,-1])
    cell_volume_m3 = area*dx
    inventory_mol = cell_volume_m3*np.sum(
        epsv*cb+(1.0-epsv)*(epspi[None,:]*cp+(1.0-epsp)*q),axis=0)
    raw_outlet = np.array([unpack(solution.y[:,k])[0][-1] for k in range(solution.y.shape[1])])
    q0_final = capacity-np.sum(nu*q,axis=1)
    initial_salt_inventory_mol = cell_volume_m3*nx*(
        epsv*init_salt+(1.0-epsv)*(epsp*init_salt+(1.0-epsp)*capacity))
    final_salt_inventory_mol = cell_volume_m3*np.sum(
        epsv*cb_salt+(1.0-epsv)*(epsp*cp_salt+(1.0-epsp)*q0_final))
    flow_L_s = program.flow_array_L_s(times)
    inlet_salt_mol_L = np.array([inlet_salt_M(float(t)) for t in times])
    integrate = getattr(np, 'trapezoid', None)
    if integrate is None:
        integrate = getattr(np, 'trapz')
    salt_in_mol = float(integrate(inlet_salt_mol_L*flow_L_s,times))
    salt_out_mol = float(integrate(salt_out*flow_L_s,times))
    salt_error_mol = initial_salt_inventory_mol+salt_in_mol-salt_out_mol-final_salt_inventory_mol
    return {
        'program':program,'mobile_phase':mobile_phase,
        'component_names':names,'component_mw_kDa':mw,
        'column_time_s':times,'column_component_native':outlet,
        'column_salt_M':salt_out,'column_pore_salt_M':salt_pore_out,
        'column_bound_counterion_mol_m3':q0_out,
        'column_free_sites_mol_m3':free_out,
        'mass_balance_time_s':solution.t,
        'mass_balance_component_native':raw_outlet,
        'final_inventory_native':inventory_mol,'native_basis':'mol/m3',
        'diagnostics':{
            'transport_model':'TDM','isotherm':'CADET Steric Mass Action',
            'sma_mode':'KINETIC' if kinetic else 'QUASI_STATIONARY',
            'sma_lambda_mol_m3':capacity,'sma_c_ref_mol_m3':cref,
            'sma_q_ref_mol_m3':qref,'sma_salt_film_transfer_um_s':float(sma['salt_k_eff_um_s']),
            'sma_nu':nu.tolist(),'sma_sigma':sigma.tolist(),
            'sma_salt_component':'monovalent counterion; algebraic bound salt and coupled mobile/pore balances',
            'sma_salt_balance':{
                'initial_inventory_mol':float(initial_salt_inventory_mol),
                'input_mol':salt_in_mol,'outlet_mol':salt_out_mol,
                'final_inventory_mol':float(final_salt_inventory_mol),
                'closure_error_mol':float(salt_error_mol),
                'closure_error_percent_of_input':float(100*salt_error_mol/salt_in_mol) if salt_in_mol>0 else None,
            },
            'sma_min_free_sites_mol_m3':float(np.min(free_out)),
            'sma_min_bound_counterion_mol_m3':float(np.min(q0_out)),
            'axial_cells':nx,'requested_time_steps':time_steps,
            'internal_time_steps':len(solution.t)-1,
        },
    }
