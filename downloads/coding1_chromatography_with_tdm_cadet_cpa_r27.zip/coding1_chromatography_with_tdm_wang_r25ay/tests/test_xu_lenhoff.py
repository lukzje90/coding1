"""CADET-Core colloidal residual, UI handoff and TDM integration checks."""

import json
import math
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

import tdm_bridge
import tdm_least_squares as lsq
from tdm_jmp import _validate_jsl, build_jsl
from tdm_minimal_io import MODEL_LABELS, MODEL_TDM_XU_LENHOFF, load_config, required_parameter_paths, validate_config
from tdm_minimal_model import simulate
from tdm_xu_lenhoff import R_FACTOR, rate
from verify_model import make_config


def config(n_imp=0):
    cfg = make_config(MODEL_TDM_XU_LENHOFF, n_imp, multistep=False)
    cfg["numerics"].update(time_steps=50, axial_positions=5)
    for i, row in enumerate(cfg["components"][:n_imp + 1]):
        row["molecular_weight_kDa"] = 150.0 + 10 * i
    return cfg


class XuLenhoffTests(unittest.TestCase):
    def test_rate_matches_cadet_core_colloidal_residual(self):
        cfg = config(1)
        rows = cfg["components"][:2]
        rows[0].update(xl_protein_radius_nm=5.5, xl_kinetic_rate_s=2.0,
                       xl_logkeq_power_factor=100.0, xl_bpp_power_factor=1.0)
        rows[1].update(xl_protein_radius_nm=7.0, xl_kinetic_rate_s=3.0,
                       xl_logkeq_power_factor=90.0, xl_bpp_power_factor=1.3)
        shared = cfg["xu_lenhoff"]
        cp = np.array([0.2, 0.08])
        q = np.array([0.5, 0.3])
        salt_M = 0.05
        cs = salt_M * 1000.0
        kappa = 1.0 / shared["kappa_constant"]
        distance = math.sqrt(R_FACTOR * shared["phase_ratio_m_inv"] / sum(q))
        sfactor = shared["coordination_number"] * 0.125 / sum(q) * (3 / distance + kappa)
        expected = []
        for i, row_i in enumerate(rows):
            ri = row_i["xl_protein_radius_nm"] * 1e-9
            interaction = 0.0
            for j, row_j in enumerate(rows):
                rj = row_j["xl_protein_radius_nm"] * 1e-9
                interaction += (q[j] * math.sqrt(row_i["xl_bpp_power_factor"] * row_j["xl_bpp_power_factor"])
                                * (ri + rj) * math.exp(-kappa * (distance - ri - rj)))
            log_keq = row_i["xl_logkeq_power_factor"] / cs
            expected.append(row_i["xl_kinetic_rate_s"] *
                            (cp[i] - q[i] * math.exp(interaction * sfactor - log_keq)))
        np.testing.assert_allclose(rate(cp, q, salt_M, 6.0, shared, rows), expected, rtol=1e-12)
        np.testing.assert_allclose(rate(cp, np.zeros(2), salt_M, 6.0, shared, rows),
                                   [0.4, 0.24], rtol=1e-12)

    def test_c_exchanger_only_and_lsq_parameter_catalog(self):
        cfg = config()
        self.assertEqual(validate_config(cfg, strict=True), [])
        paths = set(required_parameter_paths(cfg))
        self.assertIn("xu_lenhoff.phase_ratio_m_inv", paths)
        self.assertIn("xu_lenhoff.use_ph", paths)
        self.assertIn("components[0].xl_bpp_power_factor", paths)
        self.assertNotIn("components[0].xl_logkeq_ph_exponent", paths)
        self.assertEqual(lsq.fit_parameter_specs(cfg, unlocked_paths=[
            "components[0].xl_logkeq_ph_exponent"]), [])
        cfg["xu_lenhoff"]["use_ph"] = True
        self.assertIn("components[0].xl_logkeq_ph_exponent", required_parameter_paths(cfg))
        self.assertEqual([spec.path for spec in lsq.fit_parameter_specs(cfg, unlocked_paths=[
            "components[0].xl_logkeq_ph_exponent"])],
            ["components[0].xl_logkeq_ph_exponent"])
        self.assertNotIn("cpa.ligand_surface_density_umol_m2", paths)
        specs = lsq.fit_parameter_specs(cfg, unlocked_paths=[
            "components[0].xl_logkeq_power_factor", "components[0].xl_bpp_power_factor",
            "components[0].delta_ref", "xu_lenhoff.coordination_number",
        ])
        self.assertEqual({s.path for s in specs}, {
            "components[0].xl_logkeq_power_factor", "components[0].xl_bpp_power_factor"})
        cfg["chromatography_mode"] = "HIC"
        self.assertTrue(any("ion-exchange" in e for e in validate_config(cfg, strict=True)))

    def test_salt_and_ph_change_binding_in_expected_direction(self):
        cfg = config()
        row = cfg["components"][0]
        shared = cfg["xu_lenhoff"]
        cp = np.array([0.2])
        q = np.array([0.4])
        low_salt = rate(cp, q, 0.05, 6.0, shared, [row])[0]
        high_salt = rate(cp, q, 0.5, 6.0, shared, [row])[0]
        self.assertGreater(low_salt, high_salt)
        row["xl_logkeq_ph_exponent"] = 1.0
        row["xl_bpp_ph_exponent"] = 1.0
        self.assertAlmostEqual(rate(cp, q, 0.1, 5.0, shared, [row])[0],
                               rate(cp, q, 0.1, 7.0, shared, [row])[0])
        shared["use_ph"] = True
        low_ph = rate(cp, q, 0.1, 5.0, shared, [row])[0]
        high_ph = rate(cp, q, 0.1, 7.0, shared, [row])[0]
        self.assertNotAlmostEqual(high_ph, low_ph)

    def test_jmp_parameter_handoff_and_area_conversion(self):
        cfg = config()
        jsl = build_jsl(cfg)
        _validate_jsl(jsl)
        self.assertIn(MODEL_LABELS[MODEL_TDM_XU_LENHOFF], jsl)
        self.assertIn('xlPhaseRatio = Number Edit Box(200, 9', jsl)
        self.assertIn('Python Name("tdm_ui_xl_phase_ratio_m_inv")', jsl)
        self.assertIn('Python Name("tdm_ui_xl_use_ph")', jsl)
        self.assertIn('Python Name("tdm_ui_c1_xl_logkeq_power_factor")', jsl)
        sent = {
            "tdm_ui_model": MODEL_LABELS[MODEL_TDM_XU_LENHOFF],
            "tdm_ui_chromatography_mode": "ION_EXCHANGE",
            "tdm_ui_impurity_count": 0,
            "tdm_ui_xl_phase_ratio_m_inv": 210.0,
            "tdm_ui_xl_use_ph": "On",
            "tdm_ui_c1_xl_logkeq_power_factor": 85.0,
        }
        with patch.dict(tdm_bridge.__dict__, sent):
            received = tdm_bridge.build_shared_config_from_jmp()
        self.assertEqual(received["xu_lenhoff"]["phase_ratio_m_inv"], 210e6)
        self.assertIs(received["xu_lenhoff"]["use_ph"], True)
        self.assertEqual(received["components"][0]["xl_logkeq_power_factor"], 85.0)

    def test_legacy_ph_exponents_preserve_behavior_on_load(self):
        cfg = config()
        cfg["components"][0]["xl_logkeq_ph_exponent"] = 1.0
        cfg["xu_lenhoff"].pop("use_ph")
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "old.json"
            path.write_text(json.dumps(cfg), encoding="utf-8")
            restored = load_config(path)
        self.assertIs(restored["xu_lenhoff"]["use_ph"], True)

    def test_lsq_fitted_values_apply_to_visible_jmp_controls(self):
        cfg = config()
        cfg["xu_lenhoff"]["phase_ratio_m_inv"] = 210e6
        cfg["components"][0]["xl_logkeq_power_factor"] = 85.0
        specs = lsq.fit_parameter_specs(cfg, unlocked_paths=[
            "xu_lenhoff.phase_ratio_m_inv", "components[0].xl_logkeq_power_factor",
        ])
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "apply.jsl"
            with patch.object(lsq, "FIT_APPLY_JSL", path):
                lsq._write_apply_jsl(cfg, specs)
            script = path.read_text(encoding="utf-8")
        self.assertIn("xlPhaseRatio << Set(210);", script)
        self.assertIn("c1XL5 << Set(85);", script)

    def test_tdm_mass_balance(self):
        result = simulate(config(1))
        self.assertEqual(result["simulation"]["diagnostics"]["transport_model"], "TDM")
        for balance in result["mass_balance"].values():
            self.assertLess(abs(balance["closure_error_percent_of_input"]), 0.01)
        self.assertTrue(np.all(np.isfinite(result["trace"]["uv_mAU"])))

    def test_use_ph_switch_changes_tdm_output_and_keeps_mass_closed(self):
        cfg = config()
        cfg["components"][0]["xl_logkeq_ph_exponent"] = 1.0
        cfg["xu_lenhoff"]["use_ph"] = False
        no_ph = simulate(cfg)
        cfg["xu_lenhoff"]["use_ph"] = True
        with_ph = simulate(cfg)
        self.assertGreater(float(np.max(no_ph["trace"]["uv_mAU"])),
                           float(np.max(with_ph["trace"]["uv_mAU"])))
        for result in (no_ph, with_ph):
            self.assertLess(abs(result["mass_balance"]["Target protein"]
                                ["closure_error_percent_of_input"]), 0.01)


if __name__ == "__main__":
    unittest.main()
