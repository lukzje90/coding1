"""CPA molecular mass is an input/output conversion, independent of radius."""

import copy
import unittest
from unittest.mock import patch

import numpy as np

import tdm_bridge
from tdm_jmp import build_jsl
from tdm_minimal_io import (MAX_IMPURITIES, MODEL_LABELS, MODEL_TDM_CPA,
                            blank_config, normalize_config)
from tdm_minimal_model import _build_cpa_components, _cpa_model, simulate
from verify_model import make_config


class CPAMolecularMassHandoffTests(unittest.TestCase):
    def test_radius_is_the_independent_cpa_input(self):
        cfg = make_config(MODEL_TDM_CPA, 0, multistep=False)
        cfg["components"][0]["diameter_nm"] = 14.0  # CPA input is a_i = 7 nm.
        factors = []
        for mass in (75.0, 300.0):
            cfg["components"][0]["molecular_weight_kDa"] = mass
            components = _build_cpa_components(cfg, need_tdm_kinetics=True)
            self.assertAlmostEqual(components[0].radius_m, 7e-9, delta=1e-20)
            model = _cpa_model(cfg, components)
            factors.append(model.equilibrium_factors(np.array([0.0]), 5.0, 0.05)[0])
        self.assertEqual(factors[0], factors[1])

    def test_mass_reaches_feed_and_outlet_conversion(self):
        base = make_config(MODEL_TDM_CPA, 0, multistep=False)
        base["numerics"].update(axial_positions=6, time_steps=100)
        base["feed"]["load_density_mg_mL_resin"] = 0.5
        for mass in (75.0, 300.0):
            with self.subTest(molecular_weight_kDa=mass):
                cfg = copy.deepcopy(base)
                cfg["components"][0]["molecular_weight_kDa"] = mass
                result = simulate(cfg)
                sim = result["simulation"]
                expected_molar = float(cfg["feed"]["total_concentration_mg_mL"]) / mass
                self.assertAlmostEqual(sim["program"].stages[0].feed_vector[0], expected_molar)
                self.assertEqual(result["parameter_receipt"]["species_molecular_weight_kDa_used"]
                                 [cfg["components"][0]["name"]], mass)
                self.assertAlmostEqual(result["parameter_receipt"]
                                       ["derived_species_feed_concentration_mol_m3"]
                                       [cfg["components"][0]["name"]], expected_molar)
                np.testing.assert_allclose(
                    result["trace"]["column_component_g_L"][:, 0],
                    np.asarray(sim["column_component_native"])[:, 0] * mass,
                    rtol=2e-14, atol=1e-14,
                )

    def test_jmp_mass_and_old_project_component_slots(self):
        self.assertEqual(MAX_IMPURITIES, 7)
        old = blank_config()
        first_six = copy.deepcopy(old["components"][:6])
        old["components"] = first_six
        upgraded = normalize_config(old)
        self.assertEqual(len(upgraded["components"]), 8)
        self.assertEqual(upgraded["components"][:6], first_six)
        self.assertNotIn("system_specific_adsorption_parameter", upgraded["cpa"])
        jsl = build_jsl(upgraded)
        self.assertIn("Impurity 7", jsl)
        self.assertNotIn("systemAdsorption", jsl)
        mass_sends = [line.strip() for line in jsl.splitlines()
                      if 'Python Name("tdm_ui_c1_molecular_weight_kDa")' in line]
        self.assertEqual(len(mass_sends), 2)
        self.assertTrue(any(line.startswith('Python Send(c1MolecularWeight << Get,')
                            for line in mass_sends))
        self.assertTrue(any(line.startswith('If(Char(modelBox << Get Selected)')
                            and 'c1XL0 << Get' in line for line in mass_sends))
        for mass in (75.0, 300.0):
            with self.subTest(molecular_weight_kDa=mass):
                with patch.dict(tdm_bridge.__dict__, {
                    "tdm_ui_model": MODEL_LABELS[MODEL_TDM_CPA],
                    "tdm_ui_impurity_count": 0,
                    "tdm_ui_c1_molecular_weight_kDa": mass,
                }):
                    shared = tdm_bridge.build_shared_config_from_jmp()
                self.assertEqual(shared["components"][0]["molecular_weight_kDa"], mass)


if __name__ == "__main__":
    unittest.main()
