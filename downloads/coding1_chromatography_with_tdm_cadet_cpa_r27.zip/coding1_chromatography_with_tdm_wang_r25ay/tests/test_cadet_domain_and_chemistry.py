"""CADET development-documentation equations and *strict* CPA domain checks.

CADET source: https://cadet.github.io/master/modelling/binding/colloidal_particle_adsorption.html
These tests do not claim that the application's prescribed buffer chemistry
is identical to CADET's optional species-resolved proton transport.
"""
import copy
import math
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
from tdm_minimal_io import (
    MODEL_TDM_CPA, validate_config, sanitize_config_for_selected_model,
    save_config, load_config, apply_batch_shared_parameters, batch_shared_parameter_paths,
)
from tdm_minimal_model import (
    CPAModel, CPAInvalidStateError, N_A, E_CHARGE, _build_cpa_components, _cpa_model,
)
from verify_model import make_config


class CadetDomainChemistryTests(unittest.TestCase):
    def setUp(self):
        self.config = make_config(MODEL_TDM_CPA, 0, multistep=False)
        self.component = _build_cpa_components(self.config, need_tdm_kinetics=True)[0]
        self.model = _cpa_model(self.config, [self.component])

    def test_surface_coverage_at_and_over_one_is_invalid_not_silently_capped(self):
        c = self.component
        q_unit = c.As_m_inv / (math.pi * N_A * c.radius_m**2)
        for coverage in (1.0+1e-10, 1.01, 2.0):
            with self.subTest(coverage=coverage), self.assertRaisesRegex(ValueError, 'Theta < 1'):
                self.model.available_surface(0, np.array([coverage*q_unit]))
        self.assertTrue(self.model.available_surface(0, np.array([0.9*q_unit])) >= 0.0)

    def test_strict_invalid_ionic_strength_and_charge_domains(self):
        for ionic_mol_m3 in (0.0, -0.1, float('nan')):
            with self.subTest(I=ionic_mol_m3), self.assertRaises(ValueError):
                self.model.debye_kappa(ionic_mol_m3)
        self.component.Z_ref = 0.0
        with self.assertRaises(ValueError):
            self.model.equilibrium_factors(np.zeros(1), 5.0, 0.1)
        self.component.Z_ref = -30.0
        with self.assertRaises(ValueError):
            self.model.equilibrium_factors(np.zeros(1), 5.0, 0.1)

    def test_equal_opposite_surface_potentials_invalid_even_if_numerically_finite(self):
        m, c = self.model, self.component
        kappa = m.debye_kappa(30.0)
        psi_a = m._adsorber_surface_potential(5.0, kappa)
        with patch.object(m, '_protein_surface_potential', return_value=-psi_a):
            with self.assertRaisesRegex(ValueError, 'unequal magnitudes'):
                m._paper_adsorber_energy(c, 5.0, kappa, psi_a)
            with self.assertRaisesRegex(ValueError, 'magnitudes differ'):
                m.equilibrium_factors(np.zeros(1), 5.0, 0.03)

    def test_nearly_equal_potentials_have_stable_finite_energy(self):
        m, c = self.model, self.component
        kap = m.debye_kappa(30.0)
        psi_a = m._adsorber_surface_potential(5.0, kap)
        with patch.object(m, '_protein_surface_potential', return_value=-psi_a*(1.0-1e-10)):
            energy = m._paper_adsorber_energy(c, 5.0, kap, psi_a)
        self.assertTrue(math.isfinite(energy))
        self.assertLess(energy, 0.0)
        # Limit of CADET's constant-charge expression as abs(psi_p) -> abs(psi_a).
        expected = -4.0*math.pi*c.radius_m*m.eps*psi_a**2*math.log(2.0)
        self.assertAlmostEqual(energy/expected, 1.0, places=8)

    def test_ligand_full_charge_matches_cadet_surface_charge_balance(self):
        m = self.model
        for zeta in (0.0, 0.5, 1.0):
            m.ligand_charge_full=zeta
            m._adsorber_potential_cache.clear()
            for pH in (3.0, 5.0, 8.0):
                kappa=m.debye_kappa(20.0)
                psi=m._adsorber_surface_potential(pH,kappa)
                pH0=pH + E_CHARGE*psi/(math.log(10)*m.kBT)
                alpha=1/(1+10**(m.ligand_pK-pH0))
                charge=E_CHARGE*N_A*m.ligand_density_mol_m2*(zeta-alpha)
                diffuse=m._grahame_scale(kappa)*math.sinh(E_CHARGE*psi/(2*m.kBT))
                self.assertAlmostEqual(charge-diffuse, 0, delta=max(abs(charge),1e-12)*1e-10)
        with self.assertRaises(ValueError):
            CPAModel([self.component],m.ligand_density_mol_m2,1.,
                     ligand_charge_full=-1)

    def test_cadet_pore_ionic_strength_and_davies_ph(self):
        # [H+, Na+, Cl-, citrate2-], c in mol/m^3 (1000 mol/m3 = 1 M).
        c=np.array([0.01, 45.0, 30.0, 7.5])
        z=np.array([1, 1, -1, -2])
        pH, I=CPAModel.cadet_pore_chemistry(c,z,0)
        expected_I=0.5*float(np.dot(c,z*z))*0.001
        self.assertAlmostEqual(I,expected_I,places=14)
        gamma_log=-0.509*(math.sqrt(I)/(1+math.sqrt(I))-0.3*I)
        expected_pH=-math.log10(c[0]*1e-3) - gamma_log
        self.assertAlmostEqual(pH,expected_pH,places=13)
        no_gamma_pH,_=CPAModel.cadet_pore_chemistry(c, np.array([0,1,-1,-2]),0)
        self.assertAlmostEqual(no_gamma_pH, -math.log10(0.01*1e-3),places=14)
        self.assertEqual(CPAModel.cadet_pore_chemistry(np.array([0.,10.]),np.array([1.,1.]))[0],14.0)
        for b,zv in [(np.array([-1.,1.]),np.array([1,1])),(np.ones(2),np.array([1,1.5]))]:
            with self.assertRaises(ValueError):
                CPAModel.cadet_pore_chemistry(b,zv)

    def test_cadet_temperature_permittivity_parameterised(self):
        m=self.model
        k0=m.debye_kappa(30.)
        warm=CPAModel([self.component],m.ligand_density_mol_m2,1.0,
                       paper_tdm_cpa=True,temperature_K=310.0,relative_permittivity=79.0)
        kw=warm.debye_kappa(30.)
        self.assertAlmostEqual(kw/k0,
            math.sqrt(m.relative_permittivity*m.temperature_K /
                      (warm.relative_permittivity*warm.temperature_K)),places=13)
        for k,v in [('temperature_K',-1),('relative_permittivity',0)]:
            c=copy.deepcopy(self.config)
            c['cpa'][k]=v
            self.assertNotEqual(validate_config(c,strict=True),[])

    def test_high_total_equilibrium_stays_in_cadet_surface_domain(self):
        # The excess belongs in free liquid, not in an invalid Theta >= 1.
        m=self.model
        for amount in (1.0, 50.0, 1000.0):
            total=np.array([amount])
            free,bound=m.equilibrium_from_total(total,0.5,5.0,0.02)
            self.assertLess(m.surface_coverages(bound)[0],1.0)
            np.testing.assert_allclose(free+0.5*bound,total,rtol=1e-12)
            np.testing.assert_allclose(bound,
                m.equilibrium_factors(bound,5.0,0.02)*free,rtol=2e-6,atol=1e-8)
        cp2=copy.copy(self.component)
        cp2.radius_m*=0.9
        mix=CPAModel([self.component,cp2],m.ligand_density_mol_m2,1.0,
                     paper_tdm_cpa=True)
        total=np.array([100.,200.])
        free,bound=mix.equilibrium_from_total(total,.5,5.,.02)
        self.assertLess(mix.surface_coverages(bound)[0],1.0)
        np.testing.assert_allclose(free+0.5*bound,total,rtol=1e-12)
        np.testing.assert_allclose(bound,mix.equilibrium_factors(bound,5.,.02)*free,
                                   rtol=2e-6,atol=1e-8)

    def test_new_settings_survive_sanitize_save_and_batch_merge(self):
        c=copy.deepcopy(self.config)
        c['cpa'].update(ligand_charge_full=0.7, invalid_state_policy='FLOW_THROUGH_LEGACY', temperature_K=303.15, relative_permittivity=75.0)
        self.assertEqual(validate_config(c, strict=True),[])
        with tempfile.TemporaryDirectory() as d:
            save_config(c,Path(d)/'settings.json')
            loaded=load_config(Path(d)/'settings.json')
        sanitized=sanitize_config_for_selected_model(loaded)
        for x in (loaded,sanitized):
            self.assertEqual(x['cpa']['ligand_charge_full'],0.7)
            self.assertEqual(x['cpa']['temperature_K'],303.15)
            self.assertEqual(x['cpa']['relative_permittivity'],75.0)
            self.assertEqual(x['cpa']['invalid_state_policy'],'FLOW_THROUGH_LEGACY')
        paths=batch_shared_parameter_paths(c)
        self.assertIn('cpa.ligand_charge_full',paths)
        self.assertIn('cpa.invalid_state_policy',paths)
        self.assertIn('cpa.temperature_K',paths)
        self.assertIn('cpa.relative_permittivity',paths)
        run=copy.deepcopy(c)
        run['cpa'].update(ligand_charge_full=0.0,invalid_state_policy='ERROR')
        effective,_=apply_batch_shared_parameters(c,run)
        self.assertEqual(effective['cpa']['ligand_charge_full'],0.7)
        self.assertEqual(effective['cpa']['invalid_state_policy'],'FLOW_THROUGH_LEGACY')
        c['cpa']['invalid_state_policy']='INVENTED'
        self.assertTrue(any('invalid state policy' in e for e in validate_config(c, strict=True)))


if __name__=='__main__':
    unittest.main()
