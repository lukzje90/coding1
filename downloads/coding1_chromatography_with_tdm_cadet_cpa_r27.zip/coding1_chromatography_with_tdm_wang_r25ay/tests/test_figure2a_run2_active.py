"""Check the installed Run 1 benchmark is the Huuk Run 2 recipe."""
from pathlib import Path
import math
from tdm_minimal_io import (CONFIG_PATH, BATCH_RUNS_CSV, load_config,
                            load_batch_rows, batch_row_to_run_config,
                            apply_batch_shared_parameters, validate_config,
                            buffer_chemistry)


def test_figure2a_run2_active_files():
    shared = load_config(CONFIG_PATH)
    row = load_batch_rows(BATCH_RUNS_CSV)[0]
    effective, _ = apply_batch_shared_parameters(shared, batch_row_to_run_config(row))
    assert validate_config(effective) == []
    assert row['Run_Name'] == 'Figure 2a - Huuk Run 2 (90 g/L)'
    assert effective['model'] == 'TDM_CPA'
    assert effective['cpa']['steric_convention'] == 'STANDARD_SPT'
    assert math.isclose(effective['column']['flow_mL_min'], 0.08)
    assert math.isclose(effective['feed']['total_concentration_mg_mL'], 12.7)
    assert math.isclose(effective['feed']['load_density_mg_mL_resin'], 90)
    p = effective['process']
    assert p['equilibration_source'] == 'BUFFER_A'
    assert p['load_material_chemistry_mode'] == 'BUFFER_RECIPE'
    assert p['plw_count'] == 1 and p['elution_count'] == 2
    assert math.isclose(p['plw_steps'][0]['CV'], 5)
    assert math.isclose(p['elution_steps'][0]['CV'], 30.63)
    assert math.isclose(p['elution_steps'][1]['CV'], 5)
    a = buffer_chemistry(effective,p['buffer_A'])
    b = buffer_chemistry(effective,p['buffer_B'])
    assert a['salt_input_mode'] == b['salt_input_mode'] == 'SALT_M'
    assert math.isclose(a['salt_concentration_M'], 0)
    assert math.isclose(b['salt_concentration_M'], 0.45)
    assert 0.02 < a['ionic_strength_M'] < 0.03
    assert math.isclose(b['ionic_strength_M']-a['ionic_strength_M'],0.45,abs_tol=1e-12)
    assert p['elution_steps'][1]['chemistry_control'] == 'ENDPOINT_CHEMISTRY'
    assert math.isclose(p['elution_steps'][1]['start_salt_concentration_M'],1)
