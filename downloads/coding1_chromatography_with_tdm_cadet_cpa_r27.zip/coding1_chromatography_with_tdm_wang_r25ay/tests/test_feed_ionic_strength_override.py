"""Regression for independent, saved, feed-only prescribed ionic strength.

10 mM is a hypothetical feed condition, not an experimental measurement.
"""
import copy
import tempfile
import unittest
from pathlib import Path

import numpy as np
from tdm_jmp import build_jsl, _validate_jsl
from tdm_minimal_io import (load_config, load_batch_rows, batch_run_fields,
    default_batch_row, batch_row_to_run_config, apply_batch_shared_parameters,
    validate_config, ensure_batch_runs_csv)
from tdm_minimal_model import _build_program

ROOT = Path(__file__).resolve().parents[1]

class FeedChemistryOverrideTests(unittest.TestCase):
    def _config(self):
        shared = load_config(ROOT / "tdm_inputs.json")
        saved = load_batch_rows(ROOT / "tdm_batch_runs.csv")[0]
        cfg, _ = apply_batch_shared_parameters(shared, batch_row_to_run_config(saved))
        return cfg

    def test_loading_override_changes_only_load_pore_ionic_strength(self):
        base = self._config()
        c = copy.deepcopy(base)
        c['process']['load_ionic_strength_M'] = 0.010
        self.assertEqual(validate_config(c, strict=True), [])
        original = _build_program(base, np.zeros(1))
        changed = _build_program(c, np.zeros(1))
        self.assertAlmostEqual(original.stages[0].start_I_M, 0.0226948668)
        self.assertAlmostEqual(changed.stages[0].start_I_M, 0.010)
        self.assertAlmostEqual(changed.stages[0].end_I_M, 0.010)
        self.assertEqual(changed.stages[0].start_salt_M, 0.0)
        self.assertAlmostEqual(changed.stages[0].start_conductivity_mS_cm, 3.0)
        self.assertEqual(changed.initial_chemistry, original.initial_chemistry)
        for a,b in zip(changed.stages[1:],original.stages[1:]):
            self.assertEqual((a.start_I_M,a.end_I_M,a.start_salt_M,a.end_salt_M),
                             (b.start_I_M,b.end_I_M,b.start_salt_M,b.end_salt_M))

    def test_save_load_table_preserves_feed_override(self):
        self.assertIn('Load_Ionic_Strength_M', batch_run_fields())
        with tempfile.TemporaryDirectory() as d:
            import csv
            p=Path(d)/'runs.csv'
            row=default_batch_row(1)
            row['Load_Ionic_Strength_M']='0.010'
            with open(p,'w',newline='',encoding='utf-8') as f:
                w=csv.DictWriter(f,fieldnames=list(row));w.writeheader();w.writerow(row)
            ensure_batch_runs_csv(p)
            saved=load_batch_rows(p)[0]
            self.assertAlmostEqual(float(saved['Load_Ionic_Strength_M']),0.01)
            cfg=batch_row_to_run_config(saved)
            self.assertAlmostEqual(cfg['process']['load_ionic_strength_M'],0.010)

    def test_invalid_feed_strength_rejected(self):
        base=self._config()
        for value in [-1.0, 0.0]:
            with self.subTest(value=value):
                cfg=copy.deepcopy(base);cfg['process']['load_ionic_strength_M']=value
                self.assertTrue(validate_config(cfg,strict=True),msg=value)

    def test_jmp_control_present_and_persistent(self):
        j=build_jsl();_validate_jsl(j)
        self.assertIn('loadIonicStrength = Number Edit Box(',j)
        self.assertIn('"Load_Ionic_Strength_M")[currentRun] = loadIonicStrength << Get',j)
        self.assertIn('loadIonicStrength << Set(Column(dtRuns, "Load_Ionic_Strength_M")',j)

if __name__=='__main__':unittest.main()
