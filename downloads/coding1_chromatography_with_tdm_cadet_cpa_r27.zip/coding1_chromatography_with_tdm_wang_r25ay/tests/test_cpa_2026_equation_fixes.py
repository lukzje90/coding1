"""Independent regression tests for the CPA equation audit fixes (Nov 2026)."""
import copy
import math
import unittest
import warnings
import tempfile
from pathlib import Path
from unittest.mock import patch
from decimal import Decimal, localcontext

import numpy as np
from scipy.integrate import solve_ivp

from tdm_minimal_io import (
    MODEL_TDM_CPA, sanitize_config_for_selected_model,
    save_config, load_config, validate_config,
    apply_batch_shared_parameters, batch_shared_parameter_paths,
)
from tdm_minimal_model import (
    N_A, CPA_MONODISPERSE_CLOSE_PACKING, _CoverageGuardedBDF,
    _build_cpa_components, _cpa_model, _exp_from_log,
)
from verify_model import make_config


class CPAEquationFixTests(unittest.TestCase):
    def setUp(self):
        self.config = make_config(MODEL_TDM_CPA, 0, multistep=False)
        self.component = _build_cpa_components(self.config, need_tdm_kinetics=True)[0]
        self.model = _cpa_model(self.config, [self.component])

    def bound_at_theta(self, theta):
        c = self.component
        return np.array([theta * c.As_m_inv / (math.pi * N_A * c.radius_m**2)])

    def test_unclipped_lateral_energy_at_111_kbt(self):
        c, m = self.component, self.model
        c.Z_lat = 40.0
        m.has_lateral_interactions = True
        q = self.bound_at_theta(0.658)
        u_lat = m.lateral_interactions(q, 3.0)[0]
        self.assertGreater(u_lat / m.kBT, 100.0)
        y = m.u_adsorber(c, 5.0, 3.0) / m.kBT
        b = m.available_surface(0, q)
        expected = c.delta(5.0) * b * math.exp(-u_lat/m.kBT) * (-math.expm1(-y) / y)
        calculated = m.equilibrium_factors(q, 5.0, 0.003)[0]
        self.assertAlmostEqual(calculated / expected, 1.0, places=12)
        # Original numeric reference was calculated for BRISKOT_PRINTED.
        # Under CADET's pi**2 term, compare against the independent analytical
        # expression above rather than the previous-convention constant.
        self.assertGreater(calculated, 0.0)

    def test_opposing_exponents_are_combined_before_exponentiation(self):
        # exp(-700) * exp(+800) is representable as a product (exp(100)),
        # although exp(+800) is not representable as an intermediate float.
        q = np.zeros(1)
        m = self.model
        m.has_lateral_interactions = True
        with patch.object(m, 'lateral_interactions', return_value=np.array([700.0*m.kBT])), \
             patch.object(m, '_u_adsorber_at_environment', return_value=-800.0*m.kBT):
            forward = np.zeros(1)
            kv = m.equilibrium_factors(q, 5.0, 0.05, _forward_out=forward)[0]
        with localcontext() as ctx:
            ctx.prec = 70
            y, v = Decimal(-800), Decimal(700)
            expected = (Decimal(str(self.component.delta(5.0))) * (-v).exp()
                        * (Decimal(1) - (-y).exp()) / y)
            expected_forward = (Decimal(str(self.component.delta(5.0)))
                                * (-v).exp() * y / (y.exp() - Decimal(1)))
        self.assertAlmostEqual(kv / float(expected), 1.0, places=11)
        self.assertAlmostEqual(forward[0] / float(expected_forward), 1.0, places=11)

    def test_boltzmann_factor_not_capped_near_80(self):
        m = self.model
        q = np.zeros(1)
        y = -40.0
        m.has_lateral_interactions = True
        for lateral in (0.0, 40.0, 79.9, 80.1, 120.0, 400.0):
            with self.subTest(lateral=lateral):
                with patch.object(m, 'lateral_interactions', return_value=np.array([lateral*m.kBT])), \
                     patch.object(m, '_u_adsorber_at_environment', return_value=y*m.kBT):
                    val = m.equilibrium_factors(q, 5.0, 0.05)[0]
                expected = (self.component.delta(5.0)*math.exp(-lateral)
                            * (-math.expm1(-y)/y))
                self.assertAlmostEqual(val / expected, 1.0, places=11)

    def test_monodisperse_cadet_steric_pi_squared_only(self):
        for theta in (0.1, 0.5, 0.658, 0.9):
            q = self.bound_at_theta(theta)
            standard = ((1-theta)*math.exp(-3*theta/(1-theta)
                        -theta**2/((1-theta)**2)))
            self.assertAlmostEqual(self.model.available_surface(0, q)/standard, 1.0, places=11)
        # The legacy single-pi mode is intentionally unavailable.
        from tdm_minimal_model import CPAModel
        with self.assertRaisesRegex(ValueError, 'Single-pi'):
            CPAModel([self.component], self.model.ligand_density_mol_m2,
                     1.0, paper_tdm_cpa=True, steric_pi_squared=False)

    def test_standard_steric_high_packing_does_not_floor_exponent_to_80(self):
        self.model.steric_pi_squared = True
        theta = 0.905
        calc = self.model.available_surface(0, self.bound_at_theta(theta))
        expected = ((1-theta)*math.exp(-3*theta/(1-theta)
                    -theta**2/((1-theta)**2)))
        self.assertLess(calc, (1-theta)*math.exp(-80))
        self.assertAlmostEqual(calc/expected, 1.0, places=10)

    def test_cadet_standard_is_default_and_signed_lateral_attraction_is_retained(self):
        self.assertTrue(self.model.steric_pi_squared)
        from tdm_minimal_model import CPAModel
        import copy
        a = copy.copy(self.component)
        b = copy.copy(self.component)
        a.Z_lat, b.Z_lat = 12.0, -12.0
        model = CPAModel([a, b], self.model.ligand_density_mol_m2,
                         1.0, paper_tdm_cpa=True, steric_pi_squared=True)
        single_surface = 0.6 * a.As_m_inv / (math.pi*N_A*a.radius_m*a.radius_m)
        qv = np.array([0.0, single_surface*a.As_m_inv])
        lat = model.lateral_interactions(qv, 0.03*1000.0)
        self.assertLess(lat[0], 0.0)
        self.assertGreater(lat[1], 0.0)
        # Signed Yukawa sum: the attraction between opposite charges should
        # be equal in magnitude to same-magnitude charge repulsion here.
        self.assertAlmostEqual(lat[0]/lat[1], -1.0, places=11)

    def test_invalid_charge_sign_no_artificial_affinity(self):
        from tdm_minimal_model import CPAInvalidStateError
        self.component.Z_ref = -5.0
        m = self.model
        with self.assertRaises(ValueError):
            m.equilibrium_factors(np.zeros(1), 5.0, 0.05)
        with self.assertRaises(ValueError):
            m.kinetic_rate(np.ones(1), np.zeros(1), 5.0, 0.05)
        with self.assertRaises(ValueError):
            m.u_adsorber(self.component, 5.0, 50.0)
        # Legacy historical run behavior remains available only when selected.
        m.invalid_state_policy = 'FLOW_THROUGH_LEGACY'
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            K = m.equilibrium_factors(np.zeros(1), 5.0, 0.05)[0]
            rate = m.kinetic_rate(np.ones(1), np.zeros(1), 5.0, 0.05)[0]
        self.assertEqual(K, 0.0)
        self.assertEqual(rate, 0.0)
        self.assertTrue(any('FLOW_THROUGH_LEGACY' in str(w.message) for w in caught))

    def test_steric_convention_config_and_validation(self):
        cfg = copy.deepcopy(self.config)
        cfg['cpa']['steric_convention'] = 'STANDARD_SPT'
        self.assertTrue(_cpa_model(cfg, [self.component]).steric_pi_squared)
        cfg['cpa']['steric_convention'] = 'BRISKOT_PRINTED'
        with self.assertRaisesRegex(ValueError, 'STANDARD_SPT'):
            _cpa_model(cfg, [self.component])
        self.assertTrue(any('STANDARD_SPT' in error for error in validate_config(cfg)))
        cfg['cpa']['steric_convention'] = 'UNKNOWN'
        with self.assertRaisesRegex(ValueError, 'steric_convention'):
            _cpa_model(cfg, [self.component])

    def test_steric_convention_survives_save_sanitize_and_batch(self):
        cfg = copy.deepcopy(self.config)
        cfg['cpa']['steric_convention'] = 'STANDARD_SPT'
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / 'cpa.json'
            save_config(cfg, path)
            loaded = load_config(path)
        self.assertEqual(loaded['cpa']['steric_convention'], 'STANDARD_SPT')
        self.assertEqual(sanitize_config_for_selected_model(cfg)['cpa']['steric_convention'], 'STANDARD_SPT')
        self.assertIn('cpa.steric_convention', batch_shared_parameter_paths(cfg))
        run = copy.deepcopy(cfg)
        run['cpa']['steric_convention'] = 'BRISKOT_PRINTED'
        effective, overridden = apply_batch_shared_parameters(cfg, run)
        self.assertEqual(effective['cpa']['steric_convention'], 'STANDARD_SPT')
        self.assertIn('cpa.steric_convention', overridden)
        self.assertTrue(_cpa_model(effective, [self.component]).steric_pi_squared)
        cfg['cpa']['steric_convention'] = 'UNKNOWN'
        self.assertTrue(any('steric convention' in e for e in validate_config(cfg)))

    def test_exp_from_log_rounding_at_subnormal_limit(self):
        smallest = float(np.nextafter(0, 1))
        self.assertEqual(_exp_from_log(math.log(smallest)), smallest)
        # exp(log(smallest)-0.5) rounds UP to the smallest subnormal.
        # The earlier standalone Python file incorrectly returned zero.
        self.assertEqual(_exp_from_log(math.log(smallest) - 0.5), smallest)
        self.assertEqual(_exp_from_log(math.log(smallest) - 0.8), 0.0)

    def test_kinetic_coefficient_does_not_underflow_before_multiplication(self):
        # Eq. (18): fkin ~ y**2 exp(-|y|).  With |y|=750,
        # exp(-750) is not representable, but the full expression is.
        for y in (-740.0, -745.0, -750.0, 740.0, 745.0, 750.0):
            with self.subTest(y=y), localcontext() as ctx:
                ctx.prec = 90
                mag = Decimal(abs(y))
                tiny = (-mag).exp()
                expected = float(mag*mag * tiny / (Decimal(1) - tiny)**2)
                actual = self.model._fkin(y)
                self.assertGreater(actual, 0.0)
                # Subnormal spacing is necessarily coarse near 1e-320.
                self.assertAlmostEqual(actual / expected, 1.0, delta=0.001)
        for y in (745.0, 750.0):
            self.assertGreater(self.model._kinetic_forward_factor(y), 0.0)

    def test_cadet_coverage_domain_is_theta_below_one(self):
        # CADET does not impose 0.9069 as a hard mathematical cutoff.
        def rhs(_t, _y):
            return np.array([0., 0., 1.])
        result = _CoverageGuardedBDF(
            rhs, 0.0, np.array([0., 0., 0.91]), 0.05,
            coverage_weights=np.ones(1),
            adsorbed_slice=slice(2, 3), axial_positions=1, species_count=1,
            bulk_slice=slice(0, 1), pore_slice=slice(1, 2),
            void_fraction=0.5, particle_porosity=0.5,
            projection_stats={'count': 0, 'maximum_phase_correction_mol_m3': 0.},
            geometric_coverage_ceiling=1.0, max_step=0.01,
        )
        while result.status == 'running':
            result.step()
        self.assertEqual(result.status, 'finished')
        self.assertGreater(float(result.y[2]), CPA_MONODISPERSE_CLOSE_PACKING)
        self.assertLess(float(result.y[2]), 1.0)

    def test_coverage_equal_one_is_not_silently_clipped(self):
        with self.assertRaisesRegex(ValueError, 'Theta < 1'):
            self.model.available_surface(0, self.bound_at_theta(1.0))


if __name__ == '__main__':
    unittest.main()
