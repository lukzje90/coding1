"""The actual Huuk Run 2 / Briskot Fig. 2a benchmark, not a Run 1/Run 2 hybrid.

Experimental source: Huuk et al. (2017), Table 1 Run 2 and Fig. 1B.
This test checks numerical and operating-condition consistency. It deliberately
DOES NOT assert agreement with the experimental wash-transition spike: the
published CPA simulation itself underpredicts that feature.
"""

import unittest
import numpy as np
from pathlib import Path
from tdm_minimal_io import (
    load_config, load_batch_rows, batch_row_to_run_config,
    apply_batch_shared_parameters, validate_config,
)
from tdm_minimal_model import simulate

ROOT = Path(__file__).resolve().parents[1]


def poros_mab1_run2_case(axial_cells=8, output_steps=175):
    shared = load_config(ROOT / "tdm_inputs.json")
    row = load_batch_rows(ROOT / "tdm_batch_runs.csv")[0]
    config, _ = apply_batch_shared_parameters(shared, batch_row_to_run_config(row))
    config["numerics"].update(axial_positions=axial_cells, time_steps=output_steps)
    return config


class PorosPaperBenchmarkTests(unittest.TestCase):
    def test_source_setup_is_exact_run2_not_run1_hybrid(self):
        cfg = poros_mab1_run2_case()
        self.assertEqual(validate_config(cfg, strict=True), [])
        self.assertEqual(cfg["model"], "TDM_CPA")
        self.assertEqual(cfg["cpa"]["steric_convention"], "STANDARD_SPT")
        self.assertEqual(cfg["cpa"]["ionic_strength_mode"], "PRESCRIBED")
        self.assertAlmostEqual(cfg["column"]["flow_mL_min"], 0.080)
        self.assertAlmostEqual(cfg["feed"]["load_density_mg_mL_resin"], 90.0)
        self.assertAlmostEqual(cfg["feed"]["total_concentration_mg_mL"], 12.7)
        proc = cfg["process"]
        self.assertAlmostEqual(proc["plw_steps"][0]["CV"], 5.0)
        self.assertAlmostEqual(proc["elution_steps"][0]["CV"], 30.63)
        self.assertAlmostEqual(proc["elution_steps"][0]["flow_mL_min"], 0.080)
        self.assertAlmostEqual(proc["elution_steps"][1]["CV"], 5.0)
        self.assertAlmostEqual(proc["buffer_A"]["salt_concentration_M"], 0.0)
        self.assertAlmostEqual(proc["buffer_B"]["salt_concentration_M"], 0.45)
        self.assertAlmostEqual(cfg["components"][0]["As_m_inv"], 0.22e9)

    def test_loading_spike_is_predicted_but_not_empirically_validated(self):
        cfg = poros_mab1_run2_case()
        result = simulate(cfg)
        trace = result["trace"]
        uv = np.asarray(trace["uv_mAU"])
        volume = np.asarray(trace["volume_mL"])
        early = (volume >= 6.0) & (volume <= 11.0)
        self.assertTrue(np.any(early))
        # The initial load/wash pulse must not vanish numerically.
        self.assertGreater(float(np.max(uv[early])), 0.0)
        # Numerical sanity: the main elution peak is later than the pulse.
        self.assertGreater(float(volume[np.argmax(uv)]), 15.0)
        self.assertLess(float(volume[np.argmax(uv)]), 30.0)
        diagnostics = result["simulation"]["diagnostics"]
        self.assertGreater(diagnostics["axial_grid_cell_peclet_max"], 2.0)
        self.assertTrue(any("axial-grid cell Peclet" in w for w in diagnostics["warnings"]))
        audit = diagnostics["CPA_adsorption_audit"]["species"][0]
        self.assertLess(audit["load_outlet_percent_of_load"], 1.0)
        balance = next(iter(result["mass_balance"].values()))
        self.assertAlmostEqual(balance["input_g"], 0.08829, places=5)
        self.assertLess(abs(balance["closure_error_percent_of_input"]), 1.0)


if __name__ == "__main__":
    unittest.main()
