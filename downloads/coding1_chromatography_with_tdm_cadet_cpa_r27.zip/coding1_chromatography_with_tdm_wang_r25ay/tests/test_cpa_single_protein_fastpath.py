"""Check the single-protein speed path against the full CADET CPA equations.

The tests intentionally compare against the independent existing general path
rather than inspecting only one special-case implementation.
"""
import copy
import math
import unittest
import warnings
import numpy as np
from tdm_minimal_io import MODEL_TDM_CPA
from tdm_minimal_model import CPAModel, _cpa_model, _build_cpa_components, N_A
from verify_model import make_config


class SingleProteinFastpathTests(unittest.TestCase):
    def setUp(self):
        self.config = make_config(MODEL_TDM_CPA, 0, multistep=False)
        self.comp = _build_cpa_components(self.config, need_tdm_kinetics=True)[0]
        self.model = _cpa_model(self.config, [self.comp])

    def test_matches_general_rate_for_ionic_strength_coverage_and_pH(self):
        # Includes zero occupancy, high occupancy and high lateral charge.
        for charge in (0.0, 19.07, 40.0):
            self.comp.Z_lat = charge
            self.model.has_lateral_interactions = charge != 0
            for pH in (4.5, 5.0, 6.0):
                for ionic in (0.005, 0.025, 0.080, 0.200, 0.5):
                    for theta in (0.0, 0.001, 0.2, 0.5, 0.77, 0.89):
                        q = theta*self.comp.As_m_inv/(math.pi*N_A*self.comp.radius_m**2)
                        for cp in (0.0, 0.01, 0.1):
                            with self.subTest(charge=charge, pH=pH, ionic=ionic, theta=theta, cp=cp):
                                fast = self.model._kinetic_rate_single(cp, q, pH, ionic)
                                general = self.model.kinetic_rate(
                                    np.array([cp]), np.array([q]), pH, ionic)[0]
                                self.assertTrue(np.isclose(fast, general, rtol=2e-10,
                                                           atol=1e-12), (fast, general))

    def test_invalid_charge_policy_and_coverage_domain(self):
        self.comp.Z_ref = -5.0
        with self.assertRaisesRegex(ValueError, 'invalid attractive'):
            self.model._kinetic_rate_single(0.1, 0.01, 5.0, 0.02)
        self.model.invalid_state_policy = 'FLOW_THROUGH_LEGACY'
        self.comp.kkin_star_s = 37.0
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            self.assertAlmostEqual(self.model._kinetic_rate_single(0.1, 0.01, 5.0, 0.02), -0.37)
        self.comp.Z_ref = 40.0
        q_unit = self.comp.As_m_inv/(math.pi*N_A*self.comp.radius_m**2)
        with self.assertRaisesRegex(ValueError, 'Theta < 1'):
            self.model._kinetic_rate_single(0.1, 1.01*q_unit, 5.0, 0.02)

    def test_legacy_steric_configuration_rejected(self):
        self.config['cpa']['steric_convention'] = 'BRISKOT_PRINTED'
        with self.assertRaisesRegex(ValueError, 'STANDARD_SPT'):
            _cpa_model(self.config, [self.comp])


if __name__ == '__main__':
    unittest.main()
