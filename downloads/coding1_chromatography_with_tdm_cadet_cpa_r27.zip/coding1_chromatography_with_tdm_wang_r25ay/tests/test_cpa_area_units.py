"""Briskot CPA area uses nm⁻¹ in JMP; saved recipes use m⁻¹."""
import csv
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import tdm_bridge
import tdm_least_squares as lsq
from tdm_jmp import build_jsl, _validate_jsl
from tdm_minimal_io import MODEL_LABELS, MODEL_TDM_CPA, load_config, save_config
from tdm_minimal_model import simulate
from verify_model import make_config


class CPAAreaUnitTests(unittest.TestCase):
    def test_paper_radius_and_log_delta_round_trip(self):
        config = make_config(MODEL_TDM_CPA, 0, multistep=False)
        config["tdm"]["bead_radius_um"] = 25.0
        config["components"][0].update(diameter_nm=11.0, delta_ref=10.0 ** -1.9)
        jsl = build_jsl(config)
        self.assertIn('beadRadius = Number Edit Box(50, 9', jsl)
        self.assertIn('c1Diameter = Number Edit Box(5.5, 9', jsl)
        self.assertIn('c1Delta = Number Edit Box(-1.8999999999999999, 9', jsl)
        with patch.dict(tdm_bridge.__dict__, {
                "tdm_ui_model": MODEL_LABELS[MODEL_TDM_CPA],
                "tdm_ui_impurity_count": 0,
                "tdm_ui_bead_radius": 25.0,
                "tdm_ui_c1_radius_nm": 5.5,
                "tdm_ui_c1_log10_delta_ref": -1.9,
                "tdm_ui_c1_Z1_per_pH": 0.0,
                "tdm_ui_c1_Z2_per_pH2": 0.0,
                "tdm_ui_c1_Z3_per_pH3": 0.0,
        }):
            shared = tdm_bridge.build_shared_config_from_jmp()
        self.assertEqual(shared["tdm"]["bead_radius_um"], 25.0)
        self.assertEqual(shared["components"][0]["diameter_nm"], 11.0)
        self.assertAlmostEqual(shared["components"][0]["delta_ref"], 10.0 ** -1.9)
        self.assertEqual(shared["components"][0]["Z3_per_pH3"], 0.0)

    def test_old_saved_area_displays_in_new_jmp_unit_without_changing_solver_value(self):
        config = make_config(MODEL_TDM_CPA, 1, multistep=False)
        config["components"][0]["As_m_inv"] = 200_000_000.0
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "saved.json"
            save_config(config, path)
            loaded = load_config(path)
            jsl = build_jsl(loaded)
        _validate_jsl(jsl)
        self.assertEqual(loaded["components"][0]["As_m_inv"], 200_000_000.0)
        self.assertIn('c1As = Number Edit Box(0.20000000000000001, 9', jsl)
        self.assertIn('Accessible area A_s,i [nm⁻¹]', jsl)
        self.assertIn('Python Name("tdm_ui_c1_As_nm_inv")', jsl)

    def test_new_jmp_area_converts_once_and_old_jmp_field_remains_compatible(self):
        common = {"tdm_ui_model": MODEL_LABELS[MODEL_TDM_CPA], "tdm_ui_impurity_count": 0}
        with patch.dict(tdm_bridge.__dict__, {**common, "tdm_ui_c1_As_nm_inv": 0.2,
                                               "tdm_ui_c1_As_m_inv": 1.0}):
            paper_recipe = tdm_bridge.build_shared_config_from_jmp()
        self.assertEqual(paper_recipe["components"][0]["As_m_inv"], 200_000_000.0)
        with patch.dict(tdm_bridge.__dict__, {**common, "tdm_ui_c1_As_m2_mL_solid": 200.0,
                                               "tdm_ui_c1_As_m_inv": 1.0}):
            new_recipe = tdm_bridge.build_shared_config_from_jmp()
        self.assertEqual(new_recipe["components"][0]["As_m_inv"], 200_000_000.0)
        with patch.dict(tdm_bridge.__dict__, {**common, "tdm_ui_c1_As_m_inv": 200_000_000.0}):
            tdm_bridge.__dict__.pop("tdm_ui_c1_As_m2_mL_solid", None)
            old_recipe = tdm_bridge.build_shared_config_from_jmp()
        self.assertEqual(old_recipe["components"][0]["As_m_inv"], 200_000_000.0)

    def test_lsq_still_fits_stored_area_but_applies_and_reports_ui_unit(self):
        config = make_config(MODEL_TDM_CPA, 0, multistep=False)
        config["components"][0]["As_m_inv"] = 200_000_000.0
        path = "components[0].As_m_inv"
        specs = lsq.fit_parameter_specs(config, unlocked_paths=[path])
        spec = next(item for item in specs if item.path == path)
        self.assertAlmostEqual(spec.initial, 8.301029995663981)
        self.assertIn("[nm⁻¹]", spec.label)
        self.assertEqual(lsq._display_fit_value(path, 200_000_000.0), 0.2)
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "apply.jsl"
            with patch.object(lsq, "FIT_APPLY_JSL", target):
                lsq._write_apply_jsl(config, [spec])
            script = target.read_text(encoding="utf-8")
        self.assertIn("c1As << Set(0.20000000000000001);", script)
        self.assertEqual(config["components"][0]["As_m_inv"], 200_000_000.0)

    def test_lsq_fit_report_shows_area_in_ui_units_while_fit_config_stays_legacy(self):
        config = make_config(MODEL_TDM_CPA, 0, multistep=False)
        config["numerics"].update(time_steps=50, axial_positions=6)
        config["components"][0]["As_m_inv"] = 200_000_000.0
        trace = simulate(config)["trace"]
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "reference.csv"
            with source.open("w", encoding="utf-8", newline="") as fh:
                writer = csv.writer(fh)
                writer.writerow(["CV", "UV [mAU]"])
                writer.writerows(zip(trace["CV"], trace["uv_mAU"]))
            outputs = ("FIT_RESULTS_CSV", "FIT_TRACE_CSV", "FIT_CONDUCTIVITY_CSV",
                       "FIT_COMPOSITION_CSV", "FIT_REPORT_HTML", "FIT_CONFIG_JSON",
                       "FIT_APPLY_JSL", "FIT_SETTINGS_JSON", "FIT_HISTORY_CSV",
                       "FIT_IMPROVED_CSV", "FIT_IMPROVED_TXT", "CONFIG_PATH")
            with patch.multiple(lsq, **{name: root / getattr(lsq, name).name for name in outputs}):
                fit = lsq.run_global_least_squares_refinement(
                    [{"config": config, "chromatogram_csv": source,
                      "run_context": {"run_number": 1, "run_name": "Area test"}}],
                    unlocked_paths=["components[0].As_m_inv"],
                    max_nfev=3, max_model_evaluations=6)
                with lsq.FIT_RESULTS_CSV.open(newline="", encoding="utf-8") as fh:
                    area = next(row for row in csv.DictReader(fh)
                                if row["Parameter_Path"] == "components[0].As_m_inv")
                report = lsq.FIT_REPORT_HTML.read_text(encoding="utf-8")
                fitted = load_config(lsq.FIT_CONFIG_JSON)
        self.assertEqual(float(area["Initial_Value"]), 0.2)
        self.assertIn("nm⁻¹", area["Parameter"])
        self.assertIn("nm⁻¹", report)
        self.assertEqual(fitted["components"][0]["As_m_inv"],
                         fit["fitted_config"]["components"][0]["As_m_inv"])


if __name__ == "__main__":
    unittest.main()
