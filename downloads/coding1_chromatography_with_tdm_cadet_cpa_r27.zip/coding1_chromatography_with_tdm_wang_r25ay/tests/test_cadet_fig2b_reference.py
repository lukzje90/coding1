"""Independent CADET-Core Fig. 2b outlet benchmark for TDM + CPA.

Reference: CADET-Core test/data/ref_COL1D_CPA_Briskot_Fig2b.h5,
unit_001/SOLUTION_OUTLET[:,3], commit a30f62b44e1c5861db3b6b8eb476588d505da860.
The source uses 100 WENO3 cells; this fast regression uses 24 MC-limited cells,
so the permitted discrepancy reflects spatial discretization, not parameter fitting.
"""

import unittest
from pathlib import Path

import numpy as np

from tdm_minimal_io import load_config, validate_config
from tdm_minimal_model import simulate


ROOT = Path(__file__).resolve().parents[1]
CASE = ROOT / "benchmark_scenarios" / "cadet_fig2b_translated.json"


class CadetFig2bReferenceTests(unittest.TestCase):
    def test_independent_outlet_profile_and_mass_balance(self):
        cfg = load_config(CASE)
        self.assertEqual(validate_config(cfg, strict=True), [])
        self.assertEqual(cfg["model"], "TDM_CPA")
        self.assertAlmostEqual(cfg["components"][0]["As_m_inv"], 1.8e8)
        self.assertAlmostEqual(cfg["components"][0]["diameter_nm"], 11.0)
        self.assertAlmostEqual(cfg["components"][0]["kkin_star_s"], 8.44e7)
        result = simulate(cfg)
        trace = result["trace"]
        volume = np.asarray(trace["volume_mL"])
        # 150 kDa is only the conversion scale from CADET's mol/m3 feed to
        # this application's g/L feed; compare in CADET's native mol/m3.
        protein = np.asarray(trace["column_component_g_L"][:, 0]) / 150.0
        source_points = {
            # mL: mol/m3 from CADET's committed numerical reference.
            300.0: 0.06286,
            330.0: 0.09287,
            360.0: 0.13246,
            390.0: 0.15690,
            420.0: 0.13761,
            450.0: 0.03477,
        }
        for outlet_mL, expected in source_points.items():
            with self.subTest(outlet_mL=outlet_mL):
                self.assertAlmostEqual(float(np.interp(outlet_mL, volume, protein)),
                                       expected, delta=0.004)
        peak = int(np.argmax(protein))
        self.assertAlmostEqual(float(volume[peak]), 396.24, delta=2.0)
        self.assertAlmostEqual(float(protein[peak]), 0.15791, delta=0.002)
        load_wash = volume < 230.0
        self.assertLess(float(np.max(protein[load_wash])), 0.03)
        self.assertGreater(float(np.max(protein[load_wash])), 0.018)
        self.assertLess(abs(next(iter(result["mass_balance"].values()))[
            "closure_error_percent_of_input"]), 0.02)
        self.assertEqual(result["simulation"]["diagnostics"][
            "protein_solver_section_restarts"], 3)


if __name__ == "__main__":
    unittest.main()
