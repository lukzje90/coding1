"""Regression: default CADET prescribed ionic strength versus legacy feedback."""
import copy
import unittest
import numpy as np
from tdm_minimal_io import (normalize_config, validate_config,
    sanitize_config_for_selected_model, batch_shared_parameter_paths)
from tdm_minimal_model import simulate
from tests.test_cpa_binding_audit import binding_recipe


class CADETPrescribedModeTests(unittest.TestCase):
    def recipe(self):
        cfg = binding_recipe(0.012)
        cfg['numerics'].update(time_steps=50, axial_positions=5)
        cfg['feed']['load_density_mg_mL_resin'] = 1.0
        return cfg

    def test_mode_survives_normalization_batch_and_sanitization(self):
        cfg = self.recipe()
        cfg['cpa']['ionic_strength_mode'] = 'COUNTERION_COUPLED_LEGACY'
        self.assertEqual(normalize_config(cfg)['cpa']['ionic_strength_mode'], 'COUNTERION_COUPLED_LEGACY')
        self.assertEqual(sanitize_config_for_selected_model(cfg)['cpa']['ionic_strength_mode'], 'COUNTERION_COUPLED_LEGACY')
        self.assertIn('cpa.ionic_strength_mode', batch_shared_parameter_paths(cfg))
        cfg['cpa']['ionic_strength_mode'] = 'NOT_REAL'
        self.assertTrue(any('ionic strength mode' in x for x in validate_config(cfg)))

    def test_default_does_not_couple_counterions_into_adsorption_or_conductivity(self):
        cfg = self.recipe()
        cfg['cpa']['ionic_strength_mode'] = 'PRESCRIBED'
        result = simulate(cfg)
        sim = result['simulation']
        report = sim['diagnostics']['counterion_exchange']
        self.assertEqual(report['ionic_strength_mode'], 'PRESCRIBED')
        self.assertFalse(report['tracked_ion_state'])
        trace = result['trace']
        baseline = sim['mobile_phase'].baseline.outlet(trace['t_s'])
        np.testing.assert_allclose(trace['ionic_strength_M'], baseline[:, 2], rtol=0, atol=1e-12)
        np.testing.assert_allclose(trace['column_conductivity_mS_cm'], baseline[:, 3], rtol=0, atol=1e-12)
        np.testing.assert_allclose(trace['counterion_pair_excess_M'], 0.0, atol=1e-12)
        self.assertIsNone(report['maximum_released_inventory_umol'])

    def test_legacy_mode_remains_reproducible(self):
        cfg = self.recipe()
        cfg['cpa']['ionic_strength_mode'] = 'COUNTERION_COUPLED_LEGACY'
        result = simulate(cfg)
        report = result['simulation']['diagnostics']['counterion_exchange']
        self.assertTrue(report['tracked_ion_state'])
        self.assertGreater(report['maximum_released_inventory_umol'], 0)
        self.assertLess(abs(report['closure_percent_of_maximum_released_inventory']), 1.0)


if __name__ == '__main__':
    unittest.main()
