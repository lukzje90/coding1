"""Illustrative eight-species Briskot Figure 2c TDM+CPA simulation.

The published main article omits feed fractions, feed concentration, pH,
buffer salt recipe, and UV response factors. Assumptions below are therefore
explicit; the output is not a reconstruction of the measured chromatogram.
"""

import copy
import csv
import json
import math
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

MODEL = Path(__file__).resolve().parents[1]
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(MODEL))

import tdm_minimal_io as io
from tdm_minimal_model import simulate

if io.MAX_IMPURITIES < 7:
    raise RuntimeError("This benchmark needs the model version with seven impurity slots.")

SPECIES = [
    # name, assumed feed mass %, MW kDa, radius nm, keff um/s,
    # k*kin /s, Zref, log10 Delta, Zlat (Briskot et al. Table 1).
    ("Main",         30.0, 150.0, 5.5, 0.60, 7.67e7,  84.47, -2.18, 44.04),
    ("Acidic",       45.0, 150.0, 5.5, 0.60, 5.98e6,  73.18, -1.19, 25.79),
    ("Basic",        18.0, 150.0, 5.5, 0.60, 5.78e7,  84.64, -2.00, 54.69),
    ("HMW",           3.0, 300.0, 7.2, 0.51, 1.29e6, 140.49, -2.72, 35.77),
    ("LMW 1",         1.5,  75.0, 4.1, 0.60, 1.78e4,  38.92, -0.03, 28.58),
    ("LMW 2",         1.0,  75.0, 4.1, 0.80, 1.58e4,  33.30,  0.22, 11.60),
    ("HCP",           1.0, 150.0, 5.5, 0.67, 2.38e5,  74.85, -1.16, 59.98),
    ("Protein A",     0.5,  50.0, 3.2, 0.92, 6.72e5,  37.96, -0.86, 31.45),
]


def make_case(cells: int, steps: int):
    cfg = io.load_config(MODEL / "cpa_poros50hs_mab1_example.json")
    cfg["impurity_count"] = 7
    # 100 cm/h superficial velocity times cross-section V/L.
    cfg["column"].update(volume_mL=1.91, length_mm=97.2,
                         flow_mL_min=(1.91 / 9.72) * 100.0 / 60.0)
    cfg["feed"].update(total_concentration_mg_mL=12.0,
                       load_density_mg_mL_resin=123.0)
    cfg["numerics"].update(axial_positions=cells, time_steps=steps)
    cfg["tdm"].update(void_fraction=0.39, particle_porosity=0.87,
                      bead_radius_um=25.0, salt_axial_dispersion_mm2_s=0.78)
    cfg["system"].update(buffer_dispersion_enabled=False,
                         buffer_dispersion_mL=0.0,
                         salt_dispersion_enabled=True,
                         salt_dispersion_mm2_s=0.78)
    cfg["cpa"].update(ligand_surface_density_umol_m2=0.6,
                      ligand_pK=2.3, ionic_strength_mode="PRESCRIBED")

    base = cfg["components"][0]
    rows = []
    for name, mass, mw, radius, keff, kkin, charge, logdelta, zlat in SPECIES:
        row = copy.deepcopy(base)
        row.update(name=name, mass_percent=mass,
                   molecular_weight_kDa=mw, diameter_nm=2.0*radius,
                   accessible_particle_porosity=0.87,
                   As_m_inv=0.75e9, D_ax_mm2_s=0.78,
                   k_eff_um_s=keff, kkin_star_s=kkin,
                   Z_ref=charge, Z_lat=zlat, delta_ref=10.0**logdelta,
                   pH_ref=5.0, Z1_per_pH=0.0, Z2_per_pH2=0.0,
                   Z3_per_pH3=0.0, delta_pH_slope_m2_C=0.0,
                   uv_response_factor_mAU_L_g=58.0)
        rows.append(row)
    cfg["components"] = rows

    p = cfg["process"]
    p["load_amount_basis"] = "CAPACITY"
    p["load_CV"] = 123.0 / 12.0
    p["load_volume_mL"] = p["load_CV"] * 1.91
    p["plw_count"] = 1
    p["plw_steps"][0].update(CV=5.5, flow_mL_min=cfg["column"]["flow_mL_min"],
                              start_percent_B=0.0, end_percent_B=0.0)
    p["elution_count"] = 1
    p["elution_steps"][0].update(CV=25.0, mode="LINEAR",
                                  flow_mL_min=cfg["column"]["flow_mL_min"],
                                  start_percent_B=0.0, end_percent_B=100.0)
    p["load_start_percent_B"] = p["load_end_percent_B"] = 0.0
    for which, salt, cond in (("buffer_A", 0.0, 4.0),
                              ("buffer_B", 0.30, 29.0)):
        buffer = p[which]
        buffer.update(pH=5.0, salt_concentration_M=salt,
                      conductivity_mS_cm=cond)
        for ion in buffer["ions"]:
            if ion["species"] == "Na+":
                ion["concentration_M"] = 0.01634743335052317 + salt
            elif ion["species"] == "Cl-":
                ion["concentration_M"] = salt
    return io.normalize_config(cfg)


def main():
    cells = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    steps = int(sys.argv[2]) if len(sys.argv) > 2 else 240
    cfg = make_case(cells, steps)
    errors = io.validate_config(cfg, strict=True)
    if errors:
        raise ValueError("Invalid illustrative Figure 2c case:\n" + "\n".join(errors))
    (OUT / "figure2c_all_species_assumed_config.json").write_text(json.dumps(cfg, indent=2) + "\n")
    print("validated", cells, steps, flush=True)
    if len(sys.argv) > 3 and sys.argv[3] == "config-only":
        return
    result = simulate(cfg)
    trace = result["trace"]
    volume = np.asarray(trace["volume_mL"], dtype=float)
    components = np.asarray(trace["component_g_L"], dtype=float)
    total = np.sum(components, axis=1)
    with (OUT / f"figure2c_all_species_{cells}cells.csv").open("w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow(["volume_mL", "total_g_L"] + [r[0]+"_g_L" for r in SPECIES])
        writer.writerows(zip(volume, total, *components.T))
    peak = int(np.argmax(total))
    metrics = {
        "cells": cells,
        "steps": steps,
        "peak_mL": float(volume[peak]),
        "peak_g_L": float(total[peak]),
        "component_peak_g_L": {name: float(np.max(components[:, i]))
                               for i, (name, *_) in enumerate(SPECIES)},
        "mass_balance": result["mass_balance"],
        "maximum_coverage": result["simulation"]["diagnostics"].get("maximum_surface_coverage_fraction"),
    }
    (OUT / f"figure2c_all_species_{cells}cells_metrics.json").write_text(json.dumps(metrics, indent=2) + "\n")
    fig, axes = plt.subplots(2, 1, figsize=(10, 8), sharex=True)
    axes[0].plot(volume, total, color="black", lw=2.3)
    axes[0].set_ylabel("Total protein (g/L)")
    axes[0].set_title("Illustrative mAb3 / Capto S ImpAct, 123 g/L, eight species")
    for i, (name, *_) in enumerate(SPECIES):
        axes[1].plot(volume, components[:, i], lw=1.5, label=name)
    axes[1].set(xlabel="Outlet volume (mL)", ylabel="Individual protein (g/L)")
    axes[1].legend(ncol=4, fontsize=8)
    for ax in axes:
        ax.grid(alpha=0.2)
        ax.set_xlim(0.0, 80.0)
    fig.tight_layout()
    fig.savefig(OUT / f"figure2c_all_species_{cells}cells.png", dpi=170)
    print(json.dumps({k: v for k, v in metrics.items() if k != "mass_balance"}, indent=2), flush=True)


if __name__ == "__main__":
    main()
