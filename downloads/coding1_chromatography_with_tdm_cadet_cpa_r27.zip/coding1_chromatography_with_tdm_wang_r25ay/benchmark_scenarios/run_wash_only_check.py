"""Optional 100-200 cell load/wash convergence (not full gradient)."""
import json,sys,time,os
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tdm_minimal_model import simulate
name=sys.argv[1]
path=ROOT/'benchmark_scenarios'/name
c=json.loads(path.read_text())
c['process']['elution_count']=0
c['numerics']['time_steps']=650
start=time.perf_counter()
limit=float(os.getenv("FEED_BENCHMARK_TIMEOUT_S", "600"))
try:
    result=simulate(c,solver_deadline=time.perf_counter()+limit)
    vol=np.asarray(result['trace']['volume_mL']); uv=np.asarray(result['trace']['uv_mAU'])/1000.0
    m=(vol>=6.0)&(vol<=12.0)
    idx=np.where(m)[0][np.argmax(uv[m])]
    stages=result['simulation']['diagnostics']['CPA_adsorption_audit']['stages']
    r={'scenario':name,'axial_cells':c['numerics']['axial_positions'],'feed_I_M':c['process'].get('load_ionic_strength_M'), 'seconds':round(time.perf_counter()-start,2),
       'early_peak_AU':float(uv[idx]),'early_peak_mL':float(vol[idx]),
       'wash_outlet_mg':stages[1]['outlet_g'][0]*1000,'load_outlet_mg':stages[0]['outlet_g'][0]*1000,
       'mass_error_pct':next(iter(result['mass_balance'].values()))['closure_error_percent_of_input']}
    print('RESULT',json.dumps(r),flush=True)
    (ROOT/'benchmark_scenarios'/(path.stem+'_wash_only_results.json')).write_text(json.dumps(r,indent=2))
    import csv
    with (ROOT/'benchmark_scenarios'/(path.stem+'_wash_only_trace.csv')).open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['volume_mL','uv_AU']);w.writerows(zip(vol,uv))
except Exception as e:
    print('FAILED',type(e).__name__,str(e),'seconds',round(time.perf_counter()-start,1),flush=True)
    raise
