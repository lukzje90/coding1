# CADET CPA consistency fixes — 20 November 2026

Reference: <https://cadet.github.io/master/modelling/binding/colloidal_particle_adsorption.html>

## Modified files (original names preserved)
- `tdm_minimal_model.py`
- `tdm_minimal_io.py`
- `tdm_inputs.json`
- `cpa_poros50hs_mab1_example.json`
- Tests added/updated under `tests/`.

## Changes
1. **CADET prescribed ionic-strength mode is the default:** `cpa.ionic_strength_mode = "PRESCRIBED"`. Protein adsorption uses the local prescribed pore ionic-strength profile calculated by the process chemistry transport. **No additional protein counter-ion feedback** changes the adsorption ionic strength or displayed conductivity. The optional historical approximation is available only with `"COUNTERION_COUPLED_LEGACY"` and retains its own ion-state variables. This is an approximation and not a full electrolyte speciation model.
2. **Remove the incorrect monodisperse 0.9069 hard cutoff.** The CADET scaled-particle equation is defined for total surface area fraction `Theta < 1`. A hexagonal monodisperse packing fraction of `pi/(2 sqrt(3))` is a physical reference, not CADET's imposed equation-domain cutoff. The solver still rejects `Theta >= 1`.
3. **Recover temporary BDF Newton-trial coverage overshoots:** Reject and retry a smaller time step after restoring BDF predictor history; persistent violations generate a clear error. Invalid opposite-charge or ionic-strength conditions remain errors rather than fabricated adsorption laws.
4. **Show the selected ionic-strength mode in model diagnostics.** Prescribed mode's counter-ion inventory is marked as diagnostic potential release only, not as a completed ion transport balance.
5. **Preserve the `STANDARD_SPT` pi-squared formulation** and the existing exact log-domain adsorption kinetics; **do not adjust fitted CPA parameters** without experimental fitting.
6. **Reduce runtime in prescribed mode:** No longer integrate 2N extra counter-ion ODE states. The single-protein scalar rate optimization and the subnormal-density division-by-zero repair are retained.

## What this is NOT
- Not a full CADET-Core electrolyte/proton/Davies transport model. The helper function for concentration-based Davies speciation requires real pore-component concentrations and valences; the supplied process only has buffer blends and prescribed pH/ionic strength.
- Not a new fitted data set. Published Briskot mAb1 parameters were fit with the authors' conventions; switching the steric formulation to CADET's pi-squared equation changes the fitted model and can require recalibration.
- Not a validated quantitative reproduction of Huuk Run 2 / Briskot Fig. 2a. A low predicted loading breakthrough remains even when the ion feedback is disabled.

## Configuring
In `tdm_inputs.json` under `cpa`:

```json
"ionic_strength_mode": "PRESCRIBED"
```

To reproduce older simulations with extra counter-ion release feedback (not CADET prescribed mode), select `COUNTERION_COUPLED_LEGACY`. The selection survives normalizing and batch run parameter persistence.

## Numerical checks
- New prescribed-mode and legacy-mode simulation tests, BDF coverage-domain tests, CADET adsorption-formula tests, and the POROS 50 HS benchmark tests are included.
- A full 100-cell experimental peak fit was *not* performed; the calculation is too slow to warrant claiming empirical validation without raw experimental chromatogram data.
