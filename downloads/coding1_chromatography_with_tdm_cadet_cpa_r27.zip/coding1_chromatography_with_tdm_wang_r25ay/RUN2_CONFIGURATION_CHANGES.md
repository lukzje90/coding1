# Figure 2a / Figure 1B — prepared Run 2 project

## What changed
- `tdm_inputs.json` is now included and matches `cpa_poros50hs_mab1_example.json`.
- `tdm_batch_runs.csv` **Run 1** now contains Huuk et al. experimental **Run 2** operating conditions. The other 29 saved rows are unchanged. Choose **Run 1** in the JMP interface; the row name is `Figure 2a - Huuk Run 2 (90 g/L)`.
- The previous ZIP did not include `tdm_inputs.json` and its saved Run 1 row was still at default settings. This explains why a previously plotted chromatogram could show 0.033 / 0.44 M conductivity-derived salt and a 30 CV gradient despite the corrected example JSON.

## Applied settings
- POROS 50 HS, 0.981 mL bed, 50 mm length; flow 0.080 mL/min.
- Load 90 g/L resin, 12.7 mg/mL protein (7.0866 CV).
- Initial bed pre-equilibrated at 10 mM citrate pH 5.0, **0 M added NaCl**. The solver represents this as an initial liquid state, not 10 simulated CV of equilibration.
- Wash 5 CV; main elution 30.63 CV, 0→0.45 M added NaCl; **post-elution 5 CV at 1 M NaCl** modeled as a second, direct-chemistry SET_POINT elution stage. Run output extends past the published Figure 2a plotting window.
- CADET `STANDARD_SPT` steric convention; previously fitted Briskot CPA parameters retained **without refitting**.

## Important assumptions (not published measurements)
- The publication specifies 10 mM sodium citrate pH 5.0 but not its full ion concentrations. The example uses an idealised 10 mM total citrate mixture split into H2Cit⁻ and HCit²⁻ using approximate pKa2=4.76 and electroneutral Na⁺. Minor neutral and citrate³⁻ fractions are omitted. Computed ionic strengths are approximately 0.0227 M (A) and 0.4727 M (B). **This is not experimental ionic-strength data.**
- The feed in Huuk et al. was diluted to conductivity **below 2.5 mS/cm**. The present solver uses Buffer A composition as an approximation for feed chemistry; the exact feed composition is not available. This must be checked before quantitative peak fitting.
- Entered conductivity endpoints (3 and 40 mS/cm), UV scaling (58 mAU·L/g), and the conversion factor (0.011 M/(mS/cm)) are unvalidated plotting estimates. The selected SALT_M input remains authoritative for added NaCl.
- The last 5 CV 1 M added NaCl stage is resolved as a direct 1 M monovalent salt, and does not fully include the citrate offset.
- The published parameters were fitted using Briskot's published CPA convention. CADET's hard-disc π² convention may require refitting. **A correctly entered recipe alone is not proof of Figure 2a reproduction.**

## Verification
1. Open this extracted project in JMP, choose **Run 1** and simulate. Do not overwrite `tdm_inputs.json` and `tdm_batch_runs.csv` with older saved copies.
2. Inspect the PDF's 'Inputs actually used' and stages: `SALT_M`, Buffer A 0 M / Buffer B 0.45 M, 30.63 CV, and Run 1 at 0.080 mL/min.
3. Compare the high-loading breakthrough and peak shape with the published Figure 1B / Figure 2a after matching the UV calibration and feed citrate content.

Sources: Huuk et al., Biotechnology Journal 12 (2017) 1600336 Table 1 Run 2, Figure 1B; Briskot et al., J Chromatogr A 1654 (2021) 462439 Table 1 and Figure 2a; CADET CPA documentation at https://cadet.github.io/master/modelling/binding/colloidal_particle_adsorption.html.

The result receipt Build label for this distribution is `2026-11-20-FIG2A-CADET-RUN2`. The build label identifies this package; it does not certify chromatographic agreement.
