# CADET CPA molecular mass handoff and Figure 2c example

## What changed

The JMP interface previously sent the visible CPA molecular-mass value and then
overwrote it with the hidden Xu–Lenhoff molecular-mass value under the same
Python variable name. The latter is now sent only when Xu–Lenhoff is selected.
For CPA, the entered molecular mass reaches the run configuration directly.
The result receipt records each species' molecular mass and derived molar feed
concentration.

CADET's CPA binding law does **not** have a molecular-weight parameter. The
application needs molecular mass because its feed and detector outputs are
mass-based, while the CPA states are in mol/m³. For species *i*, the model uses
`c_feed,i [mol/m³] = c_feed,total [g/L] × feed_mass_fraction,i / MW_i [kDa]`
and `c_out,i [g/L] = c_out,i [mol/m³] × MW_i [kDa]`. The protein radius is a
separate measured or fitted input; it is not inferred from molecular mass.

The retired EDM-only `system_specific_adsorption_parameter` is removed from
new and normalized TDM + CPA configurations. A species-specific pore porosity
is neither required nor shown for TDM + CPA; the transport model uses the
column's particle porosity. The unused HIC salt-sensitivity field is not fed
to CPA. Seven impurity slots are now available, allowing the eight species in
the Figure 2c example. Existing six-component configurations are padded with
empty slots without changing their saved species or process inputs.

## CADET equation mapping

The active TDM + CPA binding path uses CADET's regulated adsorber charge,
Debye screening, protein charge polynomial, charge-density dependent
interaction-layer thickness, attractive-minimum energy, Henry factor,
pi-squared hard-disc surface blocking, hexagonal lateral interaction, and
kinetic rate. The old empirical energy multiplier and single-pi steric form
are not selectable in the active path. The model's `STANDARD_SPT` validation
rejects saved parameters fitted under the old single-pi convention rather
than silently reinterpreting them.

The chromatography transport and chemistry solver remains this application's
TDM implementation. It supplies local prescribed pH and ionic strength to
the CADET CPA binding equations; it is not CADET-Core's fully transported
proton/ion/Davies mode. This is why matching the binding equations does not
imply an identical CADET chromatogram at every time point.

## Figure 2c example

`benchmark_scenarios/figure2c_all_species_assumed.py` builds an eight-species
Capto S ImpAct mAb3 case using Briskot et al.'s Table 1 CPA parameters and
the 123 g/L, 5.5 CV wash, 25 CV gradient condition indicated by Figure 5c.
`Main` is the target protein, followed by Acidic, Basic, HMW, LMW1, LMW2,
HCP, and Protein A. The article does not report the feed species fractions,
total feed concentration, complete salt/buffer recipe, or UV response factors
for this trace. The example therefore assumes 30% Main, 45% Acidic, 18%
Basic, 3% HMW, 1.5% LMW1, 1% LMW2, 1% HCP, and 0.5% Protein A; 12 mg/mL
total feed; pH 5; and a 0–0.30 M NaCl gradient. Its graph reports g/L, not
an independently predicted absorbance. It is an illustrative simulation,
not a quantitative reproduction of the paper's measured trace.

The 48-cell simulation produces a narrow breakthrough peak near 20.5 mL and
a broad elution region near 52 mL. All eight species' mass-closure errors
were below 0.001% of their respective applied masses in that run. The
24-to-48-cell breakthrough peak height changed about 2.2%, so further grid
refinement would be needed for a numerical convergence claim.

## Independent CADET benchmark

See `CADET_CORE_FIG2B_BENCHMARK.md` for the independent CADET Figure 2b
comparison. At 100 axial cells, the main peak height agrees to about 0.001%,
while the full-trace error is 0.641% of the reference peak height. A uniform
0.751 mL shift of this application's trace reduces that error to 0.218%,
accounting for about 88% of the squared discrepancy. The residual difference
is consistent with differing spatial and ion-transport discretizations; the
comparison does not identify a missing CPA molecular-mass term.
