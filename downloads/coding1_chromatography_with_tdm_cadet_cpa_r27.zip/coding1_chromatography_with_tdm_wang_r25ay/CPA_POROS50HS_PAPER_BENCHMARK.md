# Poros 50 HS / mAb1 CPA benchmark

The example `cpa_poros50hs_mab1_example.json` follows Table 1 and Fig. 2(a)
of Briskot et al., *J. Chromatogr. A* 1654 (2021) 462439, using the user's
corrected **90 g/L column load** for the Fig. 2(a) run. The attached Briskot
paper reproduces that figure from Huuk et al., *Biotechnol. J.* 12 (2017)
1600336 but does not state the exact Fig. 2(a) load in its own caption. It is
a TDM + CPA CEX example, not a calibration for another resin.
The JSON is a complete direct-Python simulation recipe. JMP keeps each run's
process recipe in its run table, so setting up this run in JMP also requires
entering the load, wash, and gradient in Process Setup.

| Paper value | JMP CPA input | Stored solver value |
| --- | --- | --- |
| Particle diameter 50 µm | 50 µm | `bead_radius_um = 25` |
| Protein radius 5.5 nm | 5.5 nm | `diameter_nm = 11` |
| Accessible area 0.22 nm⁻¹ | 0.22 nm⁻¹ | `As_m_inv = 2.2e8` |
| log₁₀ Δ = −1.90 | −1.90 | `delta_ref = 0.012589254...` |
| k*kin = 4.61e7 s⁻¹ | 4.61e7 s⁻¹ | 4.61e7 s⁻¹ |
| Z(pH_ref) = 80.45 | Z_ref = 80.45 | 80.45 |
| No pH charge slopes | Z1 = Z2 = Z3 = 0 | 0, 0, 0 |

The other Table 1 model values are εv = 0.53, εp = 0.54,
ΓL = 2.89 µmol/m², Dax = 0.06 mm²/s, keff = 1.01 µm/s,
Zlat = 19.07, and the assigned antibody mass is 150 kDa. At pH_ref = 5,
the charge polynomial gives Z(5) = 80.45 and Z at every other pH is also
80.45 when the three slopes are zero.

The example uses 0.981 mL, 50 mm, 0.239 mL/min, 12.7 mg/mL,
**90 g/L column loading** (7.0866 CV, 6.952 mL, 88.29 mg), a 5 CV wash, and
a 31.81 CV 0–100% B gradient. The incoming load, wash, and gradient start at
0% B; the gradient begins after 12.0866 CV or 11.857 mL of pumped volume.
Buffer A is represented as 10 mM citrate, 3 mS/cm; Buffer B adds 0.45 M
NaCl and is 40 mS/cm. The example assumes citrate²⁻ and Na⁺ for its ion
composition. The publication does not establish the exact citrate species,
mixing delay, dead volume, detector calibration, or all original Huuk run
details. The example's UV response factor (58 mAU·L/g) only scales the plotted
absorbance near Fig. 2(a)'s 0.5 AU maximum; it is not a measured detector
parameter.

![Predicted mAb1 UV chromatogram and conductivity at 90 g/L](cpa_poros50hs_90g_example_output.png)

With 700 output points and 40 axial cells, the numerical simulation produced
a load breakthrough peak near 7.5 mL and a shoulder ahead of a 0.503 AU main
peak at 22.76 mL. About 0.228% of loaded mass left during loading and 0.540%
during washing. Total protein mass-balance error was 0.00035% and maximum
surface coverage was 0.811. A separate 100-cell, 200-point calculation using
a 30 CV gradient (the recipe in the user's report) gave a main peak at 22.30 mL
and 0.529 AU, with 0.231% load breakthrough. The shoulder remained; it was
not created by the 40-cell mesh.

The corrected load produces a closer qualitative shape, but the predicted
load spike and elution front still differ from the experimental dashed curve
in Figure 2(a). That curve includes measured flow-rate oscillations that the
paper explicitly attributes to the chromatography system. The article's solid
CPA prediction is the appropriate equation comparison. This example is
**not an exact reproduction** of either curve.
The model uses finite volumes and SciPy BDF, while the paper uses SUPG and
IDAS. The accessible surface, lateral electrostatic interaction, adsorption
energy, equilibrium partition, kinetic rate, and TDM phase-balance equations
have been checked against the attached papers. Their implemented forms agree
with the cited equations. The remaining shape and timing differences cannot
be resolved from the available paper figure because the complete original
run recipe, measured system delays, detector response, and detailed ion
composition are unavailable. The example should not be used to claim
quantitative predictive accuracy without those measurements.

The accepted-step BDF safeguard repairs a negative phase overshoot by
redistributing protein among bulk, pore, and adsorbed phases within the same
axial cell. It preserves total protein inventory and rebuilds the BDF
history. A materially negative *total cell inventory* still raises an error.
The safeguard also rejects a correction larger than 1e−5 times the larger
of 1 mol/m³ and the current maximum phase magnitude, so it cannot silently
repair a large solver failure. In the eight-cell test its largest correction
was below 5e−9 mol/m³.
The published high kinetic value previously generated a negative pore state;
the benchmark now integrates it without replacing it by a smaller value.

The mAb2/Fractogel EMD SO₃ and mAb5/Poros 50 HS Table 1 parameter sets were
also run as solver stress checks. Both completed without material negative
phase concentrations. Those checks used the example gradient and an assumed
residence time, because their individual experimental run recipes were not
fully specified here; they do not compare predicted peaks with the paper.
