# Figure 2a / Huuk Run 2: feed-only ionic-strength correction

## Scientific status

**This is a code/configuration correction and a sensitivity study, not an experimentally calibrated fit.** The original Huuk experiment reports an antibody pool at pH 5, diluted with ultrapure water to **conductivity below 2.5 mS/cm**. It does **not** supply the measured citrate/sodium/chloride/acetate composition or ionic strength of this feed. The paper's equilibration/wash buffer is **10 mM sodium citrate, pH 5, zero additional NaCl**. Its exact feed speciation cannot be reconstructed from conductivity alone.

The model previously ignored `process.load_ionic_strength_M` in `_build_program()`, reverting to Buffer A/B ionic strength during loading. The fixed version accepts an **optional positive loading-feed ionic strength [M]**. It is applied only to the LOADING stage in prescribed-ionic-strength mode, without modifying wash/equilibration, user-entered NaCl, conductivity, pH or the published CPA parameters.

## Changes to the project

- `tdm_minimal_model.py`: honor `process.load_ionic_strength_M` in the loading stage; the report labels the feed override and shows the resolved loading ionic strength.
- `tdm_minimal_io.py`: add optional `Load_Ionic_Strength_M` to saved-run CSV schema, load/save, numeric type handling, and positive-value validation.
- `tdm_jmp.py`: provide an editable **Load feed ionic strength override [M] (optional)** field in the Run & load panel, independent of the load-material mode and independent of wash settings.
- `tdm_batch_runs.csv`: keep Run 1 as the unmodified buffer-derived 22.695 mM *modelled* feed and add Runs 2-4 as clearly labelled **hypothetical 10 mM** cases with 100, 150 and 200 axial cells.
- `benchmark_scenarios/*.json`: four standalone resolved configurations for reproducible baseline and sensitivity runs.
- `tests/test_feed_ionic_strength_override.py`: checks that the override survives CSV and JMP wiring, changes only the load stage, and rejects zero/negative molarities.

## Results: matched 100-cell load and wash

All predictions below are for the same published mAb1 CPA parameters, 90 g/L packed-resin load, 12.7 mg/mL feed, 0.080 mL/min flow, same 10 mM citrate wash, and **100 finite-volume axial cells**. Both runs were truncated after the 5 CV wash for efficient investigation of the early spike. UV factor remains the project's assumed 58 mAU per g/L. No empirical parameters were refitted.

| Calculated output | Run 1: no feed override (22.695 mM modelled feed) | Run 2: hypothetical 10 mM feed |
|---|---:|---:|
| Initial peak [AU] | 0.027972 | 0.122738 |
| Initial peak position [mL] | 7.5702 | 7.6067 |
| Protein leaving in loading [mg] | 0.010614 | 0.038773 |
| Protein leaving in 5 CV wash [mg] | 0.212155 | 0.744488 |
| Absolute mass-closure error [%] | ~0.000011 | ~0.000003 |

The early experimental spike in Figure 2a is visually around 0.16 AU, but this value is an approximate reading from a figure, **not digitised source data**. A closer spike height is suggestive, not proof of correct sample chemistry or model validity.

### Completed 100 / 150 / 200-cell convergence study (load + wash)

The 150- and 200-cell runs initially exceeded an overly short 105-second solver deadline. They were rerun with a longer allowed budget and **both completed**. Results below all use the same hypothetical 10 mM loading feed, published CPA parameters, unchanged 5 CV citrate wash, and 650 reported time intervals:

| Axial cells | Early spike [AU] | Spike position [mL] | Wash-out protein [mg] | Runtime [s] |
|---:|---:|---:|---:|---:|
| 100 | 0.122738 | 7.6067 | 0.744488 | 62.48 |
| 150 | 0.118767 | 7.5885 | 0.739973 | 116.24 |
| 200 | 0.118829 | 7.5702 | 0.738911 | 139.03 |

The spike height changes by approximately **0.052%** from 150 to 200 cells and wash-out mass by ~0.14%. The loading/wash result is therefore much more stable with axial resolution for the **hypothetical 10 mM** input. The experimental early spike (~0.16 AU by visual figure reading) is still higher than the computed 0.119 AU by about 0.041 AU (26%).

The full salt-gradient elution at 100/150/200 cells was not rerun for the new feed cases. This release **does not prove** that the original main elution-peak agreement is preserved at high resolution.

## How to run in JMP

1. Extract the ZIP into a separate project folder and launch it there. Do not mix an older `tdm_jmp.py` or saved-run CSV with the new modules.
2. In **Run & load**, see the new optional **Load feed ionic strength override [M]** field.
3. **Run 1** uses the existing buffer-derived feed (blank override). **Runs 2, 3 and 4** use `0.010` M as a **hypothesis**, at 100/150/200 cells. Each run shares Buffer A (0 added NaCl) and the 5 CV citrate wash unchanged.
4. Do not interpret the hypothetical 10 mM as a measured feed value. Replace it with measured/speciated feed ionic strength if available.
5. The 150/200-cell full chromatograms may be slow. Verify the output report's `load_input_used.feed_ionic_strength_override_M`, `material_ionic_strength_M`, and wash-stage `start_ionic_strength_M` rather than relying on a run label.

### Experimental measurements needed

Actual sample conductivity (number, not only the published upper bound), pH, buffer acid/base composition, residual acetate/chloride/NaCl from Protein A elution/neutralization, and dilution history. Conductivity cannot uniquely determine ionic strength without the ion composition or a calibrated composition-specific relationship.

## Files

- `benchmark_scenarios/fig2a_baseline_100cells.json`
- `benchmark_scenarios/fig2a_hypothetical_feed_10mM_100cells.json`
- `benchmark_scenarios/fig2a_hypothetical_feed_10mM_150cells.json`
- `benchmark_scenarios/fig2a_hypothetical_feed_10mM_200cells.json`
- `benchmark_scenarios/run_wash_only_check.py` (load/wash convergence-only test)
- `benchmark_scenarios/*_wash_only_trace.csv` and `*_wash_only_results.json` (all four completed cases)
- `benchmark_scenarios/figure2a_feed_grid_convergence.png` (four-curve comparison)
- `benchmark_scenarios/figure2a_feed_grid_convergence_summary.csv` (simulation metrics)

## Test status

28 relevant CPA and new feed-input tests passed. An optional wider group included failures in legacy EDM model branches that were already unsupported by the currently selected TDM interface; these are unrelated to the new feed override. The solver and benchmark need additional whole-chromatogram validation and higher-grid convergence checks before asserting quantitative reproduction.
