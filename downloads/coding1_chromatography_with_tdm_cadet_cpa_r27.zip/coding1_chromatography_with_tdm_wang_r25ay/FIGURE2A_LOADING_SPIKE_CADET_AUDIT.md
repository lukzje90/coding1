# Figure 2a loading spike — CADET CPA audit (20 November 2026)

## Key result

The initial experimental peak (about 0.16 AU at ~8 mL in Briskot et al. 2021 Fig. 2a) is notably higher than the peak of the **published CPA simulation in the same figure**, which is only about 0.02–0.04 AU by visual estimate. The standalone 40-axial-cell Python run previously produced ~0.0276 AU at 7.69 mL; its main elution peak was ~0.485 AU. Experimental and published-model heights are graphical estimates, not digitized source data.

The discrepancy must not be interpreted as evidence that a CADET equation is missing a coefficient. The source paper's fitted CPA model does not fully reproduce the initial experimental spike either.

### Equation inspection

CADET reference: https://cadet.github.io/master/modelling/binding/colloidal_particle_adsorption.html

The current model matches the stated valid-domain forms of:
- Kinetic adsorption law `dq_s/dt = kkin * (Kv * cp - q_s)`.
- Inverse Debye length, adsorber surface charge regulation, protein surface potential and the attractive minimum.
- Henry coefficient `KH = (1 - exp(-u_A/kBT))/(u_A/kBT)` and its limiting value 1.
- Scaled-particle available surface function with the **pi-squared** final term.
- Lateral hexagonal/Yukawa interaction, `Kv = delta * KH * B * exp(-u_lat/kBT)` and `kkin = kkin_star*y^2/[2(cosh(y)-1)]`.
- Validity checks `Theta < 1` and opposite, unequal surface potentials.

These are *formula* checks and do not replace CADET-Core-versus-Python chromatogram comparison. CADET-Core was not available in this environment for a direct solver reference run.

### Loading equilibrium

At pH 5, feed 12.7 mg/mL, prescribed I=0.022695 M, published mAb1 CPA parameters and 0.22 nm^-1 accessible surface parameter, the computed local homogeneous equilibrium capacity is ~102.46 g protein/L packed resin. This is not a dynamic binding capacity measured in an experiment. The actual applied load is 90 g/L, so the model's near-complete capture is consistent with its own isotherm. Using A_s=0.219 or 0.221 nm^-1 gives approximately 102.00 and 102.93 g/L, respectively; using Z_lat=18.67 or 19.47 gives 102.55 and 102.37 g/L. Small changes around the published parameters do not close the gap.

### Grid resolution comparison (same corrected model and Run 2 recipe)

| Axial cells | Cell Pe, approx. | Peak <12 mL (AU) | Load outlet (% of load) | Wash outlet (% of load) |
| ---: | ---: | ---: | ---: | ---: |
| 8 | 13.35 | 0.1115 | 0.0350 | 1.274 |
| 12 | 8.90 | 0.1218 | 0.0327 | 0.826 |
| 24 | 4.45 | 0.0519 | 0.00621 | 0.332 |

500 uniformly spaced output intervals, numerical results rounded. These grids are **not converged for the early spike** and should not be used to fit an experimental spike. A separate earlier 40-cell simulation produced a ~0.0276 AU spike, but was not generated within this identical three-grid sweep. A matched 40/60-cell extension did not finish before the execution limit. The 100-cell default remains unchanged.

At sharp load/wash fronts the monotonized-central limiter can revert to first-order upwinding. The first-order numerical-diffusion scale u*dx/2 is ~0.40, 0.27, 0.13, and 0.032 mm2/s for 8, 12, 24, and 100 cells, respectively. Physical protein Dax is 0.06 mm2/s. The diagnostic is an *estimate* near discontinuities, not a substitute for measured convergence.

### Code validation fix

The prior `tests/test_cpa_poros50hs_paper_benchmark.py` combined 90 g/L (Huuk Run 2) with 0.239 mL/min and 31.81 CV (Huuk Run 1). It incorrectly asserted a certain amount of loading breakthrough, potentially masking the discrepancy. This test now reads the real active Run 2 configuration at 0.080 mL/min and 30.63 CV; the test verifies conservation and a nonzero early pulse but **does not claim an experimental match**.

`tdm_minimal_model.py` now reports `axial_grid_cell_peclet_max` and a front numerical-diffusion estimate, and warns when the cell Peclet number exceeds 2. These changes are diagnostic only; the CPA and TDM equations and the standard 100-cell project configuration are unchanged. Direct before/after comparison of the 8-cell simulation showed **zero numeric change** in the UV, protein concentration, volume, loading and wash outlet values.

### Unresolved differences requiring data or model extensions

- The original Huuk protein feed had conductivity **below 2.5 mS/cm**; the example loads Buffer A at 3 mS/cm. This is not an experimentally matched feed-ion composition and could be explicitly configured once measured feed ionic composition and pH are known.
- The publication reports 98.3% monomer, but Briskot's mAb1 model uses a single protein component. The nature/retention of the nonmonomer fraction is not given; adding a hypothetical component would be a *new fitted assumption*, not a verified correction.
- Actual detector path length/UV response, upstream/downstream holdup, valve-switching effects and raw experimental loading/wash UV measurements are needed to attribute the narrow spike uniquely.
- Briskot's published fitted parameters were obtained under the authors' original conventions; retaining them while switching to CADET's pi-squared scaled-particle convention may require refitting. Fitting only the spike could degrade the already reasonable main elution profile.

**Conclusion:** No further error in the valid-domain CADET CPA equation coefficients was demonstrated. The initial-spike discrepancy is primarily an unresolved model-versus-experiment/parameter-identification problem, compounded by severe grid sensitivity on coarse verification runs. Do not hard-code a spike or tune an isotherm solely to a raster image of the experiment.

### Sources

- Briskot et al., *Journal of Chromatography A* 1654 (2021), 462439; Fig. 2a p. 7, Table 1 p. 6, Eqs. 13–25 pp. 3–4.
- Huuk et al., *Biotechnology Journal* 12 (2017), 1600336; Run 2 Table 1 p. 3 and Figure 1B p. 4, feed conductivity and monomer content in Methods.
- CADET CPA documentation (linked above), accessed 20 Nov 2026.
