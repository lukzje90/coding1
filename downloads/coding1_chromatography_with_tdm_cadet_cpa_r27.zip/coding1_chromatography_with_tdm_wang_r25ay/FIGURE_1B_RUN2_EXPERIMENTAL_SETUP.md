# Figure 1B (Huuk et al. 2017) / Figure 2a (Briskot et al. 2021) — actual Run 2

## Published experiment (not assumptions)

- Resin: POROS 50 HS; packed column 0.981 mL, 5 mm inner diameter, 50 mm bed length.
- Running buffer: 10 mM sodium citrate, pH 5.0. Buffers differ by added NaCl.
- Feed: mAb1 12.7 mg/mL, adjusted to pH 5.0 and diluted to **conductivity below 2.5 mS/cm**.
- **Run 2 flow = 0.080 mL/min** (Run 1, 75 g/L, has 0.239 mL/min).
- Equilibrate 10 CV, 0 M *added* NaCl; load 7.1 CV, 90 g/L resin;
  wash 5 CV, 0 M added NaCl; elute linearly 30.63 CV from 0 to 0.45 M added NaCl;
  post-elution 5 CV at 1.0 M added NaCl. pH 5.0 for all stages.
- Total calculated dose for 0.981 mL at 90 g/L: 88.29 mg = 6.952 mL feed = 7.087 CV.

**Source:** Huuk et al. *Biotechnol. J.* 12 (2017) 1600336, Table 1 Run 2 (p.3),
Figure 1B and Table 2 (p.4), DOI 10.1002/biot.201600336.

## Published Briskot CPA parameters (mAb1, Table 1)

- Void fraction 0.53; particle porosity 0.54; particle diameter 50 µm;
  protein Dax 0.06 mm²/s; mass transfer coefficient 1.01 µm/s.
- Protein radius 5.5 nm, molecular weight 150 kDa, specific adsorber area 0.22 nm^-1
  (=2.2e8 m^-1), ligand surface density 2.89 µmol/m², ligand pK 2.3.
- Effective charge Z(pHref=5) = 80.45, lateral charge Zlat = 19.07,
  delta = 10^-1.90 = 0.0125892541, kkin* = 4.61e7 s^-1.
- No pH slopes when pH is fixed at 5.0.

## Important approximations in the example JSON

- The publication **does not provide the complete citrate acid/base speciation**, so
  `buffer_A` and `buffer_B` in this JSON use an *illustrative* charge-balanced
  20 mM Na+ / 10 mM citrate2- approximation, plus the indicated NaCl in Buffer B.
  This gives approximate I(A)=0.030 M and I(B)=0.480 M. It is NOT a measured
  ionic strength or full citrate speciation; replace with measured/validated buffer chemistry.
- Conductivities 3 and 40 mS/cm are illustration/plot-display estimates, not
  measured values from the paper. Feed conductivity below 2.5 mS/cm is stated
  in the paper, but the present process engine treats feed chemistry as Buffer A;
  this differs from a separate feed sample specification. Do not report exact
  equivalence or fit results without resolving it.
- UV factor 58 mAU·L/g is an illustration scale, **not a measured calibration**.
- The example JSON simulates load, wash, and main 30.63-CV gradient; original
  published post-elution 5 CV at 1 M NaCl must be added separately when required.
- The CPA model default is now `STANDARD_SPT` per CADET pi² hard-disc equation.
  Briskot's printed legacy form can be selected with `BRISKOT_PRINTED`.
  The published CPA fitted parameters were not recalibrated for the CADET
  convention; this example is NOT a quantitative reproduction of Figure 2a.

CADET reference: https://cadet.github.io/master/modelling/binding/colloidal_particle_adsorption.html
