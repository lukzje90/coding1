# CADET CPA performance update — 20 November 2026

## What was changed

1. Only CADET's standard two-dimensional hard-disc scaled-particle formula is now implemented. The quadratic packing term is `pi**2`, never the printed single-`pi` alternative. The saved setting remains `cpa.steric_convention: STANDARD_SPT` for compatibility with the JMP project.
2. A saved setting of `BRISKOT_PRINTED` is **rejected with a clear error**, rather than silently changing the adsorption model or fitted parameters. Any parameters calibrated for that former formula must be recalibrated separately.
3. Single-component TDM+CPA simulations now use a scalar kinetic-rate implementation that is algebraically equivalent to the general CADET equations, with no temporary 1-element NumPy arrays inside every axial-cell evaluation. Multi-component CPA and other adsorption models retain the existing path.
4. No flow rate, loading, pH, fitted CPA parameters, tolerances, axial grid, mass-balance equation, counter-ion balance, or published Run 2 recipe was changed by this performance patch.
5. Updated regression tests verify the CADET-only steric formula, reject the old convention, and compare the scalar and general CPA kinetic rates.

## Performance measured (same hardware and input settings)

| Benchmark | Unoptimized | Optimized | Notes |
|---|---:|---:|---|
| Huuk Run 2, 8 cells / 60 reported time steps | 6.67 s | 4.79 s | Both complete; approximately 1.39x speedup |
| Huuk Run 2, 24 cells / 120 reported time steps | >90 s (timed out) | 21.07 s | At least 4.3x faster on this benchmark; not a precise ratio |

The adaptive BDF solver may choose different internal steps after floating-point-level differences, so runtime speedups need not scale uniformly with cell count.

### Output consistency — 8-cell benchmark

| Metric | Old | New |
|---|---:|---:|
| Peak elution volume | 23.40499925 mL | 23.40499925 mL |
| Peak UV | 478.00117043 mAU | 478.00061120 mAU |
| Loading breakthrough (% of protein loaded) | 0.0346661822 | 0.0346660134 |
| Maximum surface coverage | 0.762302398 | 0.762302415 |

These are coarse-grid equivalence tests, not evidence of reproduction of experimental high-loading breakthrough. The 24-cell optimized run still has a loading breakthrough prediction of about 0.0062%, showing that the separate physical/calibration limitation remains unresolved.

## Verification and limitations

- 39 focused tests and 828 parameterized subtests passed after the speed/steric changes.
- Additional longer-running test groups were not completed in the time available.
- A pre-existing counter-ion test that treated zero-charge protein as a valid CPA adsorption state was revised to expect a strict CADET domain error, then explicitly select the legacy flow-through approximation for its nonbinding-control calculation.
- Reusing Briskot single-pi fitted parameters with CADET pi-squared blocking may require refitting. This update does not perform that calibration.
- The prescribed pH and ionic-strength model is not a full species-resolved proton/Davies transport model.
- The performance improvement specifically targets the single-protein Figure 2a TDM+CPA case; other models, and mixtures with multiple proteins, are unchanged.
