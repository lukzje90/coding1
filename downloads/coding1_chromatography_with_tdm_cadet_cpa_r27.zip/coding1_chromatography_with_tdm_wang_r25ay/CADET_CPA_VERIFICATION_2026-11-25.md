# CADET CPA equation and chromatogram verification — 25 November 2026

## Result

The uploaded R25ay solver **already implements CADET's CPA binding equations** for TDM + CPA. CADET's documentation cites Briskot et al. as the source of this CPA model; it is not a separate physical isotherm. The consequential convention difference from the older Python implementation is the second hard-disc surface-blocking term, which uses **pi squared** in CADET rather than the single pi printed in one Briskot equation. The uploaded solver uses pi squared in both its general multi-protein and scalar single-protein paths. No CPA equation was changed in this verification.

The current uploaded 90 g/L example was rerun and its stale plot and metrics were replaced. The example now reports 700 output intervals so that its narrow load/wash peak is adequately sampled. The process and fitted CPA parameters were not changed.

## Source comparison

Equation source: [CADET CPA documentation](https://cadet.github.io/master/modelling/binding/colloidal_particle_adsorption.html), and [CADET-Core `ColloidalParticleAdsorptionBinding.cpp`](https://github.com/cadet/CADET-Core/blob/a30f62b44e1c5861db3b6b8eb476588d505da860/src/libcadet/model/binding/ColloidalParticleAdsorptionBinding.cpp). The solver was checked against the documentation and C++ source at commit `a30f62b44e1c5861db3b6b8eb476588d505da860` for:

- Debye screening and regulated adsorber and protein surface potentials;
- pH-dependent protein charge and interaction-layer thickness;
- attractive-minimum energy and Henry factor;
- surface coverage and the pi-squared scaled-particle available-surface factor;
- hexagonal-lattice lateral interaction, volumetric equilibrium factor, and adsorption/desorption kinetics;
- units of `A_s` (m^-1 internally), radius (m), ionic strength (mol/m^3 inside Debye screening), and surface concentration (mol/m^2).

The application uses prescribed pore pH and ionic-strength profiles from its buffer setup. It does not simulate CADET's optional component-resolved proton transport and Davies speciation. A chromatogram comparison therefore tests the application as a whole, not bitwise equivalence with CADET-Core.

## Controlled equation comparison

Both runs used the **same uploaded 90 g/L Huuk Run 2 configuration**, current solver, 40 axial cells and 300 reported intervals. The comparison changed only the second hard-disc term in both the scalar and general CPA paths. The single-pi diagnostic was run in memory; it is not an option in the delivered model.

| Prediction | CADET pi-squared | Earlier printed single-pi |
| --- | ---: | ---: |
| Load/wash peak (AU) | 0.0306 | 0.0044 |
| Load/wash peak volume (mL) | 7.65 | 7.49 |
| Main peak (AU) | 0.4846 | 0.5290 |
| Main peak volume (mL) | 23.09 | 22.78 |
| Protein leaving during loading (% of load) | 0.00837 | 0.00154 |
| Protein leaving during wash (% of load) | 0.2577 | 0.0380 |

The CADET surface-blocking term gives a visibly larger small load/wash peak and an earlier elution front. The published *simulated* Figure 2a curve has a small load/wash peak on the order of 0.02–0.04 AU by visual inspection, so this change improves that feature. The paper's larger, narrow **experimental** spike is not fully reproduced by its own solid simulation curve. These visual estimates are not a fit against digitized experimental data.

See `cadet_vs_printed_single_pi.png` for the controlled plot.

## Current full-resolution example

The active example is Huuk Run 2 / Briskot Figure 2a: Poros 50 HS, mAb1, 0.981 mL column, 90 g/L applied load, 12.7 mg/mL feed, 0.080 mL/min, 5 CV wash and 30.63 CV gradient. The earlier README erroneously listed Run 1 flow and gradient settings with Run 2 loading; that description has been corrected.

| Numerical case | Load/wash maximum (AU) | Main maximum (AU) | Main volume (mL) |
| --- | ---: | ---: | ---: |
| 100 axial cells, 250 reported intervals | 0.02368 | 0.484996 | 23.0305 |
| 150 axial cells, 250 reported intervals | 0.02321 | 0.485032 | 23.0305 |
| **100 axial cells, 700 reported intervals (delivered example)** | **0.02741** | **0.484987** | **23.0038** |

At 250 output intervals the narrow load/wash peak falls between reported points, making its displayed height too low. The 100/700 example has 0.00865% whole-run protein mass-closure error, 0.0120% of loaded protein exits during loading and 0.2403% during washing. The generated `cpa_poros50hs_90g_example_trace.csv`, plot and metrics correspond to this same configuration and current solver, with configuration and solver SHA-256 hashes recorded in the metrics JSON.

The former plot and metrics in the uploaded ZIP were stale: they claimed a 0.5029 AU main peak at 22.76 mL, while rerunning the ZIP's then-current 100-cell/250-interval inputs gave 0.4850 AU at 23.03 mL. They were replaced rather than used as evidence.

The predicted main peak is broadly similar to the published simulated Figure 2a peak (visually about 0.5 AU near 23 mL). Exact agreement cannot be established without digitized source traces and measured feed ionic composition. Huuk reports feed conductivity below 2.5 mS/cm, while this example uses Buffer A at 3 mS/cm during loading. That difference is unresolved, not an equation correction.

## Next independent benchmark

CADET-Core provides a complete [Briskot Figure 2b CPA/TDM configuration](https://github.com/cadet/CADET-Core/blob/master/test/data/config_COL1D_CPA_Briskot_Fig2b.json) and [reference HDF5 outlet trace](https://github.com/cadet/CADET-Core/blob/master/test/data/ref_COL1D_CPA_Briskot_Fig2b.h5). This is a stronger numerical benchmark than judging raster Figure 2a peaks. Briskot et al., *Prediction of complex adsorption of a protein mixture on ion-exchange resins based on a colloidal particle adsorption model*, J. Chromatogr. A 1654 (2021) 462467, DOI 10.1016/j.chroma.2021.462467, is a separate multi-protein experimental candidate. Its complete transport and UV inputs still need to be confirmed before using it as a quantitative trace benchmark.

Parameters fitted under the older single-pi convention need refitting for the CADET convention. This verification does not claim a match to a narrow experimental artifact or a CADET-Core versus Python trace identity.
