# CADET-Core Figure 2b benchmark and TDM + CPA solver audit

## Sources and scope

The independent numerical reference is CADET-Core's
[`config_COL1D_CPA_Briskot_Fig2b.json`](https://github.com/cadet/CADET-Core/blob/a30f62b44e1c5861db3b6b8eb476588d505da860/test/data/config_COL1D_CPA_Briskot_Fig2b.json)
and [`ref_COL1D_CPA_Briskot_Fig2b.h5`](https://github.com/cadet/CADET-Core/blob/a30f62b44e1c5861db3b6b8eb476588d505da860/test/data/ref_COL1D_CPA_Briskot_Fig2b.h5),
checked against CADET's [CPA equation](https://cadet.github.io/master/modelling/binding/colloidal_particle_adsorption.html),
[CPA parameter interface](https://cadet.github.io/master/interface/binding/colloidal_particle_adsorption.html),
[general-rate transport](https://cadet.github.io/master/modelling/unit_operations/general_rate_model.html),
[time-integration](https://cadet.github.io/master/simulation/index.html), and
[spatial-discretization](https://cadet.github.io/master/interface/spatial_discretization_methods.html) guidance.
The committed CADET reference was generated with CADET 6.0.0a4; its input HDF5 values match the JSON for all CPA parameters.

The added `benchmark_scenarios/cadet_fig2b_translated.json` is a separate,
quick 24-cell benchmark case. `benchmark_scenarios/cadet_fig2b_100cells.json`
reproduces the finer comparison. Its outlet trace and comparison metrics are
in the same folder as CSV and JSON files. These cases do not replace
`tdm_inputs.json`, saved process setups, or fitted parameters. No CPA
adsorption equation or coefficient was changed.

## Input mapping

| CADET input | This model's input | Benchmark value |
| --- | --- | ---: |
| `CPA_LIGAND_DENSITY`, mol/m² | Ligand surface density, µmol/m² | 1.47 |
| `CPA_SPECIFIC_SURFACE_AREA`, m⁻¹ per solid volume | `As_m_inv` (180 m²/mL solid in the UI) | 1.8 × 10⁸ m⁻¹ |
| `CPA_RADIUS`, m | Protein diameter, nm | 11.0 |
| `CPA_EFFECTIVE_CHARGE_COEF`, row-major constant row | `Z_ref` | 111.79 |
| `CPA_EFFECTIVE_CHARGE_COEF`, higher-order rows | `Z1`, `Z2`, `Z3` | 0, 0, 0 |
| `CPA_LAT_CHARGE` | `Z_lat` | 61.87 |
| `CPA_DELTA_REF` | `delta_ref` | 9.120108393559096 × 10⁻⁵ |
| `CPA_KKIN`, s⁻¹ | `kkin_star_s` | 8.44 × 10⁷ |
| `CPA_LIGAND_PK` / `CPA_LIGAND_CHARGE_FULL` | CPA ligand pK / full charge | 2.3 / 0 |
| `CPA_TEMPERATURE` / `CPA_PERMITTIVITY` | CPA temperature / relative permittivity | 298.15 K / 78.3 |
| Initial ionic strength 69.97 mol/m³ | Buffer A ionic strength | 0.06997 M |
| `COL_DISPERSION`, m²/s | `D_ax_mm2_s` | 0.1 mm²/s |
| Protein `FILM_DIFFUSION`, m/s | `k_eff_um_s` | 0.51 µm/s |
| `PAR_RADIUS`, m | Bead radius | 32.5 µm |
| `COL_POROSITY` / `PAR_POROSITY` | Void / particle porosity | 0.34 / 0.39 |

The CADET feed is 0.106 mol/m³ protein. The application requires a mass-based
feed, so the benchmark uses a **150 kDa conversion scale** and enters 15.9
mg/mL. Predicted outlet g/L is divided by 150 to compare in CADET's mol/m³.
The resulting protein equations and molar chromatogram do not depend on this
arbitrary conversion scale.

The CADET column is 22.3 mL × 215 mm at 2.41998 mL/min. Its four sections map
to 8.04670 CV loading, 3.00598 CV washing, 9.56055 CV linear salt gradient,
and 2.17039 CV high-salt hold. The load density is 127.94 g/L packed column
under the 150 kDa scale. The gradient moves ionic strength from 0.06997 to
0.350128 M, and the last hold is 0.345 M.

## Quantitative result

The table compares full protein outlet concentration after interpolating the
application prediction onto CADET's 2,000 time points. The RMSE is divided by
the CADET peak height of 0.157911 mol/m³. CADET uses 100 finite-volume cells
and WENO3 reconstruction; this application uses a monotonized-central
finite-volume limiter.

| Application axial cells | Full-trace RMSE (% of CADET peak) | Main peak (mol/m³) | Load/wash maximum (mol/m³) |
| ---: | ---: | ---: | ---: |
| 8 | 3.23 | 0.15609 | 0.03233 |
| 24 | 1.26 | 0.15763 | 0.02706 |
| 32 | 0.95 | 0.15774 | 0.02234 |
| 40 | 0.82 | 0.15782 | 0.02274 |
| 60 | 0.68 | 0.15788 | 0.02198 |
| 100 | **0.64** | **0.15791** | **0.02091** |
| CADET reference | — | **0.15791** | **0.02099** |

The apparent loading feature changes appreciably with the axial grid, while
the main elution peak and mass recovery agree closely. At 100 axial cells,
the main peak differs by less than 0.001% in height and the load/wash maximum
differs by 0.4%. Whole-run mass-closure error is 0.000043% of loaded protein.
The 100-cell application peak is 0.7625 mL earlier than the CADET peak on the
reported grid. A fitted uniform 0.7511 mL shift reduces the full-trace error
from 0.6414% to 0.2183% of the reference peak height; it accounts for 88.4%
of the squared discrepancy. This is a diagnostic alignment, not a correction
applied to the model or an explanation of the remaining 0.2183%. The output
sampling interpolation contributes much less than the observed shift.
The comparison
plot is `benchmark_scenarios/cadet_fig2b_comparison.png`. A new regression
test checks the independent CADET outlet values at six elution volumes, main
peak, loading range, mass conservation, and section restarts.

## Confirmed solver issue and correction

Before the correction, both 40-cell/300-output and 40-cell/700-output
benchmark runs failed after prolonged integration. SciPy's sparse finite-
difference Jacobian kept increasing its perturbation scale on nearly
unresponsive states. Eventually it probed an adsorbed state with surface
coverage millions of times above the valid CPA domain, although the accepted
trajectory's maximum coverage on successful runs was about 0.691. Halving the
BDF time step did not reset SciPy's enlarged `jac_factor`, so retries repeated
the invalid probe.

The CPA-specific BDF guard now resets `jac_factor` **only after a rejected
surface-coverage trial**. The same 40-cell cases then completed. It does not
clip accepted coverage or change the adsorption law. CADET also restarts time
integration at discontinuous process sections; the protein solver now restarts
at the same stage boundaries as the existing buffer solver. The 8, 24 and
32-cell predictions changed only at numerical noise level after this restart.

## Remaining differences

- The application uses prescribed pH and an ion-composition-derived ionic
  strength profile. CADET's benchmark sets `CPA_IONIC_VALENCE`, so CADET
  computes ionic strength from transported pore ion concentrations. The
  measured outlet ionic-strength profiles in this benchmark differ by only
  about 0.0003 M near the gradient onset; the two chemistry formulations are
  still not identical internally.
- CADET uses a 0.2 µm/s film coefficient for its ion components. This
  application uses its existing fast bulk-to-pore salt exchange assumption.
  A separate ion-film parameter was not added because the difference in this
  benchmark's outlet salt profile is small and no fitted ionic-transport data
  were supplied.
- CADET uses IDAS with an analytic Jacobian for this test. This application
  uses SciPy BDF with a sparse numerical Jacobian and the coverage-domain
  safeguard. Matching this benchmark does not prove equivalence for pH ramps,
  multiple proteins, or every CPA parameter combination.

The independent CADET trace shows no evidence of a missing CPA coefficient or
unit conversion in this single-protein, fixed-pH benchmark. The remaining
load-peak error falls as the axial grid is refined, consistent with the
different finite-volume reconstruction methods.

## Recheck

From the extracted model folder, run
`python -m unittest tests.test_cadet_fig2b_reference` for the short 24-cell
reference test. The full CPA-focused validation used that test plus
`test_cadet_domain_and_chemistry`, `test_cpa_paper_equations`,
`test_cpa_binding_audit`, `test_cpa_single_protein_fastpath`,
`test_cadet_prescribed_ionic_strength`, `test_cpa_counterion_exchange`,
`test_cpa_poros50hs_paper_benchmark`, `test_figure2a_run2_active`, and
`test_solver_sparse_equivalence`: 48 tests passed. The older
`test_solver_chromatograms` module contains EDM cases and an outdated JMP
handoff expectation; it fails in the untouched uploaded ZIP in the same way.
