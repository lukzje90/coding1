# Xu–Lenhoff colloidal binding with the TDM column

This is a fourth, CEX-only model choice: **TDM – Xu–Lenhoff colloidal**. It
does not replace the existing Briskot TDM–CPA model. The user's `binding.py`
is the CADET-Process parameter wrapper. The rate law follows CADET-Core's
`ColloidalBinding.cpp` (Xu and Lenhoff, 2009) and is implemented locally in
`tdm_xu_lenhoff.py` so the JMP model can run without CADET installed.

For each species CADET's residual is

```
res_i = k_kin,i [q_i exp(S_i S_factor − log K_eq,i) − c_p,i].
```

The local TDM adsorption rate is `dq_i/dt = −res_i`. `log K_eq,i` and the
pair-interaction coefficient `bpp_i` each use CADET's salt power plus salt
exponential terms, optionally multiplied by a pH power. The shared screening
law, coordination number, pair interactions, and linear low-coverage branch
are retained. The species compete through the sum of adsorbed concentrations
and pair interactions. Local **pore salt and pH** from the run program drive
the binding law. The TDM balances bulk protein, pore protein, and adsorbed
protein; it uses the existing axial dispersion, bead radius, porosities and
effective mass-transfer coefficient.

## Input units

- Column and TDM fields retain their existing JMP units.
- Protein molecular weight is kDa and protein radius is nm. Radius is separate
  from the Briskot CPA protein diameter.
- Shared area/volume `φ` is entered as **m²/mL stationary solid** and saved
  internally as m⁻¹ (`JMP value × 10⁶`).
- The **Use local pH** switch matches CADET's `use_ph` option and defaults
  to Off. With Off, the affinity and pair-interaction pH exponents do not
  affect the binding rate or participate in LSQ. With On, both laws use the
  local pore pH. Previously saved local Xu–Lenhoff recipes with nonzero pH
  exponents are migrated to On so their old behavior is preserved.
- Kinetic rate is s⁻¹; linear-branch threshold is mol/m³ bound protein.
- Salt-law coefficients follow CADET's numerical convention: salt is evaluated
  in **mol/m³**, obtained from the process salt molarity by multiplying by
  1000. Exponential multipliers therefore have m³/mol units. `log K_eq` is a
  natural-log equilibrium coefficient, not `log10`.
- Protein concentrations and adsorbed states are mol/m³ in the rate law;
  feed and chromatogram values are converted through each species' kDa.

The starting values are uncalibrated examples. Xu–Lenhoff and Briskot CPA
parameters are not interchangeable. Fit retention at low load across salt
conditions first, then the pair-interaction parameters from high-load runs,
and then kinetic and pH terms if the data contain information about them.
Keep the coordination number and linear threshold fixed during LSQ.

The `tests/test_xu_lenhoff.py` tests the rate against an independent
translation of the CADET-Core residual, the low-coverage branch, salt and pH
response, the `use_ph` switch, the JMP-to-Python area/volume conversion,
LSQ eligibility, CEX-only validation and two-species TDM mass closure.
