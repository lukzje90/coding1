"""Xu–Lenhoff colloidal binding law used by CADET's MULTI_COMPONENT_COLLOIDAL.

The attached CADET-Process binding.py declares parameters only. This module
implements the CADET-Core ColloidalBinding.cpp residual with the sign reversed
to obtain dq/dt. Concentrations are mol/m³, radii are metres, and the phase
ratio is accessible area per stationary-solid volume in m⁻¹. Salt enters the
CADET expression in mol/m³ (1000 times the process salt molarity).
"""

from __future__ import annotations

import math
import numpy as np

R_FACTOR = 2.0 / (6.02214076e23 * math.sqrt(3.0))

SHARED_FIELDS = (
    "phase_ratio_m_inv", "kappa_exponential", "kappa_factor",
    "kappa_constant", "coordination_number", "linear_threshold_mol_m3",
)
SPECIES_FIELDS = (
    "xl_logkeq_ph_exponent", "xl_logkeq_power_exponent",
    "xl_logkeq_power_factor", "xl_logkeq_exponent_factor",
    "xl_logkeq_exponent_multiplier", "xl_bpp_ph_exponent",
    "xl_bpp_power_exponent", "xl_bpp_power_factor",
    "xl_bpp_exponent_factor", "xl_bpp_exponent_multiplier",
    "xl_protein_radius_nm", "xl_kinetic_rate_s",
)


def _salt_law(c_s: float, power: float, factor: float,
              exp_factor: float, exp_multiplier: float) -> float:
    # The positive floor only defines the zero-salt limit of a power law;
    # normal CEX buffers have finite salt and are evaluated without alteration.
    c_s = max(c_s, 1e-12)
    argument = c_s * exp_multiplier
    if argument > 700.0 and exp_factor != 0.0:
        raise FloatingPointError("Xu–Lenhoff salt exponential exceeds floating-point range.")
    exponential = 0.0 if argument < -745.0 or exp_factor == 0.0 else math.exp(argument)
    try:
        return c_s**power * factor + exponential * exp_factor
    except OverflowError as exc:
        raise FloatingPointError("Xu–Lenhoff salt power exceeds floating-point range.") from exc


def rate(cp: np.ndarray, q: np.ndarray, salt_M: float, pH: float,
         shared: dict, species: list[dict]) -> np.ndarray:
    """Adsorbed protein rate in mol/m³ stationary solid/s for one axial cell.

    This is ``-res`` from CADET-Core's ColloidalBinding.cpp. The branch at
    qSum <= linear_threshold follows CADET exactly. States must be finite;
    tiny negative BDF probes are projected to zero for constitutive evaluation.
    """
    cp = np.maximum(np.asarray(cp, dtype=float), 0.0)
    q = np.maximum(np.asarray(q, dtype=float), 0.0)
    if cp.shape != q.shape or cp.shape != (len(species),):
        raise ValueError("Xu–Lenhoff rate requires one pore and solid concentration per species.")
    if not np.all(np.isfinite(cp)) or not np.all(np.isfinite(q)):
        raise ValueError("Xu–Lenhoff rate received non-finite protein concentration.")
    ph_enabled = shared.get("use_ph", False)
    if not isinstance(ph_enabled, bool):
        raise ValueError("Xu–Lenhoff use-pH switch must be Boolean.")
    if not (math.isfinite(salt_M) and salt_M >= 0 and math.isfinite(pH)
            and (not ph_enabled or pH > 0)):
        raise ValueError("Xu–Lenhoff requires nonnegative salt molarity and positive pH when use-pH is On.")
    c_s = max(float(salt_M) * 1000.0, 1e-12)
    q_sum = float(np.sum(q))
    log_k = np.empty(len(species))
    bpp = np.empty(len(species))
    radii = np.empty(len(species))
    for i, row in enumerate(species):
        log_k[i] = _salt_law(c_s, -float(row["xl_logkeq_power_exponent"]),
                             float(row["xl_logkeq_power_factor"]),
                             float(row["xl_logkeq_exponent_factor"]),
                             float(row["xl_logkeq_exponent_multiplier"]))
        bpp[i] = _salt_law(c_s, float(row["xl_bpp_power_exponent"]),
                            float(row["xl_bpp_power_factor"]),
                            float(row["xl_bpp_exponent_factor"]),
                            float(row["xl_bpp_exponent_multiplier"]))
        if ph_enabled:
            log_k[i] *= pH**float(row["xl_logkeq_ph_exponent"])
            bpp[i] *= pH**float(row["xl_bpp_ph_exponent"])
        radii[i] = float(row["xl_protein_radius_nm"]) * 1e-9
    if not np.all(np.isfinite(log_k)) or not np.all(np.isfinite(bpp)) or np.any(bpp < 0):
        raise ValueError("Xu–Lenhoff affinity or pair-interaction law is invalid at this salt/pH.")
    interaction = np.zeros(len(species))
    if q_sum > float(shared["linear_threshold_mol_m3"]):
        denominator = (c_s**float(shared["kappa_exponential"]) *
                       float(shared["kappa_factor"]) + float(shared["kappa_constant"]))
        if denominator <= 0 or not math.isfinite(denominator):
            raise ValueError("Xu–Lenhoff screening denominator must be positive.")
        kappa = 1.0 / denominator
        distance = math.sqrt(R_FACTOR * float(shared["phase_ratio_m_inv"]) / q_sum)
        sfactor = float(shared["coordination_number"]) * 0.125 / q_sum * (3.0 / distance + kappa)
        for i in range(len(species)):
            for j in range(len(species)):
                if bpp[i] * bpp[j] > 1e-16:
                    radius_sum = radii[i] + radii[j]
                    exponent = -kappa * (distance - radius_sum)
                    if exponent > 700.0:
                        raise FloatingPointError("Xu–Lenhoff pair interaction exceeds floating-point range.")
                    interaction[i] += q[j] * math.sqrt(bpp[i] * bpp[j]) * radius_sum * math.exp(max(exponent, -745.0))
        interaction *= sfactor
    exponent = interaction - log_k
    if np.any((q > 0.0) & (exponent > 700.0)):
        raise FloatingPointError("Xu–Lenhoff desorption exceeds floating-point range.")
    desorption = q * np.exp(np.minimum(np.maximum(exponent, -745.0), 700.0))
    kinetics = np.array([float(row["xl_kinetic_rate_s"]) for row in species])
    result = kinetics * (cp - desorption)
    if not np.all(np.isfinite(result)):
        raise FloatingPointError("Xu–Lenhoff adsorption rate is non-finite.")
    return result
