"""Poros 50 HS / mAb1 stress case from Briskot et al., JCA 1654 (2021)."""

import unittest

import numpy as np

from tdm_minimal_io import MODEL_TDM_CPA, validate_config
from tdm_minimal_model import _build_cpa_components, simulate
from verify_model import make_config


def poros_mab1_case():
    config = make_config(MODEL_TDM_CPA, 0, multistep=False)
    config["column"].update(volume_mL=0.981, length_mm=50.0, flow_mL_min=0.239)
    config["feed"].update(total_concentration_mg_mL=12.7,
                          load_density_mg_mL_resin=12.7 * 5.9)
    config["tdm"].update(bead_radius_um=25.0, void_fraction=0.53,
                          particle_porosity=0.54)
    config["cpa"].update(ligand_surface_density_umol_m2=2.89, ligand_pK=2.3)
    config["components"][0].update(
        mass_percent=100.0, D_ax_mm2_s=0.06, k_eff_um_s=1.01,
        diameter_nm=11.0, molecular_weight_kDa=150.0,
        As_m_inv=0.22e9, Z_ref=80.45, Z_lat=19.07,
        delta_ref=10.0 ** -1.90, kkin_star_s=4.61e7,
        pH_ref=5.0, Z1_per_pH=0.0, Z2_per_pH2=0.0,
        Z3_per_pH3=0.0, delta_pH_slope_m2_C=0.0,
    )
    # The article does not supply detector calibration or citrate speciation.
    # The values below are a documented monovalent-NaCl/citrate approximation.
    config["conversion"].update(uv_to_protein_mAU_L_g=200.0,
                                conductivity_to_salt_M_per_mS_cm=0.45 / 37.0)
    config["process"].update(load_CV=5.9, load_amount_basis="LOAD_VOLUME",
                             plw_count=1, elution_count=1,
                             equilibration_source="BUFFER_A")
    config["process"]["plw_steps"][0].update(CV=5.0, flow_mL_min=0.239,
                                               start_percent_B=0.0)
    config["process"]["elution_steps"][0].update(
        mode="LINEAR", CV=31.81, flow_mL_min=0.239,
        start_percent_B=0.0, end_percent_B=100.0,
        chemistry_control="BUFFER_B_PERCENT",
    )
    for key, salt, conductivity in (("buffer_A", 0.0, 3.0),
                                    ("buffer_B", 0.45, 40.0)):
        buffer = config["process"][key]
        buffer.update(pH=5.0, salt_concentration_M=salt,
                      salt_input_mode="SALT_M", conductivity_mS_cm=conductivity,
                      ionic_strength_source="ION_COMPOSITION")
        for ion in buffer["ions"]:
            ion.update(species="", concentration_M=None, valency=None)
        buffer["ions"][0].update(species="Na+", concentration_M=0.02 + salt,
                                  valency=1)
        buffer["ions"][1].update(species="Citrate2-", concentration_M=0.01,
                                  valency=-2)
        if salt:
            buffer["ions"][2].update(species="Cl-", concentration_M=salt,
                                      valency=-1)
    config["numerics"].update(time_steps=700, axial_positions=8)
    return config


class PorosPaperBenchmarkTests(unittest.TestCase):
    def test_published_kinetic_parameter_stays_physical_and_conserves_mass(self):
        config = poros_mab1_case()
        self.assertEqual(validate_config(config, strict=True), [])
        component = _build_cpa_components(config, need_tdm_kinetics=True)[0]
        self.assertAlmostEqual(component.Z(5.0), 80.45)
        self.assertAlmostEqual(component.Z(5.6), 80.45)
        result = simulate(config)
        self.assertAlmostEqual(result["mass_balance"]["Target protein"]["input_g"],
                               0.07350633, places=7)
        self.assertLess(abs(result["mass_balance"]["Target protein"]
                            ["closure_error_percent_of_input"]), 0.01)
        diagnostic = result["simulation"]["diagnostics"]
        self.assertGreater(diagnostic["accepted_step_positivity_projections"]["count"], 0)
        self.assertLess(diagnostic["accepted_step_positivity_projections"]
                        ["maximum_phase_correction_mol_m3"], 1e-6)
        charge = diagnostic["CPA_adsorption_audit"]["species"][0]
        self.assertAlmostEqual(charge["Z_at_load_pH"], 80.45)
        self.assertAlmostEqual(charge["Z_at_elution_end_pH"], 80.45)
        for minimum in diagnostic["minimum_solver_state_by_phase_mol_m3"].values():
            self.assertGreater(minimum, -1e-6)
        trace = result["trace"]
        peak_mL = float(trace["volume_mL"][int(np.argmax(trace["uv_mAU"]))])
        self.assertGreater(peak_mL, 18.0)
        self.assertLess(peak_mL, 27.0)


if __name__ == "__main__":
    unittest.main()
