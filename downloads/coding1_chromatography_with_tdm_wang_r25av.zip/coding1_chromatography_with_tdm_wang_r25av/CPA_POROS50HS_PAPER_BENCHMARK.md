# Poros 50 HS / mAb1 CPA benchmark

The example `cpa_poros50hs_mab1_example.json` follows Table 1 and Fig. 2(a)
of Briskot et al., *J. Chromatogr. A* 1654 (2021) 462439, using the Run 1
conditions supplied by the user from Huuk et al., *Biotechnol. J.* 12 (2017)
1600336. It is a TDM + CPA CEX example, not a calibration for another resin.
The JSON is a complete direct-Python simulation recipe. JMP keeps each run's
process recipe in its run table, so setting up this run in JMP also requires
entering the load, wash, and gradient in Process Setup.

| Paper value | JMP CPA input | Stored solver value |
| --- | --- | --- |
| Particle diameter 50 µm | 50 µm | `bead_radius_um = 25` |
| Protein radius 5.5 nm | 5.5 nm | `diameter_nm = 11` |
| Accessible area 0.22 nm⁻¹ | 0.22 nm⁻¹ | `As_m_inv = 2.2e8` |
| log₁₀ Δ = −1.90 | −1.90 | `delta_ref = 0.012589254...` |
| k*kin = 4.61e7 s⁻¹ | 4.61e7 s⁻¹ | 4.61e7 s⁻¹ |
| Z(pH_ref) = 80.45 | Z_ref = 80.45 | 80.45 |
| No pH charge slopes | Z1 = Z2 = Z3 = 0 | 0, 0, 0 |

The other Table 1 model values are εv = 0.53, εp = 0.54,
ΓL = 2.89 µmol/m², Dax = 0.06 mm²/s, keff = 1.01 µm/s,
Zlat = 19.07, and the assigned antibody mass is 150 kDa. At pH_ref = 5,
the charge polynomial gives Z(5) = 80.45 and Z at every other pH is also
80.45 when the three slopes are zero.

The example uses 0.981 mL, 50 mm, 0.239 mL/min, 12.7 mg/mL,
5.9 CV loading (73.506 mg), 5 CV wash, and a 31.81 CV 0–100% B gradient.
Buffer A is represented as 10 mM citrate, 3 mS/cm; Buffer B adds 0.45 M
NaCl and is 40 mS/cm. The example assumes citrate²⁻ and Na⁺ for its ion
composition. The publication does not establish the exact citrate species,
mixing delay, dead volume, detector calibration, or all original Huuk run
details. The example's UV response factor (58 mAU·L/g) only scales the plotted
absorbance near Fig. 2(a)'s 0.5 AU maximum; it is not a measured detector
parameter.

![Predicted mAb1 UV chromatogram and conductivity](cpa_poros50hs_example_output.png)

With 700 output points and 40 axial cells, the numerical simulation produced
a broad elution peak at about 21.6 mL, with less than 0.001% total protein
mass-balance error and phase minima above −1e−9 mol/m³. The peak is earlier
and its shoulder is weaker than the published Figure 2(a); this is a
qualitative comparison, **not a reproduction of the published chromatogram**.
The model uses finite volumes and SciPy BDF, while the paper uses SUPG and
IDAS. The available inputs cannot establish whether the remaining shape
difference comes from process conditions, chemistry, model equations, or
discretization. The example should not be used to assert predictive accuracy
for the paper or for new systems without measured chromatograms.

The accepted-step BDF safeguard repairs a negative phase overshoot by
redistributing protein among bulk, pore, and adsorbed phases within the same
axial cell. It preserves total protein inventory and rebuilds the BDF
history. A materially negative *total cell inventory* still raises an error.
The safeguard also rejects a correction larger than 1e−5 times the larger
of 1 mol/m³ and the current maximum phase magnitude, so it cannot silently
repair a large solver failure. In the eight-cell test its largest correction
was below 5e−9 mol/m³.
The published high kinetic value previously generated a negative pore state;
the benchmark now integrates it without replacing it by a smaller value.

The mAb2/Fractogel EMD SO₃ and mAb5/Poros 50 HS Table 1 parameter sets were
also run as solver stress checks. Both completed without material negative
phase concentrations. Those checks used the example gradient and an assumed
residence time, because their individual experimental run recipes were not
fully specified here; they do not compare predicted peaks with the paper.
