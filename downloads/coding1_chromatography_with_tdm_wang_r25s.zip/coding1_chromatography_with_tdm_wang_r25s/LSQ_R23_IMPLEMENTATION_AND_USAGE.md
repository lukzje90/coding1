# R23 — Independent least-squares process setup and weighted RMSE

R24k supports 1–10 selected LSQ profiles. Each attached UV profile chooses its
independent LSQ recipe or any
saved normal batch run (1–30) as its model run. **Preview UV and fraction mass%**
and refinement both read the chosen run's latest saved recipe and the attached
UV file when started. The preview simulates the current model once and opens a separate
overlay of measured and predicted UV over the complete programmed recipe.
The preview reports the measured and programmed CV spans and pre-fit UV RMSE.
It does not run the optimizer or apply fitted parameters; **Open alignment
preview** reopens the last report.
Dense reference UV samples are displayed at one median value per chart pixel
column to avoid a dark overdraw region. The solver and fit trace CSV retain
every raw sample.

For mass% fitting, select **Least-squares: chromatogram + species mass% by
fraction**. Set **Use this run's fraction mass%** to On in each selected run
that has mass data, then choose **Edit mass% for LSQ run** to enter that run's
up to 30 fraction start/end ranges in CV or mL. Each LSQ run has its own
saved row count, units and species values in `tdm_lsq_fraction_mass.csv`.
Only enabled selected runs contribute mass%; the others contribute UV alone. The
midpoint is the plot position. A blank target/impurity cell leaves that
species out of the objective at that fraction and breaks its line in the plot;
zero is a measured value. The graph uses shape-preserving interpolation only
to display adjacent observations. The optimizer compares the entered mass%
with `100 × integrated species concentration / integrated sum of modeled
species concentrations` over the full collected fraction. CV is cumulative
volume, so this integration includes changes in flow. mL coordinates use the selected
model's column volume. The alignment preview shows a solid measured target
line, dotted measured impurity lines, a dashed model target and lighter dotted
model impurities, with gaps where that species has no input. UV remains a
required observation, and this optional
mass% mode uses RAW_SSE or NORMALIZED_MSE rather than WEIGHTED_RMSE.
RAW_SSE retains the literal UV sum of squares while scaling the mass% group
to comparable UV units from the measured UV range (at least 1 mAU) and sample
count; NORMALIZED_MSE uses dimensionless groups for both, also flooring the
UV normalization at 1 mAU when the trace is nearly flat.

## Model basis

Hahn et al., *Calibration-free inverse modeling of ion-exchange chromatography in industrial antibody purification*, **Engineering in Life Sciences** 16 (2016), pp. 107–113, equation (9), defines the nonlinear sum-of-squared chromatogram residuals:

\[\min_{\theta}\sum_j (y_{\mathrm{measured},j} - y_{\mathrm{model},j}(\theta))^2.\]

The existing GRM/EDM or TDM mechanistic HIC model is **not replaced** by a peak-fitting proxy. For each candidate parameter vector, the existing mechanistic `simulate` function runs every selected fixed process recipe. The predicted detector signal is the sum of simulated species UV signals using species response factors. The measured reference must be UV; AU-labelled values are converted to mAU. Linear interpolation evaluates the simulated signal at every experimental CV. Measurements outside the simulated CV window **cause an explicit error**; they are never silently dropped.

The `WEIGHTED_RMSE` option implements:

\[\mathrm{WRMSE}= \sqrt{ \frac{\sum_{r=1}^R W_r\left(\frac{\sum_j w_{rj}(\widehat y_{rj}-y_{rj})^2}{\sum_j w_{rj}}\right)}{\sum_{r=1}^R W_r} }.\]

- `W_r` is **each LSQ run's positive weight**, default `1.0`.
- `w_rj` is **the measurement's optional nonnegative `Weight` column**, default `1.0` for all samples. Every run must have at least one positive point weight.
- Every run contributes a weighted **mean** squared error, so a denser sampled chromatogram does not automatically overwhelm a less densely sampled run. This is deliberate and differs from the raw SSE option.
- The optimizer receives residuals `sqrt(W_r / sum W) * sqrt(w_rj / sum_j w_rj) * (prediction - measurement)`; therefore its least-squares objective is exactly WRMSE squared. Minimizing WRMSE or WRMSE squared produces the same minimizer.
- All profiles in one WRMSE fit must use comparable signal units. Mixing UV and concentration profiles is rejected.
- `RAW_SSE` reproduces equation (9) without weighting or baseline inference. `NORMALIZED_MSE` retains the original equal-run normalized objective.

A bounded nonlinear SciPy least-squares solver fits **only the individually unlocked** mechanistic parameters (Model Parameters tab). It uses trust-region reflective steps for interior starting values and dogbox steps when an entered parameter starts at a bound (for example, zero axial dispersion). All per-run feed, flow, stage lengths, buffers, gradients, and time/space mesh settings remain fixed. Initial and final candidate objectives are re-evaluated. The best verified result is only applied when it is not worse than the starting parameter set. An optimizer stopping at the user-selected evaluation cap is reported distinctly from successful convergence.

During a fit, `least_squares_objective_history.csv` gains one row for each actual residual evaluation. Its `best_objective` column should decrease when the fit finds a better parameter set; `elapsed_seconds` shows actual wall time. JMP waits synchronously for Python and may appear busy until the fit completes. The optional safety cap counts optimizer function evaluations, **not** column solves: with *P* unlocked parameters and *R* chromatograms, each numerical Jacobian typically needs about *R × (P + 1)* column solves. The supplied LSQ process recipe uses 1,400 time steps and 100 column cells. On the cloud test machine, one saved EDM column solve took about 8.6 seconds. Its 10 eligible unlocked parameters therefore imply roughly 95 seconds per numerical Jacobian for one run, or roughly 6 minutes for four such calculations; local Windows/JMP timing will differ. For a first diagnostic pass, reduce the numerical resolution in the **chosen model run setup**, lock parameters you do not need, and then check the final candidate again at production resolution. The conductivity-detector dead volume is editable for forward simulation but is excluded from UV-only refinement because it does not change the UV trace.

## JMP workflow

1. Unzip the whole project and start it using `00_RUN_CHROMATOGRAPHY_MODEL_IN_JMP.jsl` as before. Python dependencies: `pip install -r requirements.txt`.
2. Click **Edit LSQ process setup** at the top of the window or **Edit process recipe** in a run section. The existing **Process Setup** editor now edits a **separate LSQ process table** (`tdm_lsq_process_runs.csv`). The screen identifies which scope is active. Edit LSQ runs 1–10 separately: buffer chemistry, load flow and amount, load feed chemistry, post-load washes, elution gradient/steps and numerical resolution. Click **Save current process recipe**. **Edit normal batch setup** returns to the original independent batch table (`tdm_batch_runs.csv`). Changes to either process table never rewrite the other table.
3. Under **Least-Squares Refinement**, first choose **Number of runs to fit**. The tab immediately shows that many run sections. In each section, select the LSQ profile that owns the measured file, then set **Model run for UV comparison** to its independent LSQ recipe or the saved normal batch Run 1–30 you want to compare. Attach an **Excel `.xlsx`/`.xlsm` or `.csv`** file with measured **CV or mL versus UV absorbance in mAU**. The file path, model-run choice and axis choices are stored with that LSQ profile. Choose **X units = CV** for column volumes or **ML** for collected millilitres; `AUTO` recognizes common headings such as `CV`, `Volume (mL)`, and `UV 280 [mAU]`. The mL axis is divided by the shared column volume; mAU values are compared directly with the predicted detector mAU. The selected normal run's saved recipe is re-simulated, so edits are reflected after you save that normal run. The actual measured file is reread at every preview and refinement. Existing LSQ tables retain their independent recipe selection when upgraded.
   Choose **X = 0 at RUN_START** if the data include loading and washes. For a conference chromatogram whose x-axis restarts at the beginning of elution, choose **ELUTION_START**; the saved load and wash CV are then added to the measured CV. This origin option applies to CV/mL axes. An incorrect origin can make peaks appear early even when the solver and detector values are otherwise correct. Click **Attach / validate** and read the axis receipt before fitting.
   **Optional columns and weight** lets you name an Excel worksheet and exact X and UV headings when auto-detection is ambiguous, or assign a run weight. If the UV heading is generic (such as `Signal`), select that column explicitly; known non-UV channels and unselected ambiguous channels are rejected. Leave weight at 1 for ordinary fitting. Set X units explicitly when overriding the X column. A `Weight` column supplies optional per-point weights.
   Weighted RMSE is a chromatogram-only objective; when fitting extra species composition constraints choose RAW_SSE or NORMALIZED_MSE to avoid mixing units.
4. After the run sections, **Fit settings** contains the refinement mode, parameter-lock shortcuts, and safety evaluation cap. For ordinary CV/mL-versus-mAU fitting, leave objective and weights unchanged: `RAW_SSE` is the default pointwise objective and each run has weight 1. The optimizer retains its best verified parameter set and stops when the objective, gradient, or parameter step converges, subject to the cap. **Optional objective and stopping settings** lets you choose `WEIGHTED_RMSE` or `NORMALIZED_MSE` and baseline policy.
5. In **Model Parameters**, set each candidate's **Locked / Unlocked** selector next to its value. Only **Unlocked** eligible parameters change; column geometry, each LSQ recipe and feed species composition stay fixed. Click **Run least-squares refinement**.
6. Check the success/accepted flags and the per-run measured-vs-predicted overlays. A smaller objective is not necessarily proof of a unique physical parameter vector, so use additional runs/validation and inspect bounds and residual shape.

## Accepted Excel/CSV chromatogram layout

A numeric **CV**, **Volume (mL)**, **Time (min/s/hour)** or sample index column and a numeric **UV/mAU/Signal/Concentration** column are supported. The program scans workbook sheets for a usable table; extra metadata sheets can be ignored. The optional `Weight` column must contain a finite number >= 0 at every signal sample. Example:

| CV | UV 280 [mAU] | Weight |
|---:|---:|---:|
| 0.00 | 0.1 | 0.5 |
| 0.25 | 2.5 | 1.0 |
| 0.50 | 8.1 | 2.0 |

For time axes, the profile's *own varying stage flows* are used to convert time to CV. An unlabeled, single-signal column is treated as uniformly spaced over the full process duration, and the output records this assumption. Rows with blank/missing signal are ignored; measured points beyond the simulated recipe are rejected. `.xls` files should be saved as `.xlsx` first. Formula cells in `.xlsx` need cached calculated values; open/recalculate/save in Excel if blank in Python.

## Output files (after an actual fit)

- `least_squares_improved_parameters.csv` and `.txt`: **all unlocked/optimized mechanistic parameters**, initial values, best improved values, percent changes, and fitted bound flags. With no unlocked parameters the list explicitly says so. These are the primary requested **list of improved parameters**.
- `least_squares_fit_results.csv`: full locked/unlocked candidate parameter audit.
- `least_squares_fit_trace.csv`: individual reference points, predicted values, errors, optional sample/run weights and exact contribution to the objective.
- `least_squares_fit_report.html`: measured-vs-simulated chromatograms, per-run RMSE and weighted RMSE, full selected recipes, improved parameters, optimization progress and convergence/acceptance results.
- `least_squares_objective_history.csv`: logged loss progress for every objective call.
- `least_squares_settings.json`: individual profile locations/weights/recipes, parameter lock list, baseline policy and exact weighting expression.
- `least_squares_fitted_inputs.json`: fitted mechanistic input values.

## Verification and limits

Run `python -m unittest discover -s tests -v` for model-backed synthetic chromatogram fitting, two-profile Excel+CSV ingestion and weight mathematics, separate process-table checks, invalid-weight rejection, and generated-JSL static checks. These tests use synthetic data with a known physical model and recover a perturbed UV parameter; they **do not constitute a fit to real laboratory chromatograms**.

This environment cannot launch the JMP desktop application, so UI interactions are statically generated and audited but should be checked in a local JMP installation. The actual optimum for a given protein/resin **cannot be produced until real chromatogram files and process recipes are supplied**. Large mechanistic multi-run fits may take substantial time; increasing the optimizer evaluation cap improves opportunity to converge but does not ensure global identifiability.
