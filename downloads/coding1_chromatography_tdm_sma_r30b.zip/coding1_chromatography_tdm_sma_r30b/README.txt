TDM CHROMATOGRAPHY MODEL — R30b (26 November 2026)

SUPPORTED MODELS
• TDM – Competitive Langmuir (HIC)
• TDM – Modified Wang (HIC)
• TDM – Steric Mass Action (ion exchange, CEX setup)

The new SMA option follows CADET-Core's steric mass action binding equation,
coupled to the existing transport dispersive column with interstitial and pore
liquid balances. It supports kinetic and quasi-stationary binding, protein
competition, monovalent salt displacement and steric shielding. It does not
reuse the retired CPA binding equation or its fitted parameters.

START
1. Extract the complete ZIP into one folder.
2. Open 00_RUN_CHROMATOGRAPHY_MODEL_IN_JMP.jsl in JMP and press Ctrl+R.
3. Choose TDM – Steric Mass Action under Model Parameters for CEX. Enter
   measured molecular weights, the SMA and transport parameters, buffers and
   stages; then review the selected run before simulating.

The active tdm_inputs.json and Run 1 in tdm_batch_runs.csv are a Poros XS
SMA benchmark at pH 6.0, using the system and binding parameters published
by Briskot et al. (2021). Run 1 in tdm_lsq_process_runs.csv points to this
same normal-batch method; its experimental chromatogram field is intentionally
empty. Select Run 1 and simulate to see the predicted chromatogram. The
benchmark_scenarios/ folder also contains a CADET-Core four-component
numerical reference. These are examples, not calibrated values for your resin
or protein.

The previous CPA/CEX setup and run tables remain in archived_inputs/ for
reference. They do not automatically become SMA inputs: CPA and SMA have
different parameter meanings. Opening a saved CPA project shows the SMA
interface and requires explicit review and new SMA parameterisation.

To transfer an existing HIC project, copy tdm_inputs.json,
tdm_batch_runs.csv, tdm_lsq_process_runs.csv and tdm_lsq_fraction_mass.csv
into this extracted folder. For an existing CEX/CPA project, use its column,
buffer and run setup as a reference, then enter and fit SMA parameters.

The model writes simulation, least-squares and method-optimisation results
beside these files. Previous results are marked stale by the R30b build ID.
See SMA_IMPLEMENTATION_AND_BENCHMARK.md for the benchmark result, source,
and which transport and run settings had to be assumed.
