"""TDM+SMA physics, interface and CADET benchmark regression checks."""
import copy
import json
import math
from pathlib import Path
import unittest
from unittest.mock import patch

import numpy as np

import tdm_bridge
from tdm_jmp import _validate_jsl, build_jsl
from tdm_least_squares import (_acceptance_policy_description,
                               fit_parameter_lock_catalog, fit_parameter_specs)
from tdm_method_optimisation_extended import _recipe
from tdm_minimal_io import (MODEL_LABELS, MODEL_TDM_SMA, SELECTABLE_MODELS,
                            batch_row_to_run_config, apply_batch_shared_parameters,
                            load_batch_rows, load_config, validate_config)
from tdm_minimal_model import simulate
from tdm_sma import sma_rate, sma_equilibrium_from_totals

ROOT=Path(__file__).resolve().parents[1]
EXAMPLE=ROOT/'benchmark_scenarios'/'tdm_sma_illustrative.json'


def example():
    return json.loads(EXAMPLE.read_text())


class SMAReleaseTests(unittest.TestCase):
    def test_cadet_binding_rate_and_site_balance(self):
        cp=np.array([[0.012,0.008]])
        q=np.array([[1.4,0.5]])
        salt=np.array([80.0])
        ka=np.array([0.2,0.15]);kd=np.array([0.05,0.02])
        nu=np.array([2.0,3.0]);sigma=np.array([3.0,2.0])
        rate,q0,free=sma_rate(cp,q,salt,ka=ka,kd=kd,nu=nu,sigma=sigma,
                              capacity=100.0,c_ref=100.0,q_ref=100.0)
        self.assertAlmostEqual(q0[0],100.0-2*1.4-3*0.5)
        self.assertAlmostEqual(free[0],100.0-5*1.4-5*0.5)
        for i in range(2):
            expected=ka[i]*cp[0,i]*(free[0]/100)**nu[i]-kd[i]*q[0,i]*(salt[0]/100)**nu[i]
            self.assertAlmostEqual(rate[0,i],expected,places=13)

    def test_quasi_stationary_equilibrium_and_salt_release(self):
        ka=np.array([0.2,0.15]);kd=np.array([0.05,0.02])
        nu=np.array([2.0,3.0]);sigma=np.array([3.0,2.0])
        epsp=0.6;epspi=np.array([0.5,0.45]);beta=(1-epsp)/epspi
        beta_salt=(1-epsp)/epsp
        total=np.array([[0.02,0.03],[0.01,0.04]])
        salt_total=np.array([80+beta_salt*100,120+beta_salt*100])
        cp,q,cp_salt,q0,free=sma_equilibrium_from_totals(
            total,salt_total,ka=ka,kd=kd,nu=nu,sigma=sigma,beta=beta,
            beta_salt=beta_salt,capacity=100,c_ref=100,q_ref=100)
        np.testing.assert_allclose(cp+beta*q,total,rtol=1e-9,atol=1e-11)
        np.testing.assert_allclose(cp_salt+beta_salt*q0,salt_total,rtol=1e-9)
        np.testing.assert_allclose(q0+np.sum(nu*q,axis=1),100,rtol=1e-12)
        np.testing.assert_allclose(free+np.sum((nu+sigma)*q,axis=1),100,rtol=1e-12)
        lhs=ka*cp*(free[:,None]/100)**nu
        rhs=kd*q*(cp_salt[:,None]/100)**nu
        np.testing.assert_allclose(lhs,rhs,rtol=1e-8,atol=1e-10)

    def test_strong_binding_keeps_small_positive_pore_concentration(self):
        # With almost all protein bound, total - beta*q rounds to zero. The
        # equivalent positive-fraction formula must still satisfy CADET SMA.
        ka=np.array([4.0]);kd=np.array([0.01]);nu=np.array([10.0]);sigma=np.array([16.0])
        beta=np.array([2.0]);beta_salt=0.5;capacity=2.5
        total=np.array([[1e-6]])
        salt_total=np.array([0.1+beta_salt*capacity])
        cp,q,cp_salt,q0,free=sma_equilibrium_from_totals(
            total,salt_total,ka=ka,kd=kd,nu=nu,sigma=sigma,beta=beta,
            beta_salt=beta_salt,capacity=capacity,c_ref=1.0,q_ref=1.0)
        self.assertGreater(cp[0,0],0.0)
        self.assertAlmostEqual(float(cp[0,0]+beta[0]*q[0,0]),1e-6,places=14)
        lhs=ka[0]*cp[0,0]*free[0]**nu[0]
        rhs=kd[0]*q[0,0]*cp_salt[0]**nu[0]
        self.assertLess(abs(lhs-rhs)/max(lhs,rhs),1e-8)

    def test_equilibrium_reference_concentration_ratio(self):
        args=dict(total_protein=np.array([[0.2]]),total_salt=np.array([55.0]),
                  kd=np.array([0.1]),nu=np.array([2.5]),sigma=np.array([3.0]),
                  beta=np.array([0.6]),beta_salt=0.5,capacity=100.0)
        selected=sma_equilibrium_from_totals(**args,ka=np.array([0.3]),
                                             c_ref=10.0,q_ref=2.0)
        equivalent=sma_equilibrium_from_totals(**args,ka=np.array([0.3*5.0**2.5]),
                                               c_ref=1.0,q_ref=1.0)
        for x,y in zip(selected,equivalent):
            np.testing.assert_allclose(x,y,rtol=1e-10,atol=1e-12)

    def test_jmp_handoff_fit_catalog_and_method_recipe(self):
        x=example()
        jsl=build_jsl(x);_validate_jsl(jsl)
        selector=jsl.split('modelBox = Combo Box(',1)[1].split('}',1)[0]
        self.assertIn(MODEL_LABELS[MODEL_TDM_SMA],selector)
        self.assertIn('smaSystemPanel = Outline Box',jsl)
        self.assertIn('c1SMA = V List Box',jsl)
        payload={'tdm_ui_model':MODEL_LABELS[MODEL_TDM_SMA],
                 'tdm_ui_sma_lambda_mol_m3':100,
                 'tdm_ui_sma_salt_k_eff_um_s':10,
                 'tdm_ui_sma_c_ref_mol_m3':100,
                 'tdm_ui_sma_q_ref_mol_m3':100,
                 'tdm_ui_sma_kinetic_mode':'Quasi-stationary',
                 'tdm_ui_c1_sma_ka_s':0.2,'tdm_ui_c1_sma_kd_s':0.05,
                 'tdm_ui_c1_sma_nu':2,'tdm_ui_c1_sma_sigma':3,
                 'tdm_ui_c1_molecular_weight_kDa':150}
        with patch.dict(tdm_bridge.__dict__,payload,clear=False):
            handoff=tdm_bridge.build_shared_config_from_jmp()
        self.assertEqual(handoff['model'],MODEL_TDM_SMA)
        self.assertEqual(handoff['chromatography_mode'],'ION_EXCHANGE')
        self.assertEqual(handoff['sma']['lambda_mol_m3'],100)
        self.assertEqual(handoff['components'][0]['sma_sigma'],3)
        paths={p.path for p in fit_parameter_lock_catalog(x)}
        self.assertIn('sma.lambda_mol_m3',paths)
        self.assertIn('components[0].sma_ka_s',paths)
        self.assertNotIn('components[0].sma_kd_s',paths)
        self.assertNotIn('sma.c_ref_mol_m3',paths)
        self.assertNotIn('sma.q_ref_mol_m3',paths)
        self.assertNotIn('components[0].molecular_weight_kDa',paths)
        self.assertIn('inactive for this model',_acceptance_policy_description(x))
        x['sma']['is_kinetic']=True
        self.assertIn('components[0].sma_kd_s',{p.path for p in fit_parameter_lock_catalog(x)})
        x['sma']['is_kinetic']=False
        values={'loading_g_L':6.0,'flow_mL_min':1.0,'plw1_CV':4.0,'plw1_B':0.0,
                'el1_CV':10.0,'el1_start_B':0.0,'el1_end_B':100.0}
        candidate=_recipe(x,values,1,1,'GRADIENT')
        self.assertEqual(candidate['sma'],x['sma'])
        self.assertEqual(validate_config(candidate,strict=True),[])

    def test_kinetic_sma_and_existing_hic_models(self):
        x=example();x['sma']['is_kinetic']=True
        result=simulate(x)
        self.assertLess(abs(result['mass_balance']['Target protein']['closure_error_percent_of_input']),0.1)
        self.assertLess(abs(result['simulation']['diagnostics']['sma_salt_balance']['closure_error_percent_of_input']),0.1)
        self.assertGreaterEqual(min(result['trace']['sma_free_sites_mol_m3']),-1e-6)
        # The active default is now the literature SMA preset; exercise HIC
        # with its own saved example instead of depending on the active model.
        current=json.loads((ROOT/'benchmark_scenarios'/'tdm_wang_hic_example.json').read_text())
        for model in ('TDM_WANG','TDM_LANGMUIR'):
            c=copy.deepcopy(current);c['model']=model
            self.assertEqual(validate_config(c,strict=True),[])
            self.assertGreater(max(simulate(c)['trace']['uv_mAU']),0)

    def test_cadet_lrmp_four_component_reference(self):
        from benchmark_scenarios.run_cadet_sma_benchmark import run
        m=run()
        self.assertEqual(m['axial_cells'],32)
        self.assertLess(max(m['normalized_rmse_percent'].values()),0.5)
        self.assertLess(m['maximum_protein_mass_closure_percent'],0.1)


if __name__=='__main__':
    unittest.main()
