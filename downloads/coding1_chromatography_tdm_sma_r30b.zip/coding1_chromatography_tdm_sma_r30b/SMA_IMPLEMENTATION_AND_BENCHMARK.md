# TDM + Steric Mass Action (R30b)

## Sources and model choice

The binding law follows the [CADET-Core SMA modelling guide](https://cadet.github.io/v5.1.X/modelling/binding/steric_mass_action.html) and [parameter interface](https://cadet.github.io/v5.1.X/interface/binding/steric_mass_action.html). The transport balances follow CADET-Core's [lumped-rate model with pores](https://cadet.github.io/master/modelling/unit_operations/lumped_rate_model_with_pores.html) (LRMP): axial convection and dispersion in the column liquid, film transfer, a mixed pore liquid, and a solid adsorbed phase. This is the transport dispersive structure of this software. Radial pore diffusion is not included.

The literature cross-checks were Brooks and Cramer, *AIChE Journal* **38** (1992), 1969–1978, DOI 10.1002/aic.690381212 (original SMA displacement model); Briskot et al., *Journal of Chromatography A* **1653** (2021), 462397, DOI 10.1016/j.chroma.2021.462397 (SMA versus CPA in IEX, including its equilibrium SMA equation); and Kumar et al., *Journal of Chromatography A* **1426** (2015), 140–153, DOI 10.1016/j.chroma.2015.11.062 (mechanistic IEX modelling of mAb charge variants). CADET's equations and units govern this implementation where conventions differ.

The supplied Shekhawat et al., *Journal of Chromatography A* **1680** (2022), 463423, DOI 10.1016/j.chroma.2022.463423, uses a **general rate model plus extended Langmuir binding**, although it discusses SMA in the introduction. Its results therefore are not an SMA numerical benchmark and its binding parameters were not substituted for SMA parameters.

## Equations and units

Salt is component 0 and is treated as a monovalent counterion. For protein species `i`, with pore concentration `c_p,i` in mol/m³ liquid and stationary concentration `q_i` in mol/m³ solid:

```text
q_0    = Λ − Σ_i ν_i q_i
q_free = Λ − Σ_i (ν_i + σ_i) q_i
dq_i/dt = k_a,i c_p,i (q_free/q_ref)^ν_i
          − k_d,i q_i (c_p,0/c_ref)^ν_i
```

`Λ` is mol/m³ stationary phase, `ν_i` is characteristic charge, and `σ_i` is steric shielding. `k_a,i` is m³ liquid/(m³ solid·s), `k_d,i` is s⁻¹, and the reference concentrations `c_ref` and `q_ref` are mol/m³ in their respective phases. They default to 1 mol/m³, as in CADET. They define a parameter convention, so changing them without refitting the rate constants changes the predictions. The salt site balance is algebraic and coupled to the pore and interstitial salt transport; the program does not impose the gradient at the column outlet.

At quasi-stationary equilibrium, the effective ratio `q_i/c_p,i` is `(k_a,i/k_d,i) × [(q_free/c_p,0) × (c_ref/q_ref)]^ν_i`. Thus the ratio `c_ref/q_ref` affects equilibrium as its `ν_i` power. It is a parameter convention, not the column's buffer salt concentration or a measured protein capacity. A 1000-fold unit mistake in one reference value can make an otherwise reasonable `k_a/k_d` retain all protein. R30a evaluates the small positive pore concentration through an algebraically equivalent ratio to avoid subtraction cancellation at very strong binding.

The kinetic option integrates the rate equation. The quasi-stationary option solves its zero-rate equilibrium at each axial cell while conserving pore protein and salt totals. In quasi-stationary mode, only `k_a/k_d` is identifiable; fitting holds `k_d` fixed. Molecular weight is required to convert feed mg/mL and UV mass responses to the molar binding basis; it is not an SMA binding parameter. The values of `ν`, `σ`, `k_a/k_d`, and `Λ` must be fitted or measured for the selected resin, protein, salt and pH.

## Numerical benchmark

The independent reference is CADET-Core's four-component `ref_LRMP_reqSMA_4comp_sensbenchmark1_DG_P3Z8.h5` (CADET 4.4.0, source commit `33d8e85f44e66310e994b97110169e9c47c6d358`). Its salt plus three protein outlet curves were mapped into this TDM setup. The reference is a quasi-stationary LRMP + SMA simulation with a 14 mm bed, 45 µm bead radius, `Λ=1200 mol/m³`, charges `[4.7, 5.29, 3.7]`, shielding `[11.83, 10.6, 10.0]`, and a salt gradient. The mapped configuration and 68 sampled reference points are packaged under `benchmark_scenarios/`. The artificial protein mass of **1 kDa** is only a unit-conversion device: 1 mol/m³ equals 1 g/L numerically. It is not a physical claim about those proteins.

At 32 axial cells, `python benchmark_scenarios/run_cadet_sma_benchmark.py` gives peak-normalized outlet RMSE of **0.00346% for salt** and **0.236%, 0.164%, 0.130%** for the three proteins against the 68 CADET reference points. Maximum protein mass closure error is **0.000129%**, salt closure error **0.00726%**, and the free-site and bound-counterion concentrations remain nonnegative. A separate full 1501-point reference comparison at 64 cells gave peak-normalized RMSE of **0.00195% salt** and **0.04718%, 0.03141%, 0.02215%** for proteins 1–3. These are numerical cross-checks, not experimental validation or a claim of exact identity to CADET's discretization.

The packaged tests also check the CADET rate formula and balances, kinetic and quasi-stationary solutions, JMP-to-Python handoff, SMA fitting parameter selection, method recipe retention, and existing Wang/Langmuir simulations. Run `python -m unittest tests.test_sma_r30` in the extracted folder.

The 68 CADET reference points are stored in `cadet_lrmp_sma_reference_anchors.json`; no external CADET installation is required to rerun this check.

## Active Poros XS literature benchmark and starting parameters

The active `tdm_inputs.json` and Run 1 in `tdm_batch_runs.csv` now use the pH 6.0 Poros XS example. Briskot et al. (2021), Tables 1 and 3, provide an experimental retention check for an approximately 150 kDa mAb on this resin. Table 1 gives a 1.96 mL, 100 mm column, interstitial void fraction 0.35, total porosity 0.76, superficial velocity 150 cm/h, and ionic capacity 0.86 M. The model maps these to a 0.49 mL/min flow, pore porosity `(0.76−0.35)/(1−0.35) = 0.63077`, and `Λ = 860 mol/m³ stationary phase`. Table 3 supplies the four independently fitted SMA parameter sets below. Its `log(k_eq)` is interpreted as base 10; this convention is checked against the paper's Figure 3(b) retention range.

| pH | Published ν | Published log₁₀(k_eq) | Published σ | Predicted salt at peak, mM | Fig. 3(b) visual range at Gₕ≈10 mM, mM |
|---:|---:|---:|---:|---:|---:|
| 5.5 | 11.35 | −7.52 | 183.14 | 175.0 | 165–182 |
| 6.0 | 9.89 | −7.64 | 142.07 | 136.7 | 128–147 |
| 6.5 | 9.34 | −8.26 | 163.38 | 107.0 | 99–116 |
| 7.0 | 7.90 | −8.01 | 148.08 | 78.8 | 69–87 |

The active pH 6.0 run gives a predicted UV maximum of approximately **342.5 mAU at 6.00 CV**, with **136.7 mM salt** at that peak. Its protein mass closure is within **0.01%**. At pH 6.0 the model also predicts **128.2 and 146.1 mM** at normalized gradient slopes **5 and 20 mM**, respectively, consistent with the direction and approximate range in Figure 3(b). These paper ranges were read visually from the published graph; they are not raw experimental data or an exact digitization. The peak-salt result is the relevant literature comparison. The paper does **not** publish a full UV trace for these runs and uses an ideal mass-balance column model, so the active full UV chromatogram is a **TDM prediction**, not a reproduction of an experimental chromatogram.

For the active low-load demonstration, the pH 6.0 Table 3 values are `ν=9.89`, `σ=142.07` and `log₁₀(k_eq)=−7.64`, giving `k_a=2.29087×10⁻⁸` with quasi-stationary binding, `k_d=1 s⁻¹`, and CADET's 1 mol/m³ salt/site reference concentrations. This fixes only the equilibrium ratio; `k_d` is an arbitrary normalisation, not a measured kinetic rate. The paper does not give all full TDM inputs, so the following are **illustrative assumptions**: 25 µm bead radius; 0.0575 mm²/s axial dispersion and 6.9 µm/s protein/salt film transfer borrowed from the separate CADET LRMP/SMA numerical reference; full protein access to the derived pore volume; 0.5 mg/mL feed; 0.1 g/L column load; 50→300 mM salt over 8.75 CV after a 2 CV wash; and an arbitrary 1000 mAU·L/g UV factor. The gradient has `Gₕ = 0.35 × (300−50)/8.75 = 10 mM`.

Open the launcher and simulate normal-batch Run 1 to see this benchmark in the model. The LSQ Run 1 row refers to the same normal-batch method; enter experimental chromatogram data only when fitting actual data. Do not transfer these binding parameters unchanged to another resin, protein or pH.

## Limits

This SMA implementation uses one effective monovalent salt species. Buffer pH is retained in the process setup, but SMA charge and rate constants do **not** change with pH in this plain CADET SMA formulation. Use a fitted parameter set for the applicable pH range. Conductivity is converted to salt using the specified calibration when salt molarity is not entered. The illustrative SMA example and CADET mathematical benchmark are not calibrated predictions for a particular experimental CEX run.
