"""Compare TDM+SMA with published CADET-Core LRMP/SMA reference anchors.

The source HDF5 is CADET-Core test/data/
ref_LRMP_reqSMA_4comp_sensbenchmark1_DG_P3Z8.h5, version 4.4.0,
commit 33d8e85f44e66310e994b97110169e9c47c6d358.
The 1 kDa species masses in the mapped config are a unit-conversion device,
not physical protein masses. 1 mol/m3 then equals 1 g/L numerically.
"""
from pathlib import Path
import csv
import json
import os
import sys
import tempfile
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from tdm_minimal_io import validate_config
from tdm_minimal_model import simulate


def run() -> dict:
    folder=Path(__file__).resolve().parent
    config=json.loads((folder/'cadet_lrmp_sma_mapped.json').read_text())
    reference=json.loads((folder/'cadet_lrmp_sma_reference_anchors.json').read_text())
    errors=validate_config(config,strict=True)
    if errors:
        raise ValueError('Mapped CADET benchmark is invalid: '+str(errors))
    started=time.perf_counter()
    result=simulate(config)
    elapsed=time.perf_counter()-started
    trace=result['trace']
    rows=reference['time_points']
    times=np.array([row['time_s'] for row in rows])
    observed=np.array([[row['salt_mol_m3']]+row['protein_mol_m3'] for row in rows])
    predicted=np.column_stack([
        np.interp(times,trace['t_s'],trace['salt_concentration_M']*1000),
        *[np.interp(times,trace['t_s'],trace['component_g_L'][:,i]) for i in range(3)],
    ])
    comparison_path=folder/'cadet_sma_outlet_comparison.csv'
    with comparison_path.open('w',newline='',encoding='utf-8') as fh:
        fields=['time_s','salt_reference_mol_m3','salt_predicted_mol_m3']
        for i in range(1,4):
            fields += [f'protein_{i}_reference_mol_m3',f'protein_{i}_predicted_mol_m3']
        writer=csv.writer(fh);writer.writerow(fields)
        for t,ref,fit in zip(times,observed,predicted):
            writer.writerow([float(t),float(ref[0]),float(fit[0]),
                             *[v for i in range(1,4) for v in (float(ref[i]),float(fit[i]))]])
    try:
        os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'sma-cadet-matplotlib'))
        os.environ.setdefault('XDG_CACHE_HOME',str(Path(tempfile.gettempdir())/'sma-cadet-cache'))
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        pass
    else:
        fig,axes=plt.subplots(2,2,figsize=(9,6),layout='constrained')
        for i,ax in enumerate(axes.flat):
            ax.plot(times/60,observed[:,i],color='#202020',lw=1.7,ls='--',label='CADET reference')
            ax.plot(times/60,predicted[:,i],color='#2677ba',lw=1.25,label='TDM + SMA')
            ax.set(xlabel='Time (min)',ylabel='Concentration (mol/m³)',
                   title=('Salt' if i==0 else f'Protein {i}'))
            ax.grid(alpha=.2)
        axes.flat[0].legend(frameon=False,fontsize=8)
        fig.suptitle('CADET-Core four-component LRMP/SMA reference vs TDM/SMA',fontsize=13)
        fig.savefig(folder/'cadet_sma_outlet_comparison.png',dpi=180)
        plt.close(fig)
    normalized_rmse_percent=(100*np.sqrt(np.mean((predicted-observed)**2,axis=0))
                             /np.max(observed,axis=0))
    protein_mass_error_percent=max(abs(row['closure_error_percent_of_input'])
                                   for row in result['mass_balance'].values())
    salt_balance=result['simulation']['diagnostics']['sma_salt_balance']
    metrics={
        'reference':reference['source'],
        'cadet_version':reference['version'],
        'cadet_commit':reference['commit'],
        'axial_cells':config['numerics']['axial_positions'],
        'anchors':len(rows),
        'elapsed_seconds':elapsed,
        'normalized_rmse_percent':dict(zip(['salt','protein_1','protein_2','protein_3'],
                                            normalized_rmse_percent.tolist())),
        'maximum_protein_mass_closure_percent':protein_mass_error_percent,
        'salt_mass_closure_percent':salt_balance['closure_error_percent_of_input'],
        'minimum_free_sites_mol_m3':min(trace['sma_free_sites_mol_m3']),
        'minimum_bound_counterions_mol_m3':min(trace['sma_bound_counterion_mol_m3']),
    }
    assert np.max(normalized_rmse_percent)<0.5,metrics
    assert protein_mass_error_percent<0.1,metrics
    assert abs(salt_balance['closure_error_percent_of_input'])<0.1,metrics
    assert metrics['minimum_free_sites_mol_m3']>=-1e-6,metrics
    assert metrics['minimum_bound_counterions_mol_m3']>=-1e-6,metrics
    (folder/'cadet_sma_benchmark_metrics.json').write_text(json.dumps(metrics,indent=2))
    return metrics


if __name__=='__main__':
    print(json.dumps(run(),indent=2))
